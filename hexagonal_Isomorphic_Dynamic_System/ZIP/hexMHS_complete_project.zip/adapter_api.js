// adapter_api.js
/**
 * ADAPTER API
 * External interface for adapter functionality
 */

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

class AdapterAPI {
    constructor(runtime, config) {
        this.runtime = runtime;
        this.config = config;
        this.app = express();
        this.server = null;
        this.setupMiddleware();
        this.setupRoutes();
    }

    setupMiddleware() {
        // Adapter decision: API middleware stack
        if (this.config.get('api.cors')) {
            this.app.use(cors());
        }

        this.app.use(express.json({ 
            limit: this.config.get('security.maxInputSize')
        }));

        if (this.config.get('api.rateLimit.enabled')) {
            const limiter = rateLimit({
                windowMs: this.config.get('api.rateLimit.windowMs'),
                max: this.config.get('api.rateLimit.maxRequests')
            });
            this.app.use(limiter);
        }

        // Adapter decision: request logging
        this.app.use((req, res, next) => {
            this.runtime.log('debug', `API ${req.method} ${req.path}`, {
                ip: req.ip,
                userAgent: req.get('User-Agent')
            });
            next();
        });
    }

    setupRoutes() {
        // Health check endpoint
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                timestamp: new Date().toISOString(),
                runtime: this.runtime.getStatus()
            });
        });

        // Configuration endpoints
        this.app.get('/config', (req, res) => {
            res.json(this.config.getAll());
        });

        this.app.patch('/config', (req, res) => {
            try {
                this.config.update(req.body);
                res.json({ success: true, config: this.config.getAll() });
            } catch (error) {
                res.status(400).json({ error: error.message });
            }
        });

        // Cache management endpoints
        this.app.get('/cache/stats', (req, res) => {
            res.json(this.runtime.getCacheStats());
        });

        this.app.delete('/cache', (req, res) => {
            this.runtime.clearCache();
            res.json({ success: true, message: 'Cache cleared' });
        });

        // Metrics endpoints
        this.app.get('/metrics', (req, res) => {
            res.json(this.runtime.getMetrics());
        });

        // Logs endpoints
        this.app.get('/logs', (req, res) => {
            const level = req.query.level;
            const limit = parseInt(req.query.limit) || 100;
            res.json(this.runtime.getLogs(level, limit));
        });

        // Main processing endpoint
        this.app.post('/process', async (req, res) => {
            try {
                // Adapter decision: input validation
                if (this.config.get('security.validateInput')) {
                    this._validateProcessingInput(req.body);
                }

                const result = await this._handleProcessingRequest(req.body);
                res.json(result);

            } catch (error) {
                this.runtime.log('error', 'Processing request failed', {
                    error: error.message,
                    body: req.body
                });
                
                res.status(400).json({
                    error: error.message,
                    timestamp: new Date().toISOString()
                });
            }
        });

        // Batch processing endpoint
        this.app.post('/process/batch', async (req, res) => {
            try {
                const { items } = req.body;
                if (!Array.isArray(items)) {
                    throw new Error('Batch items must be an array');
                }

                const results = await Promise.allSettled(
                    items.map(item => this._handleProcessingRequest(item))
                );

                res.json({
                    total: results.length,
                    successful: results.filter(r => r.status === 'fulfilled').length,
                    failed: results.filter(r => r.status === 'rejected').length,
                    results: results
                });

            } catch (error) {
                res.status(400).json({ error: error.message });
            }
        });

        // Status endpoint
        this.app.get('/status', (req, res) => {
            res.json({
                adapter: this.runtime.getStatus(),
                api: {
                    port: this.config.get('api.port'),
                    uptime: this.server ? process.uptime() : 0
                }
            });
        });

        // Error handler
        this.app.use((error, req, res, next) => {
            this.runtime.log('error', 'API error', {
                error: error.message,
                stack: error.stack,
                path: req.path
            });

            res.status(500).json({
                error: 'Internal adapter error',
                timestamp: new Date().toISOString()
            });
        });
    }

    async start() {
        const port = this.config.get('api.port');
        const host = this.config.get('api.host');

        return new Promise((resolve, reject) => {
            this.server = this.app.listen(port, host, (error) => {
                if (error) {
                    reject(error);
                } else {
                    this.runtime.log('info', `API server started on ${host}:${port}`);
                    resolve();
                }
            });
        });
    }

    async stop() {
        if (!this.server) return;

        return new Promise((resolve) => {
            this.server.close(() => {
                this.runtime.log('info', 'API server stopped');
                resolve();
            });
        });
    }

    _validateProcessingInput(input) {
        if (!input || typeof input !== 'object') {
            throw new Error('Input must be an object');
        }

        // Adapter decision: required fields validation
        if (!input.canonical) {
            throw new Error('Missing canonical field in input');
        }
    }

    async _handleProcessingRequest(input) {
        // Adapter freedom: how to handle processing requests
        const startTime = Date.now();

        try {
            // Extract canonical result from input
            const canonicalResult = input.canonical;

            // Adapter decision: additional processing based on request
            const options = input.options || {};
            const context = input.context || {};

            // Process through main adapter logic (would need reference to main adapter)
            // For this example, we'll simulate processing
            const processed = {
                canonical: canonicalResult,
                adapter: {
                    timestamp: new Date().toISOString(),
                    options: options,
                    context: context,
                    processingTime: Date.now() - startTime
                }
            };

            return {
                success: true,
                result: processed,
                metadata: {
                    processingTime: Date.now() - startTime,
                    timestamp: new Date().toISOString()
                }
            };

        } catch (error) {
            throw new Error(`Processing failed: ${error.message}`);
        }
    }
}

module.exports = AdapterAPI;