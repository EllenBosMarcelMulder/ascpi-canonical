/**
 * PIPELINE DEMONSTRATION
 * Toont de complete bestand â†’ SVG pijplijn
 */

const Orchestrator = require('./orchestrator');
const FileToMathModule = require('./module_file_to_math');
const MathToEnergyModule = require('./module_math_to_energy');
const EnergyToSvgModule = require('./module_energy_to_svg');

async function demonstratePipeline() {
    try {
        console.log('=== MINIMAAL MODULAIR SYSTEEM ===');
        
        // 1. Initialize orchestrator
        const orchestrator = new Orchestrator();
        
        // 2. Register three modules
        orchestrator
            .registerModule(new FileToMathModule())
            .registerModule(new MathToEnergyModule())
            .registerModule(new EnergyToSvgModule());
        
        // 3. Set pipeline
        orchestrator.setPipeline(['file_to_math', 'math_to_energy', 'energy_to_svg']);
        
        console.log('Modules:', orchestrator.getModules());
        console.log('Pipeline:', orchestrator.getPipeline());
        
        // 4. Test with sample input
        const sampleInput = { 
            content: 'Hello, this is a test file for the minimal modular system.' 
        };
        
        console.log('\n=== EXECUTING PIPELINE ===');
        const result = await orchestrator.execute(sampleInput);
        
        console.log('Execution trace:');
        result.trace.forEach((step, index) => {
            console.log(`  ${index + 1}. ${step.module}: ${step.input_type} â†’ ${step.output_type} (${step.success ? 'SUCCESS' : 'FAILED'})`);
            if (!step.success) {
                console.log(`     Error: ${step.error}`);
            }
        });
        
        console.log('\n=== FINAL RESULT ===');
        console.log('SVG dimensions:', result.result.dimensions);
        console.log('Energy state:', result.result.energy_state);
        console.log('Checksum:', result.result.checksum);
        console.log('SVG length:', result.result.content.length, 'characters');
        
        // 5. Save SVG output
        const fs = require('fs').promises;
        await fs.writeFile('/mnt/user-data/outputs/energy_field.svg', result.result.content);
        console.log('\nSVG saved to: /mnt/user-data/outputs/energy_field.svg');
        
    } catch (error) {
        console.error('Pipeline failed:', error.message);
    }
}

// Export for external use
module.exports = { demonstratePipeline };

// Run if called directly
if (require.main === module) {
    demonstratePipeline();
}
