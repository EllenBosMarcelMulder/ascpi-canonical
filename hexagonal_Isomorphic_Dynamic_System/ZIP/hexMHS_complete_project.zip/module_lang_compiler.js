class ModuleLangCompiler {
    constructor() {
        this.assignmentPattern = /(\w+)\s*=\s*([^;\n]+)/g;
        this.returnPattern = /return\s*{([^}]*)}/;
    }

    parseBlocks(sourceCode) {
        const blocks = [];
        let i = 0;
        
        while (i < sourceCode.length) {
            while (i < sourceCode.length && /\s/.test(sourceCode[i])) {
                i++;
            }
            
            if (i >= sourceCode.length) break;
            
            const moduleMatch = sourceCode.substr(i).match(/^module\s+(\w+)\s*{/);
            const programMatch = sourceCode.substr(i).match(/^program\s+(\w+)\s*{/);
            
            if (moduleMatch) {
                const result = this.parseModuleBlock(sourceCode, i);
                blocks.push(result.block);
                i = result.nextPosition;
            } else if (programMatch) {
                const result = this.parseProgramBlock(sourceCode, i);
                blocks.push(result.block);
                i = result.nextPosition;
            } else {
                i++;
            }
        }
        
        return blocks;
    }

    parseModuleBlock(sourceCode, startPos) {
        const match = sourceCode.substr(startPos).match(/^module\s+(\w+)\s*{/);
        if (!match) throw new Error('Invalid module syntax');
        
        const moduleId = match[1];
        const blockStart = startPos + match[0].length;
        const blockContent = this.extractBlock(sourceCode, blockStart);
        
        const module = {
            type: 'module',
            id: moduleId,
            inputs: [],
            outputs: [],
            stepBody: ''
        };
        
        const inputsMatch = blockContent.match(/inputs:\s*([^\n]+)/);
        const outputsMatch = blockContent.match(/outputs:\s*([^\n]+)/);
        
        if (inputsMatch) {
            module.inputs = this.parseInputsList(inputsMatch[1]);
        }
        
        if (outputsMatch) {
            module.outputs = this.parseOutputsList(outputsMatch[1]);
        }
        
        const stepStart = blockContent.search(/step\s*{/);
        if (stepStart !== -1) {
            const stepMatch = blockContent.substr(stepStart).match(/^step\s*{/);
            if (stepMatch) {
                const stepBodyStart = stepStart + stepMatch[0].length;
                module.stepBody = this.extractBlock(blockContent, stepBodyStart);
            }
        }
        
        return {
            block: module,
            nextPosition: blockStart + blockContent.length + 1
        };
    }

    parseProgramBlock(sourceCode, startPos) {
        const match = sourceCode.substr(startPos).match(/^program\s+(\w+)\s*{/);
        if (!match) throw new Error('Invalid program syntax');
        
        const programId = match[1];
        const blockStart = startPos + match[0].length;
        const blockContent = this.extractBlock(sourceCode, blockStart);
        
        const program = {
            type: 'program',
            id: programId,
            uses: [],
            connections: []
        };
        
        const usePattern = /use\s+(\w+)/g;
        let useMatch;
        while ((useMatch = usePattern.exec(blockContent)) !== null) {
            program.uses.push(useMatch[1]);
        }
        
        const connectPattern = /connect\s+(\w+)\.(\w+)\s*->\s*(\w+)\.(\w+)/g;
        let connectMatch;
        while ((connectMatch = connectPattern.exec(blockContent)) !== null) {
            program.connections.push({
                fromModule: connectMatch[1],
                fromOutput: connectMatch[2],
                toModule: connectMatch[3],
                toInput: connectMatch[4]
            });
        }
        
        return {
            block: program,
            nextPosition: blockStart + blockContent.length + 1
        };
    }

    extractBlock(sourceCode, startPos) {
        let braceCount = 1;
        let i = startPos;
        let content = '';
        
        while (i < sourceCode.length && braceCount > 0) {
            const char = sourceCode[i];
            
            if (char === '{') {
                braceCount++;
            } else if (char === '}') {
                braceCount--;
            }
            
            if (braceCount > 0) {
                content += char;
            }
            
            i++;
        }
        
        if (braceCount > 0) {
            throw new Error('Unclosed block');
        }
        
        return content;
    }

    parseInputsList(inputsStr) {
        if (!inputsStr) return [];
        return inputsStr.split(',').map(s => s.trim()).filter(s => s.length > 0);
    }

    parseOutputsList(outputsStr) {
        if (!outputsStr) return [];
        return outputsStr.split(',').map(s => s.trim()).filter(s => s.length > 0);
    }

    parseStepBody(stepBody) {
        const assignments = [];
        const returnStatement = {};
        
        this.assignmentPattern.lastIndex = 0;
        let match;
        while ((match = this.assignmentPattern.exec(stepBody)) !== null) {
            assignments.push({
                variable: match[1],
                expression: match[2].trim()
            });
        }
        
        const returnMatch = stepBody.match(this.returnPattern);
        if (returnMatch) {
            const returnContent = returnMatch[1];
            const pairs = returnContent.split(',');
            for (const pair of pairs) {
                const [key, value] = pair.split(':').map(s => s.trim());
                if (key && value) {
                    returnStatement[key] = value;
                }
            }
        }
        
        return { assignments, returnStatement };
    }

    generateExecuteFunction(moduleId, inputs, outputs, stepBody) {
        const { assignments, returnStatement } = this.parseStepBody(stepBody);
        
        let functionBody = `
        const inputs = executionContext.input || {};
        const context = executionContext.context || {};
        const moduleData = executionContext.moduleData || {};
        const setData = executionContext.setData || (() => {});
        const getData = executionContext.getData || (() => {});
        
        `;

        for (const input of inputs) {
            functionBody += `const ${input} = inputs.${input};\n        `;
        }

        // Track declared variables to avoid re-declaration
        const declaredVars = new Set();
        
        for (const assignment of assignments) {
            if (declaredVars.has(assignment.variable)) {
                // Re-assignment, not declaration
                functionBody += `${assignment.variable} = ${assignment.expression};\n        `;
            } else {
                // First declaration
                functionBody += `let ${assignment.variable} = ${assignment.expression};\n        `;
                declaredVars.add(assignment.variable);
            }
        }

        functionBody += `
        const outputs = {};
        `;

        for (const output of outputs) {
            if (returnStatement[output]) {
                functionBody += `outputs.${output} = ${returnStatement[output]};\n        `;
            } else {
                functionBody += `outputs.${output} = null;\n        `;
            }
        }

        functionBody += `
        return {
            outputs: outputs,
            contextDelta: {},
            signals: []
        };`;

        return new Function('executionContext', functionBody);
    }

    validateProgram(blocks) {
        const modules = blocks.filter(b => b.type === 'module');
        const programs = blocks.filter(b => b.type === 'program');
        
        if (programs.length > 1) {
            throw new Error('Multiple programs not allowed');
        }
        
        if (programs.length === 1) {
            const program = programs[0];
            const moduleIds = new Set(modules.map(m => m.id));
            
            for (const usedModule of program.uses) {
                if (!moduleIds.has(usedModule)) {
                    throw new Error(`Module ${usedModule} not found`);
                }
            }
            
            for (const connection of program.connections) {
                if (!moduleIds.has(connection.fromModule)) {
                    throw new Error(`Module ${connection.fromModule} not found`);
                }
                if (!moduleIds.has(connection.toModule)) {
                    throw new Error(`Module ${connection.toModule} not found`);
                }
            }
        }
    }

    compile(sourceCode) {
        const blocks = this.parseBlocks(sourceCode);
        this.validateProgram(blocks);
        
        const modules = blocks.filter(b => b.type === 'module').map(block => ({
            id: block.id,
            inputs: block.inputs,
            outputs: block.outputs,
            execute: this.generateExecuteFunction(block.id, block.inputs, block.outputs, block.stepBody)
        }));
        
        const program = blocks.find(b => b.type === 'program') || null;
        
        return {
            modules: modules,
            program: program
        };
    }

    compileToContracts(sourceCode) {
        const { ModuleContract } = require('./module_runtime');
        const compilation = this.compile(sourceCode);
        
        return compilation.modules.map(mod => new ModuleContract(
            mod.id,
            mod.execute,
            null,
            null
        ));
    }

    loadIntoRuntime(runtime, sourceCode) {
        const compilation = this.compile(sourceCode);
        const results = [];
        
        for (const mod of compilation.modules) {
            const success = runtime.registerModule(mod.id, mod.execute);
            results.push({
                moduleId: mod.id,
                registered: success
            });
        }

        if (compilation.program) {
            for (const moduleId of compilation.program.uses) {
                runtime.loadModule(moduleId);
            }

            for (const connection of compilation.program.connections) {
                runtime.connect(
                    connection.fromModule,
                    connection.fromOutput,
                    connection.toModule,
                    connection.toInput
                );
            }
        }
        
        return {
            modules: results,
            program: compilation.program
        };
    }
}

module.exports = ModuleLangCompiler;
