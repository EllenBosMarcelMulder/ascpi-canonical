// vis_index.js
const VisRuntime = require('./vis_runtime');
const VisSvgAdapter = require('./vis_svg_adapter');
const VisCliAdapter = require('./vis_cli_adapter');
const VisWebAdapter = require('./vis_web_adapter');

class VisualizationAdapter {
    constructor(config = {}) {
        this.runtime = new VisRuntime(config);
        this.svgAdapter = new VisSvgAdapter(this.runtime.config);
        this.cliAdapter = new VisCliAdapter(this.runtime.config);
        this.webAdapter = new VisWebAdapter(this.runtime.config);
    }

    async start() {
        await this.runtime.start();
    }

    async stop() {
        await this.runtime.stop();
    }

    renderSVG(canonicalResult) {
        return this.svgAdapter.render(canonicalResult);
    }

    renderCLI(canonicalResult) {
        return this.cliAdapter.render(canonicalResult);
    }

    renderWeb(canonicalResult, targetElement) {
        return this.webAdapter.render(canonicalResult, targetElement);
    }

    updateConfig(newConfig) {
        this.runtime.updateConfig(newConfig);
        this.svgAdapter.updateConfig(this.runtime.config);
        this.cliAdapter.updateConfig(this.runtime.config);
        this.webAdapter.updateConfig(this.runtime.config);
    }
}

module.exports = VisualizationAdapter;