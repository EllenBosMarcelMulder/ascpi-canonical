// vis_timeline_buffer.js
class VisTimelineBuffer {
    constructor(maxLength = 100) {
        this.maxLength = maxLength;
        this.buffer = [];
        this.currentIndex = 0;
        this.overflowCount = 0;
    }

    add(canonicalResult) {
        if (this.buffer.length < this.maxLength) {
            this.buffer.push({
                data: canonicalResult,
                index: this.currentIndex,
                timestamp: Date.now()
            });
        } else {
            const insertIndex = this.overflowCount % this.maxLength;
            this.buffer[insertIndex] = {
                data: canonicalResult,
                index: this.currentIndex,
                timestamp: Date.now()
            };
            this.overflowCount++;
        }
        this.currentIndex++;
    }

    getAll() {
        if (this.buffer.length < this.maxLength) {
            return [...this.buffer];
        }
        
        const startIndex = this.overflowCount % this.maxLength;
        const orderedBuffer = [
            ...this.buffer.slice(startIndex),
            ...this.buffer.slice(0, startIndex)
        ];
        
        return orderedBuffer;
    }

    getRange(startIndex, endIndex) {
        const all = this.getAll();
        return all.filter(item => 
            item.index >= startIndex && item.index <= endIndex
        );
    }

    getLast(count = 1) {
        const all = this.getAll();
        return all.slice(-count);
    }

    getCount() {
        return this.buffer.length;
    }

    getTotalAdded() {
        return this.currentIndex;
    }

    clear() {
        this.buffer = [];
        this.currentIndex = 0;
        this.overflowCount = 0;
    }

    setMaxLength(newMaxLength) {
        if (newMaxLength <= 0) return;
        
        if (newMaxLength < this.maxLength && this.buffer.length > newMaxLength) {
            const all = this.getAll();
            this.buffer = all.slice(-newMaxLength);
            this.overflowCount = 0;
        }
        
        this.maxLength = newMaxLength;
    }

    getMaxLength() {
        return this.maxLength;
    }

    isEmpty() {
        return this.buffer.length === 0;
    }

    isFull() {
        return this.buffer.length === this.maxLength;
    }
}

module.exports = VisTimelineBuffer;
