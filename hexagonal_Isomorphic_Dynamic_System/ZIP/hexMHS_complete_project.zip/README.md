# MINIMAAL MODULAIR SYSTEEM

## Bestandsstructuur

```
orchestrator.js           - Module registry en sequential execution
module_file_to_math.js    - Module 1: File → Math
module_math_to_energy.js  - Module 2: Math → Energy (via kernel)  
module_energy_to_svg.js   - Module 3: Energy → SVG
pipeline.js              - Pipeline demonstratie
```

## Modules

**Module 1: File → Math**
- Input: `file` 
- Output: `math_field`
- Functie: Numerieke velden extraheren uit bestand
- Geen kernel calls

**Module 2: Math → Energy**
- Input: `math_field`
- Output: `energy_state`  
- Functie: Roept UITSLUITEND `ascpi_kernel_v1.1.py` aan
- Geen andere logica

**Module 3: Energy → SVG**
- Input: `energy_state`
- Output: `svg_state`
- Functie: Deterministisch, forensisch, lossless SVG
- Geen kernel calls

## Pipeline

```
bestand → Module 1 → Module 2 → Module 3 → SVG
```

## Module Contract

Elke module heeft:
- `id` - Unieke identifier
- `input_type` - Input type naam
- `output_type` - Output type naam  
- `process(input)` - Transformatie functie

## Usage

```javascript
const Orchestrator = require('./orchestrator');
const orchestrator = new Orchestrator();

// Register modules
orchestrator.registerModule(module1);
orchestrator.registerModule(module2); 
orchestrator.registerModule(module3);

// Set pipeline
orchestrator.setPipeline(['file_to_math', 'math_to_energy', 'energy_to_svg']);

// Execute
const result = await orchestrator.execute(inputFile);
```
