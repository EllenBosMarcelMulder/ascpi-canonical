/**
 * MODULE 1: FILE â†’ MATH
 * Zet bestand om naar numerieke velden
 * Geen kernel calls
 */

const crypto = require('crypto');
const fs = require('fs').promises;

class FileToMathModule {
    constructor() {
        this.id = 'file_to_math';
        this.input_type = 'file';
        this.output_type = 'math_field';
    }

    /**
     * Converteer bestand naar numerieke velden
     */
    async process(input) {
        let buffer;
        
        // Handle different input types
        if (typeof input === 'string') {
            // File path
            buffer = await fs.readFile(input);
        } else if (input.buffer || input.data) {
            // Buffer or data object
            buffer = input.buffer || input.data;
        } else if (typeof input === 'object' && input.content) {
            // Object with content
            buffer = Buffer.from(input.content);
        } else {
            throw new Error('Invalid file input format');
        }

        // Extract numerical fields from file data
        const math_field = this._extractMathFields(buffer);
        
        return math_field;
    }

    /**
     * Extraheer numerieke velden uit buffer
     */
    _extractMathFields(buffer) {
        // Hash for deterministic base values
        const hash = crypto.createHash('sha256').update(buffer).digest();
        
        // Extract positional values from hash
        const dPhi_base = (hash[0] / 255) * 2 - 1; // Range [-1, 1]
        const kappa_base = (hash[1] / 255) * 10; // Range [0, 10]
        const theta_base = (hash[2] / 255) * 2 * Math.PI; // Range [0, 2Ï€]
        const C_base = hash[3] / 255; // Range [0, 1]
        
        // Calculate field metrics
        const entropy = this._calculateEntropy(buffer);
        const complexity = this._calculateComplexity(buffer);
        const density = buffer.length > 0 ? (buffer.reduce((sum, byte) => sum + byte, 0) / buffer.length) / 255 : 0;
        
        // Build math field object
        const math_field = {
            // Base field components
            dPhi: dPhi_base * (1 + entropy * 0.1),
            kappa: Math.max(0.01, kappa_base * (1 + complexity * 0.1)),
            theta: theta_base,
            C: C_base * (1 + density * 0.1),
            
            // Metadata
            size: buffer.length,
            entropy: entropy,
            complexity: complexity,
            density: density,
            hash: hash.toString('hex').substring(0, 16)
        };
        
        return math_field;
    }

    /**
     * Bereken Shannon entropy
     */
    _calculateEntropy(buffer) {
        const frequencies = new Array(256).fill(0);
        
        // Count byte frequencies
        for (const byte of buffer) {
            frequencies[byte]++;
        }
        
        // Calculate entropy
        let entropy = 0;
        for (const freq of frequencies) {
            if (freq > 0) {
                const probability = freq / buffer.length;
                entropy -= probability * Math.log2(probability);
            }
        }
        
        return entropy / 8; // Normalize to [0, 1]
    }

    /**
     * Bereken structurele complexiteit
     */
    _calculateComplexity(buffer) {
        if (buffer.length === 0) return 0;
        
        // Count consecutive byte patterns
        let patterns = 0;
        let lastByte = buffer[0];
        let runLength = 1;
        
        for (let i = 1; i < buffer.length; i++) {
            if (buffer[i] === lastByte) {
                runLength++;
            } else {
                if (runLength > 1) patterns++;
                lastByte = buffer[i];
                runLength = 1;
            }
        }
        
        // Return normalized complexity metric
        return Math.min(1, patterns / (buffer.length / 4));
    }
}

module.exports = FileToMathModule;
