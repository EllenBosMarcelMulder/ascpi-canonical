// vis_timeline_runtime.js
const VisTimelineBuffer = require('./vis_timeline_buffer');

class VisTimelineRuntime {
    constructor(config) {
        this.config = config;
        this.state = 'STOPPED';
        this.buffer = new VisTimelineBuffer(config.get('timeline.maxHistory') || 100);
        this.animationAdapter = null;
    }

    async start() {
        this.state = 'RUNNING';
        this.buffer.clear();
    }

    async stop() {
        this.state = 'STOPPED';
    }

    async reset() {
        this.buffer.clear();
    }

    addSnapshot(canonicalResult) {
        if (this.state !== 'RUNNING') {
            throw new Error('Timeline runtime not running');
        }

        if (!canonicalResult) {
            throw new Error('Invalid canonical result');
        }

        this.buffer.add(canonicalResult);
    }

    getSnapshots(count = null) {
        if (count === null) {
            return this.buffer.getAll();
        }
        return this.buffer.getLast(count);
    }

    getSnapshotRange(startIndex, endIndex) {
        return this.buffer.getRange(startIndex, endIndex);
    }

    getSnapshotCount() {
        return this.buffer.getCount();
    }

    getTotalSnapshotsAdded() {
        return this.buffer.getTotalAdded();
    }

    setAnimationAdapter(adapter) {
        this.animationAdapter = adapter;
    }

    generateAnimation(config = {}) {
        if (!this.animationAdapter) {
            throw new Error('No animation adapter set');
        }

        const snapshots = this.getSnapshots();
        if (snapshots.length === 0) {
            return null;
        }

        return this.animationAdapter.render(snapshots, config);
    }

    generateAnimationFromRange(startIndex, endIndex, config = {}) {
        if (!this.animationAdapter) {
            throw new Error('No animation adapter set');
        }

        const snapshots = this.getSnapshotRange(startIndex, endIndex);
        if (snapshots.length === 0) {
            return null;
        }

        return this.animationAdapter.render(snapshots, config);
    }

    updateConfig(newConfig) {
        this.config = newConfig;
        const maxHistory = newConfig.get('timeline.maxHistory');
        if (maxHistory) {
            this.buffer.setMaxLength(maxHistory);
        }
    }

    getStatus() {
        return {
            state: this.state,
            snapshotCount: this.getSnapshotCount(),
            totalAdded: this.getTotalSnapshotsAdded(),
            bufferFull: this.buffer.isFull(),
            maxHistory: this.buffer.getMaxLength()
        };
    }

    isEmpty() {
        return this.buffer.isEmpty();
    }

    clearBuffer() {
        this.buffer.clear();
    }
}

module.exports = VisTimelineRuntime;
