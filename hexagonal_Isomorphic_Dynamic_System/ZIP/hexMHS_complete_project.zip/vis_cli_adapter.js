// vis_cli_adapter.js
class VisCliAdapter {
    constructor(config) {
        this.config = config;
    }

    render(canonicalResult) {
        if (!canonicalResult || !canonicalResult.psi) {
            return this._renderEmpty();
        }

        const psi = canonicalResult.psi;
        const cliConfig = this.config.get('cli');
        
        const header = this._createHeader(cliConfig);
        const separator = this._createSeparator(cliConfig);
        const data = this._createDataRow(psi, cliConfig);
        
        return header + '\n' + separator + '\n' + data;
    }

    _createHeader(config) {
        const columns = config.headers.map(header => 
            this._padColumn(header, config.columnWidth)
        );
        return columns.join(config.separator);
    }

    _createSeparator(config) {
        const totalWidth = (config.columnWidth * config.headers.length) + 
                          (config.separator.length * (config.headers.length - 1));
        return '-'.repeat(totalWidth);
    }

    _createDataRow(psi, config) {
        const values = [
            this._formatNumber(psi.dPhi, config.precision),
            this._formatNumber(psi.kappa, config.precision),
            this._formatNumber(psi.theta, config.precision),
            this._formatNumber(psi.C, config.precision),
            this._formatNumber(psi.t, 0)
        ];
        
        const columns = values.map(value => 
            this._padColumn(value, config.columnWidth)
        );
        return columns.join(config.separator);
    }

    _formatNumber(value, precision) {
        if (typeof value !== 'number') return 'N/A';
        return precision > 0 ? value.toFixed(precision) : Math.round(value).toString();
    }

    _padColumn(text, width) {
        const str = text.toString();
        if (str.length >= width) {
            return str.substring(0, width - 1) + '~';
        }
        return str.padStart(width, ' ');
    }

    _renderEmpty() {
        const config = this.config.get('cli');
        return this._createHeader(config) + '\n' + 
               this._createSeparator(config) + '\n' + 
               'No data available';
    }

    updateConfig(config) {
        this.config = config;
    }
}

module.exports = VisCliAdapter;