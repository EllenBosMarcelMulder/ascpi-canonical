// vis_config.js (EXTENDED)
class VisConfig {
    constructor(overrides = {}) {
        this.config = {
            svg: {
                width: 800,
                height: 800,
                background: '#000000',
                centerX: 400,
                centerY: 400,
                hexagonRadius: 120,

                geometry: {
                    hexRadius: 120,
                    rotationOffset: 0,
                },

                mapping: {
                    dPhi: {
                        scaleFactor: 1.0,
                        modulo: null
                    },
                    kappa: {
                        scaleFactor: 1.0,
                        clampMin: null,
                        clampMax: null
                    },
                    theta: {
                        scaleFactor: 1.0
                    },
                    C: {
                        scaleFactor: 1.0,
                        clampMin: null,
                        clampMax: null
                    },
                    t: {
                        layerDivisor: 10,
                    }
                },

                layering: {
                    enabled: true,
                    maxLayers: 12
                },

                style: {
                    strokeColor: '#00ffcc',
                    strokeWidth: 2,
                    fillColor: 'none',
                    opacityBase: 1.0
                },

                colors: {
                    primary: '#00ffcc',
                    secondary: '#ffffff',
                    background: '#000000',
                    accent: '#ffaa00'
                }
            },

            timeline: {
                maxHistory: 100,
                bufferMode: 'ring'
            }
        };

        this.update(overrides);
    }

    update(overrides = {}) {
        this.config = this._deepMerge(this.config, overrides);
    }

    get(path) {
        return this._getNestedValue(this.config, path);
    }

    set(path, value) {
        this._setNestedValue(this.config, path, value);
    }

    getAll() {
        return JSON.parse(JSON.stringify(this.config));
    }

    _deepMerge(target, source) {
        const out = { ...target };
        for (const key in source) {
            if (
                typeof source[key] === 'object' &&
                source[key] !== null &&
                !Array.isArray(source[key])
            ) {
                out[key] = this._deepMerge(target[key] || {}, source[key]);
            } else {
                out[key] = source[key];
            }
        }
        return out;
    }

    _getNestedValue(obj, path) {
        return path.split('.').reduce((current, key) => {
            return current && current[key] !== undefined ? current[key] : undefined;
        }, obj);
    }

    _setNestedValue(obj, path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((current, key) => {
            if (!current[key]) current[key] = {};
            return current[key];
        }, obj);
        target[lastKey] = value;
    }
}

module.exports = VisConfig;