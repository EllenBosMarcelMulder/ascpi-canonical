/**
 * CONTRACT VALIDATION TEST
 * Test dat modules voldoen aan contract
 */

const Orchestrator = require('./orchestrator');
const FileToMathModule = require('./module_file_to_math');
const EnergyToSvgModule = require('./module_energy_to_svg');

function testModuleContracts() {
    console.log('=== MODULE CONTRACT VALIDATION ===');
    
    // Test orchestrator
    const orchestrator = new Orchestrator();
    
    // Test Module 1
    const module1 = new FileToMathModule();
    console.log('Module 1:', {
        id: module1.id,
        input_type: module1.input_type,
        output_type: module1.output_type,
        has_process: typeof module1.process === 'function'
    });
    
    // Test Module 3 (skip Module 2 as it needs Python)
    const module3 = new EnergyToSvgModule();
    console.log('Module 3:', {
        id: module3.id,
        input_type: module3.input_type,
        output_type: module3.output_type,
        has_process: typeof module3.process === 'function'
    });
    
    // Test registration
    try {
        orchestrator.registerModule(module1);
        orchestrator.registerModule(module3);
        console.log('âœ“ Modules registered successfully');
        console.log('Registered modules:', orchestrator.getModules());
    } catch (error) {
        console.log('âœ— Registration failed:', error.message);
    }
    
    // Test type mismatch detection
    try {
        orchestrator.setPipeline(['file_to_math', 'energy_to_svg']); // Wrong: math_field â†’ svg expects energy_state
        console.log('âœ— Type mismatch not detected');
    } catch (error) {
        console.log('âœ“ Type mismatch correctly detected:', error.message);
    }
    
    console.log('\n=== CONTRACT VALIDATION COMPLETE ===');
}

testModuleContracts();
