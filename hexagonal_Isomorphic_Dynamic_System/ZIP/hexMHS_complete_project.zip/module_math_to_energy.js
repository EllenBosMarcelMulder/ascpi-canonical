/**
 * MODULE 2: MATH â†’ ENERGY
 * Roept uitsluitend ascpi_kernel_v1.1.py aan
 * Bevat geen andere logica
 */

const { spawn } = require('child_process');
const path = require('path');

class MathToEnergyModule {
    constructor(kernelPath = '/mnt/project/ascpi_kernel_v1_1.py') {
        this.id = 'math_to_energy';
        this.input_type = 'math_field';
        this.output_type = 'energy_state';
        this.kernelPath = kernelPath;
    }

    /**
     * Verwerk math_field via canonieke kernel
     */
    async process(math_field) {
        // Validate input
        if (!math_field || typeof math_field.dPhi === 'undefined') {
            throw new Error('Invalid math_field input');
        }

        // Call canonical kernel ONLY
        const energy_state = await this._callKernel(math_field);
        
        return energy_state;
    }

    /**
     * Roep de canonieke kernel aan via Python subprocess
     */
    async _callKernel(math_field) {
        return new Promise((resolve, reject) => {
            // Prepare kernel input
            const kernelInput = {
                dPhi: math_field.dPhi,
                kappa: math_field.kappa,
                theta: math_field.theta,
                C: math_field.C,
                t: 0
            };

            // Create Python script to call kernel
            const pythonScript = `
import sys
import json
sys.path.append('${path.dirname(this.kernelPath)}')

from ascpi_kernel_v1_1 import ASCPIEngine, Psi

# Read input
input_data = json.loads(sys.argv[1])

# Create initial Psi state
psi = ASCPIEngine.create_initial_psi(
    dPhi=input_data['dPhi'],
    kappa=input_data['kappa'], 
    theta=input_data['theta'],
    C=input_data['C']
)

# Create engine and step
engine = ASCPIEngine(psi)
evolved_psi = engine.step()

# Output result
result = {
    'dPhi': evolved_psi.dPhi,
    'kappa': evolved_psi.kappa,
    'theta': evolved_psi.theta,
    'C': evolved_psi.C,
    'N': evolved_psi.N,
    't': evolved_psi.t
}

print(json.dumps(result))
`;

            // Spawn Python process
            const python = spawn('python3', ['-c', pythonScript, JSON.stringify(kernelInput)]);
            
            let stdout = '';
            let stderr = '';
            
            python.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            
            python.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            
            python.on('close', (code) => {
                if (code !== 0) {
                    reject(new Error(`Kernel call failed: ${stderr}`));
                    return;
                }
                
                try {
                    const energy_state = JSON.parse(stdout.trim());
                    resolve(energy_state);
                } catch (error) {
                    reject(new Error(`Failed to parse kernel output: ${error.message}`));
                }
            });
            
            python.on('error', (error) => {
                reject(new Error(`Failed to spawn Python process: ${error.message}`));
            });
        });
    }
}

module.exports = MathToEnergyModule;
