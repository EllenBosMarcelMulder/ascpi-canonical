// adapter_config.js
/**
 * ADAPTER CONFIGURATION
 * Manages all adapter-specific settings and decisions
 */

class AdapterConfig {
    constructor(initialConfig = {}) {
        this.config = this._getDefaultConfig();
        this._merge(initialConfig);
        this._validate();
    }

    _getDefaultConfig() {
        return {
            version: '1.0.0',
            environment: process.env.NODE_ENV || 'development',
            
            caching: {
                enabled: true,
                ttl: 300000, // 5 minutes
                maxSize: 1000
            },
            
            logging: {
                level: 'info',
                destination: 'console',
                format: 'json'
            },
            
            api: {
                port: 3000,
                host: '0.0.0.0',
                cors: true,
                rateLimit: {
                    enabled: true,
                    windowMs: 60000,
                    maxRequests: 100
                }
            },
            
            transformations: {
                addDisplayData: true,
                addAnalytics: false,
                addMetadata: true
            },
            
            errorHandling: {
                failFast: false,
                retryAttempts: 3,
                retryDelay: 1000
            },
            
            metrics: {
                enabled: true,
                flushInterval: 30000,
                retention: 86400000 // 24 hours
            },
            
            security: {
                validateInput: true,
                sanitizeOutput: false,
                maxInputSize: 1048576 // 1MB
            }
        };
    }

    _merge(newConfig) {
        this._deepMerge(this.config, newConfig);
    }

    _deepMerge(target, source) {
        for (const key in source) {
            if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                if (!target[key]) target[key] = {};
                this._deepMerge(target[key], source[key]);
            } else {
                target[key] = source[key];
            }
        }
    }

    _validate() {
        // Adapter decision: configuration validation rules
        if (this.config.caching.ttl < 0) {
            throw new Error('Cache TTL must be non-negative');
        }
        
        if (this.config.api.port < 1 || this.config.api.port > 65535) {
            throw new Error('API port must be between 1 and 65535');
        }
        
        if (!['debug', 'info', 'warn', 'error'].includes(this.config.logging.level)) {
            throw new Error('Invalid logging level');
        }
    }

    get(path) {
        return this._getNestedValue(this.config, path);
    }

    set(path, value) {
        this._setNestedValue(this.config, path, value);
        this._validate();
    }

    update(updates) {
        const oldConfig = JSON.parse(JSON.stringify(this.config));
        try {
            this._merge(updates);
            this._validate();
            return true;
        } catch (error) {
            this.config = oldConfig;
            throw error;
        }
    }

    getAll() {
        return JSON.parse(JSON.stringify(this.config));
    }

    _getNestedValue(obj, path) {
        return path.split('.').reduce((current, key) => {
            return current && current[key] !== undefined ? current[key] : undefined;
        }, obj);
    }

    _setNestedValue(obj, path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((current, key) => {
            if (!current[key]) current[key] = {};
            return current[key];
        }, obj);
        target[lastKey] = value;
    }

    isProduction() {
        return this.config.environment === 'production';
    }

    isDevelopment() {
        return this.config.environment === 'development';
    }
}

module.exports = AdapterConfig;