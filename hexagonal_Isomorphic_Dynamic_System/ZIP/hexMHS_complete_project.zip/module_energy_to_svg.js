/**
 * MODULE 3: ENERGY â†’ SVG
 * Genereert deterministische, forensische, lossless SVG
 */

class EnergyToSvgModule {
    constructor() {
        this.id = 'energy_to_svg';
        this.input_type = 'energy_state';
        this.output_type = 'svg_state';
        
        // Canvas dimensions for forensic precision
        this.width = 400;
        this.height = 400;
        this.center = { x: 200, y: 200 };
    }

    /**
     * Converteer energy_state naar deterministische SVG
     */
    async process(energy_state) {
        // Validate input
        if (!energy_state || typeof energy_state.dPhi === 'undefined') {
            throw new Error('Invalid energy_state input');
        }

        // Generate deterministic SVG
        const svg_elements = this._generateSvgElements(energy_state);
        const svg_content = this._assembleSvg(svg_elements, energy_state);
        
        const svg_state = {
            content: svg_content,
            dimensions: { width: this.width, height: this.height },
            energy_state: energy_state,
            checksum: this._calculateChecksum(svg_content),
            timestamp: Date.now()
        };
        
        return svg_state;
    }

    /**
     * Genereer SVG elementen deterministisch uit energy_state
     */
    _generateSvgElements(energy_state) {
        const elements = [];
        
        // Central field visualization based on energy parameters
        const fieldRadius = Math.abs(energy_state.dPhi) * 100 + 20;
        const fieldColor = this._energyToColor(energy_state);
        
        // Core field circle
        elements.push({
            type: 'circle',
            cx: this.center.x,
            cy: this.center.y,
            r: fieldRadius,
            fill: 'none',
            stroke: fieldColor,
            strokeWidth: 2,
            metadata: { component: 'field_core', dPhi: energy_state.dPhi }
        });
        
        // Kappa representation as radial lines
        const kappaLines = Math.floor(energy_state.kappa * 8);
        for (let i = 0; i < kappaLines; i++) {
            const angle = (energy_state.theta + (i * 2 * Math.PI / kappaLines)) % (2 * Math.PI);
            const x1 = this.center.x + Math.cos(angle) * fieldRadius * 0.8;
            const y1 = this.center.y + Math.sin(angle) * fieldRadius * 0.8;
            const x2 = this.center.x + Math.cos(angle) * fieldRadius * 1.2;
            const y2 = this.center.y + Math.sin(angle) * fieldRadius * 1.2;
            
            elements.push({
                type: 'line',
                x1: x1, y1: y1, x2: x2, y2: y2,
                stroke: fieldColor,
                strokeWidth: 1,
                opacity: 0.6,
                metadata: { component: 'kappa_line', index: i, angle: angle }
            });
        }
        
        // Coherence representation as filled arc
        if (energy_state.C > 0) {
            const coherenceArc = this._generateCoherenceArc(energy_state);
            elements.push(coherenceArc);
        }
        
        // N energy indicator
        const energyIndicator = this._generateEnergyIndicator(energy_state);
        elements.push(energyIndicator);
        
        // Time step markers
        if (energy_state.t > 0) {
            const timeMarkers = this._generateTimeMarkers(energy_state);
            elements.push(...timeMarkers);
        }
        
        return elements;
    }

    /**
     * Converteer energy parameters naar kleur deterministisch
     */
    _energyToColor(energy_state) {
        // Deterministic color based on field parameters
        const hue = ((energy_state.theta / (2 * Math.PI)) * 360) % 360;
        const saturation = Math.min(100, energy_state.kappa * 10);
        const lightness = 30 + (energy_state.C * 40);
        
        return `hsl(${hue.toFixed(1)}, ${saturation.toFixed(1)}%, ${lightness.toFixed(1)}%)`;
    }

    /**
     * Genereer coherentie arc
     */
    _generateCoherenceArc(energy_state) {
        const radius = 30;
        const sweepAngle = energy_state.C * 360;
        const startAngle = energy_state.theta;
        
        const x1 = this.center.x + Math.cos(startAngle) * radius;
        const y1 = this.center.y + Math.sin(startAngle) * radius;
        const x2 = this.center.x + Math.cos(startAngle + sweepAngle * Math.PI / 180) * radius;
        const y2 = this.center.y + Math.sin(startAngle + sweepAngle * Math.PI / 180) * radius;
        
        const largeArc = sweepAngle > 180 ? 1 : 0;
        
        return {
            type: 'path',
            d: `M ${this.center.x} ${this.center.y} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`,
            fill: this._energyToColor(energy_state),
            opacity: energy_state.C,
            metadata: { component: 'coherence_arc', value: energy_state.C }
        };
    }

    /**
     * Genereer energie indicator
     */
    _generateEnergyIndicator(energy_state) {
        const size = Math.max(2, energy_state.N * 8);
        
        return {
            type: 'rect',
            x: this.center.x - size/2,
            y: this.center.y - size/2,
            width: size,
            height: size,
            fill: '#ffffff',
            stroke: '#000000',
            strokeWidth: 1,
            metadata: { component: 'energy_indicator', N: energy_state.N }
        };
    }

    /**
     * Genereer tijd markers
     */
    _generateTimeMarkers(energy_state) {
        const markers = [];
        const markerCount = Math.min(20, energy_state.t);
        
        for (let i = 0; i < markerCount; i++) {
            const angle = (i * 2 * Math.PI / markerCount);
            const radius = 150 + (i * 2);
            const x = this.center.x + Math.cos(angle) * radius;
            const y = this.center.y + Math.sin(angle) * radius;
            
            markers.push({
                type: 'circle',
                cx: x, cy: y, r: 1,
                fill: '#cccccc',
                metadata: { component: 'time_marker', step: i }
            });
        }
        
        return markers;
    }

    /**
     * Assembleer definitieve SVG
     */
    _assembleSvg(elements, energy_state) {
        const header = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${this.width}" height="${this.height}" 
     xmlns="http://www.w3.org/2000/svg"
     xmlns:forensic="urn:forensic:energy">
     
  <!-- FORENSIC METADATA -->
  <metadata>
    <forensic:energy_state
      dPhi="${energy_state.dPhi}"
      kappa="${energy_state.kappa}"
      theta="${energy_state.theta}"
      C="${energy_state.C}"
      N="${energy_state.N}"
      t="${energy_state.t}" />
  </metadata>
  
  <!-- VISUAL ELEMENTS -->`;

        const footer = `</svg>`;
        
        let content = header;
        
        for (const element of elements) {
            content += '\n  ';
            content += this._elementToSvg(element);
        }
        
        content += '\n' + footer;
        
        return content;
    }

    /**
     * Converteer element naar SVG markup
     */
    _elementToSvg(element) {
        let svg = `<${element.type}`;
        
        // Add attributes
        for (const [key, value] of Object.entries(element)) {
            if (key !== 'type' && key !== 'metadata') {
                svg += ` ${key}="${value}"`;
            }
        }
        
        // Add metadata as comment
        if (element.metadata) {
            svg += `>\n    <!-- ${JSON.stringify(element.metadata)} -->`;
            svg += `\n  </${element.type}>`;
        } else {
            svg += ' />';
        }
        
        return svg;
    }

    /**
     * Bereken SVG checksum voor forensische verificatie
     */
    _calculateChecksum(content) {
        const crypto = require('crypto');
        return crypto.createHash('sha256').update(content).digest('hex');
    }
}

module.exports = EnergyToSvgModule;
