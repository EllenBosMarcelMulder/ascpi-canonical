// adapter_index.js
/**
 * ADAPTER INDEX - Main Entry Point
 * Orchestrates adapter functionality around canon consumption
 */

const AdapterConfig = require('./adapter_config');
const AdapterRuntime = require('./adapter_runtime');
const AdapterAPI = require('./adapter_api');

class HexProjectionAdapter {
    constructor(config = {}) {
        this.config = new AdapterConfig(config);
        this.runtime = new AdapterRuntime(this.config);
        this.api = new AdapterAPI(this.runtime, this.config);
        
        this.state = 'STOPPED';
        this.startTime = null;
        this.processCount = 0;
    }

    async start() {
        if (this.state === 'RUNNING') return;
        
        this.state = 'STARTING';
        this.startTime = Date.now();
        
        await this.runtime.initialize();
        await this.api.start();
        
        this.state = 'RUNNING';
        this.runtime.log('info', 'Adapter started successfully');
    }

    async stop() {
        if (this.state === 'STOPPED') return;
        
        this.state = 'STOPPING';
        
        await this.api.stop();
        await this.runtime.shutdown();
        
        this.state = 'STOPPED';
        this.startTime = null;
    }

    async reset() {
        await this.stop();
        this.processCount = 0;
        this.runtime.clearCache();
        await this.start();
    }

    async processCanonicalOutput(canonicalResult) {
        if (this.state !== 'RUNNING') {
            throw new Error('Adapter not running');
        }

        const processingId = `proc_${Date.now()}_${this.processCount++}`;
        const startTime = performance.now();

        try {
            this.runtime.log('debug', `Processing ${processingId}`, { canonicalResult });

            // Adapter decision: validate input structure
            if (!this._isValidCanonicalResult(canonicalResult)) {
                throw new Error('Invalid canonical result structure');
            }

            // Adapter decision: apply caching if enabled
            const cacheKey = this._generateCacheKey(canonicalResult);
            if (this.config.get('caching.enabled')) {
                const cached = this.runtime.getCache(cacheKey);
                if (cached) {
                    this.runtime.log('debug', `Cache hit for ${processingId}`);
                    return this._enrichResult(cached, processingId, 'CACHED');
                }
            }

            // Adapter processing: enhance canonical output
            const processed = await this._processResult(canonicalResult, processingId);

            // Adapter decision: store in cache if enabled
            if (this.config.get('caching.enabled')) {
                this.runtime.setCache(cacheKey, processed, this.config.get('caching.ttl'));
            }

            const duration = performance.now() - startTime;
            this.runtime.recordMetric('processing_duration', duration);
            this.runtime.recordMetric('processing_count', 1);

            return this._enrichResult(processed, processingId, 'PROCESSED', duration);

        } catch (error) {
            const duration = performance.now() - startTime;
            this.runtime.log('error', `Processing failed for ${processingId}`, { error: error.message });
            this.runtime.recordMetric('error_count', 1);

            // Adapter decision: how to handle errors
            if (this.config.get('errorHandling.failFast')) {
                throw error;
            }

            return this._enrichResult(null, processingId, 'ERROR', duration, error.message);
        }
    }

    _isValidCanonicalResult(result) {
        // Adapter decision: what constitutes valid canonical output
        return result && 
               typeof result === 'object' && 
               (result.psi || result.output || result.content);
    }

    _generateCacheKey(result) {
        // Adapter decision: cache key strategy
        const crypto = require('crypto');
        const key = JSON.stringify(result);
        return crypto.createHash('md5').update(key).digest('hex');
    }

    async _processResult(canonicalResult, processingId) {
        // Adapter enhancement: add metadata and context
        const processed = {
            canonical: canonicalResult,
            adapter: {
                processingId: processingId,
                timestamp: new Date().toISOString(),
                version: this.config.get('version'),
                environment: this.config.get('environment')
            }
        };

        // Adapter decision: optional transformations based on config
        if (this.config.get('transformations.addDisplayData')) {
            processed.display = await this._generateDisplayData(canonicalResult);
        }

        if (this.config.get('transformations.addAnalytics')) {
            processed.analytics = await this._generateAnalytics(canonicalResult);
        }

        return processed;
    }

    async _generateDisplayData(canonicalResult) {
        // Adapter freedom: create display-friendly data
        return {
            summary: this._createSummary(canonicalResult),
            visualization: this._createVisualizationHints(canonicalResult),
            export: this._createExportOptions(canonicalResult)
        };
    }

    async _generateAnalytics(canonicalResult) {
        // Adapter freedom: create analytics data
        return {
            complexity: this._calculateComplexity(canonicalResult),
            performance: this.runtime.getMetrics(),
            patterns: this._detectPatterns(canonicalResult)
        };
    }

    _createSummary(result) {
        // Adapter decision: how to summarize canonical output
        if (result.psi) {
            return `Field state: dPhi=${result.psi.dPhi?.toFixed(4)} C=${result.psi.C?.toFixed(4)}`;
        }
        if (result.output) {
            return `Output length: ${result.output.length} chars`;
        }
        return 'Unknown canonical result type';
    }

    _createVisualizationHints(result) {
        // Adapter freedom: suggest visualization approaches
        return {
            type: result.psi ? 'field_state' : 'text_output',
            dimensions: result.psi ? 6 : 1,
            recommended: 'svg'
        };
    }

    _createExportOptions(result) {
        // Adapter freedom: provide export capabilities
        return ['json', 'csv', 'xml'];
    }

    _calculateComplexity(result) {
        // Adapter decision: complexity metrics
        let score = 0;
        if (result.psi) {
            score += Math.abs(result.psi.dPhi || 0);
            score += Math.abs(result.psi.kappa || 0);
        }
        return Math.round(score * 100) / 100;
    }

    _detectPatterns(result) {
        // Adapter analysis: pattern detection
        return {
            detected: false,
            confidence: 0,
            patterns: []
        };
    }

    _enrichResult(processed, processingId, status, duration = null, error = null) {
        return {
            result: processed,
            metadata: {
                processingId: processingId,
                status: status,
                timestamp: new Date().toISOString(),
                duration: duration,
                error: error,
                adapter: {
                    version: this.config.get('version'),
                    uptime: this.startTime ? Date.now() - this.startTime : 0
                }
            }
        };
    }

    getStatus() {
        return {
            state: this.state,
            uptime: this.startTime ? Date.now() - this.startTime : 0,
            processCount: this.processCount,
            metrics: this.runtime.getMetrics()
        };
    }

    getConfig() {
        return this.config.getAll();
    }

    updateConfig(updates) {
        return this.config.update(updates);
    }
}

module.exports = HexProjectionAdapter;