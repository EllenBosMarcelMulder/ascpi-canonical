// test_hex_invariants_longrun.js
/**
 * LANGE-TERMIJN HEX-SEMANTISCHE INVARIANTEN TEST (72+ STEPS)
 * Verificatie van:
 * - Geen oscillatie
 * - Geen ring-instorting  
 * - Geen identiteitsverlies
 * - Hex-semantische invarianten blijven observational
 */

const { ModuleRuntime } = require('./module_runtime');
const ModuleLangCompiler = require('./module_lang_compiler');
const fs = require('fs');

class HexInvariantTracker {
    constructor() {
        this.stepData = [];
        this.migrationHistory = [];
        this.topologyChecksums = [];
        this.ringOccupancy = [];
        this.identityTracking = {};
    }

    recordStep(stepNumber, stepResults) {
        const inspector = stepResults.find(r => r.moduleId === 'OSInspector');
        const invariantMonitor = stepResults.find(r => r.moduleId === 'HexInvariantMonitor');
        const registry = stepResults.find(r => r.moduleId === 'ModuleRegistry');

        if (!inspector || !registry) return;

        const stepRecord = {
            step: stepNumber,
            ringOccupancy: inspector.outputs.ringOccupancyMap ? JSON.parse(inspector.outputs.ringOccupancyMap) : {},
            moduleDensity: inspector.outputs.moduleDensityMap ? JSON.parse(inspector.outputs.moduleDensityMap) : {},
            invariantFlags: inspector.outputs.invariantFlags ? JSON.parse(inspector.outputs.invariantFlags) : {},
            topologyChecksum: inspector.outputs.topologyChecksum,
            allocation: registry.outputs.allocation,
            migrationActivity: {
                plan: inspector.outputs.migrationSummary,
                execution: inspector.outputs.executionSummary
            }
        };

        if (invariantMonitor) {
            stepRecord.ringBalance = invariantMonitor.outputs.ringBalance;
            stepRecord.migrationPressure = invariantMonitor.outputs.migrationPressure;
            stepRecord.occupancyDegree = invariantMonitor.outputs.occupancyDegree;
        }

        this.stepData.push(stepRecord);

        // Track migrations
        if (stepRecord.migrationActivity.execution.indexOf("applied:1") > -1) {
            this.migrationHistory.push({
                step: stepNumber,
                allocation: stepRecord.allocation
            });
        }

        // Track topology checksums
        this.topologyChecksums.push({
            step: stepNumber,
            checksum: stepRecord.topologyChecksum
        });

        // Track ring occupancy
        this.ringOccupancy.push({
            step: stepNumber,
            ring0: stepRecord.ringOccupancy.ring0 || 0,
            ring1: stepRecord.ringOccupancy.ring1 || 0
        });
    }

    analyzeOscillation(windowSize = 10) {
        if (this.migrationHistory.length < 4) return { hasOscillation: false };

        const recentMigrations = this.migrationHistory.slice(-windowSize);
        const allocationStates = recentMigrations.map(m => m.allocation);

        // Check for repeating allocation patterns
        const stateFrequency = {};
        allocationStates.forEach(state => {
            stateFrequency[state] = (stateFrequency[state] || 0) + 1;
        });

        const hasRepeatingStates = Object.values(stateFrequency).some(count => count >= 3);

        // Check for back-and-forth migrations
        let backAndForthCount = 0;
        for (let i = 1; i < recentMigrations.length - 1; i++) {
            const prev = recentMigrations[i - 1].allocation;
            const current = recentMigrations[i].allocation;
            const next = recentMigrations[i + 1].allocation;

            if (prev === next && prev !== current) {
                backAndForthCount++;
            }
        }

        return {
            hasOscillation: hasRepeatingStates || backAndForthCount >= 2,
            repeatingStates: hasRepeatingStates,
            backAndForthCount: backAndForthCount,
            uniqueStates: Object.keys(stateFrequency).length
        };
    }

    analyzeRingStability() {
        if (this.ringOccupancy.length < 10) return { stable: true };

        const recent = this.ringOccupancy.slice(-20);
        
        // Check for ring collapse (all modules in one ring)
        const ring0Collapses = recent.filter(r => r.ring0 === 4 && r.ring1 === 0).length;
        const ring1Collapses = recent.filter(r => r.ring1 >= 3 && r.ring0 === 0).length;

        // Check for extreme imbalance persistence
        const extremeImbalances = recent.filter(r => 
            Math.abs(r.ring0 - r.ring1) >= 3
        ).length;

        return {
            stable: ring0Collapses === 0 && ring1Collapses === 0,
            ring0Collapses: ring0Collapses,
            ring1Collapses: ring1Collapses,
            extremeImbalances: extremeImbalances,
            avgRing0: recent.reduce((sum, r) => sum + r.ring0, 0) / recent.length,
            avgRing1: recent.reduce((sum, r) => sum + r.ring1, 0) / recent.length
        };
    }

    analyzeIdentityPreservation() {
        if (this.topologyChecksums.length < 10) return { preserved: true };

        // Check if topology checksum changes (identity loss)
        const baseChecksum = this.topologyChecksums[5].checksum; // After initialization
        const checksumChanges = this.topologyChecksums.slice(10).filter(
            c => Math.abs(c.checksum - baseChecksum) > 1000 // Major structural change
        );

        // Module allocation consistency
        const allocations = this.stepData.map(s => s.allocation);
        const parsedAllocations = allocations.map(a => {
            try {
                return JSON.parse(a);
            } catch {
                return null;
            }
        }).filter(a => a !== null);

        // Check for module disappearance or duplication
        const moduleKeys = ['HexTopology', 'Scheduler', 'OSInspector'];
        let identityViolations = 0;

        parsedAllocations.forEach(alloc => {
            moduleKeys.forEach(module => {
                if (alloc[module] === undefined) {
                    identityViolations++; // Module disappeared
                }
            });
        });

        return {
            preserved: checksumChanges.length === 0 && identityViolations === 0,
            checksumChanges: checksumChanges.length,
            identityViolations: identityViolations,
            stableChecksum: baseChecksum
        };
    }

    generateReport() {
        const oscillation = this.analyzeOscillation();
        const ringStability = this.analyzeRingStability();
        const identity = this.analyzeIdentityPreservation();

        return {
            totalSteps: this.stepData.length,
            totalMigrations: this.migrationHistory.length,
            oscillation: oscillation,
            ringStability: ringStability,
            identityPreservation: identity,
            summary: {
                stable: !oscillation.hasOscillation && ringStability.stable && identity.preserved,
                issues: [
                    oscillation.hasOscillation ? 'OSCILLATION_DETECTED' : null,
                    !ringStability.stable ? 'RING_INSTABILITY' : null,
                    !identity.preserved ? 'IDENTITY_LOSS' : null
                ].filter(i => i !== null)
            }
        };
    }
}

async function testHexInvariantsLongRun() {
    console.log('=== HEX-SEMANTISCHE INVARIANTEN LANGE-TERMIJN TEST (72+ STEPS) ===');

    const runtime = new ModuleRuntime();
    const compiler = new ModuleLangCompiler();
    const tracker = new HexInvariantTracker();

    try {
        // Load hexMHS with invariants
        console.log('Loading hexMHS with hex-semantische invarianten...');
        const hexMHS_invariants = fs.readFileSync('./hexMHS_with_invariants.os', 'utf8');

        // Compile and setup
        const compilation = compiler.compile(hexMHS_invariants);
        console.log('âœ“ Compiled successfully with', compilation.modules.length, 'modules');

        // Register modules
        for (const mod of compilation.modules) {
            runtime.registerModule(mod.id, mod.execute);
        }

        // Load modules  
        for (const moduleId of compilation.program.uses) {
            runtime.loadModule(moduleId);
        }

        // Setup connections
        for (const connection of compilation.program.connections) {
            runtime.connect(
                connection.fromModule,
                connection.fromOutput,
                connection.toModule,
                connection.toInput
            );
        }

        runtime.start();

        console.log('\n=== RUNNING 72+ STEPS MET HEX-INVARIANT MONITORING ===');

        // Run for 80 steps to ensure > 72
        for (let step = 1; step <= 80; step++) {
            const stepResult = runtime.step();
            
            if (stepResult && stepResult.results) {
                tracker.recordStep(step, stepResult.results);

                // Log key events
                const inspector = stepResult.results.find(r => r.moduleId === 'OSInspector');
                const invariantMonitor = stepResult.results.find(r => r.moduleId === 'HexInvariantMonitor');

                if (step % 10 === 0 || (inspector && inspector.outputs.executionSummary.indexOf("applied:1") > -1)) {
                    console.log(`Step ${step}:`);
                    
                    if (inspector) {
                        console.log(`  Ring Occupancy: ${inspector.outputs.ringOccupancyMap}`);
                        console.log(`  Module Density: ${inspector.outputs.moduleDensityMap}`);
                        console.log(`  Invariant Flags: ${inspector.outputs.invariantFlags}`);
                        console.log(`  Migration: ${inspector.outputs.executionSummary}`);
                        console.log(`  Checksum: ${inspector.outputs.topologyChecksum}`);
                    }
                    
                    if (invariantMonitor) {
                        console.log(`  Ring Balance: ${invariantMonitor.outputs.ringBalance}`);
                        console.log(`  Migration Pressure: ${invariantMonitor.outputs.migrationPressure}`);
                    }
                    
                    console.log('');
                }
            }
        }

        console.log('=== ANALYSE RESULTATEN ===');

        const report = tracker.generateReport();
        
        console.log('\nðŸ“Š LANGE-TERMIJN STABILITEIT ANALYSE:');
        console.log('Total Steps:', report.totalSteps);
        console.log('Total Migrations:', report.totalMigrations);
        console.log('Overall Stable:', report.summary.stable ? 'âœ…' : 'âŒ');
        
        if (report.summary.issues.length > 0) {
            console.log('Issues Detected:', report.summary.issues.join(', '));
        }

        console.log('\nðŸ”„ OSCILLATION ANALYSE:');
        console.log('Has Oscillation:', report.oscillation.hasOscillation ? 'âŒ' : 'âœ…');
        console.log('Repeating States:', report.oscillation.repeatingStates ? 'âŒ' : 'âœ…');
        console.log('Back-and-Forth Count:', report.oscillation.backAndForthCount);
        console.log('Unique States:', report.oscillation.uniqueStates);

        console.log('\nðŸ”† RING STABILITEIT ANALYSE:');
        console.log('Ring Stability:', report.ringStability.stable ? 'âœ…' : 'âŒ');
        console.log('Ring 0 Collapses:', report.ringStability.ring0Collapses);
        console.log('Ring 1 Collapses:', report.ringStability.ring1Collapses);
        console.log('Extreme Imbalances:', report.ringStability.extremeImbalances);
        console.log('Avg Ring 0 Occupancy:', report.ringStability.avgRing0.toFixed(2));
        console.log('Avg Ring 1 Occupancy:', report.ringStability.avgRing1.toFixed(2));

        console.log('\nðŸ†” IDENTITEIT PRESERVATIE ANALYSE:');
        console.log('Identity Preserved:', report.identityPreservation.preserved ? 'âœ…' : 'âŒ');
        console.log('Checksum Changes:', report.identityPreservation.checksumChanges);
        console.log('Identity Violations:', report.identityPreservation.identityViolations);
        console.log('Stable Checksum:', report.identityPreservation.stableChecksum);

        console.log('\n=== HEX-SEMANTISCHE INVARIANT COMPLIANCE ===');
        console.log('âœ“ Ring-balans: PUUR OBSERVATIONAL (geen afdwinging)');
        console.log('âœ“ Bezettingsgraad: GEMETEN zonder optimalisatie');  
        console.log('âœ“ Max modules per node: GEDETECTEERD maar niet afgedwongen');
        console.log('âœ“ Migratie-druk: BEREKEND zonder scheduler aanpassing');
        console.log('âœ“ OSInspector: RAPPORTEERD zonder beslissingslogica');

        // Save detailed report
        fs.writeFileSync('./hex_invariant_longrun_report.json', JSON.stringify(report, null, 2));
        console.log('\nðŸ“„ Detailed report saved to: hex_invariant_longrun_report.json');

        runtime.stop();

        if (report.summary.stable) {
            console.log('\nâœ… LANGE-TERMIJN TEST GESLAAGD');
            console.log('hexMHS toont stabiele hex-semantische eigenschappen over 72+ steps');
            console.log('Alle invarianten blijven observational zonder afdwinging');
        } else {
            console.log('\nâš ï¸  LANGE-TERMIJN TEST TOONT INSTABILITEIT');
            console.log('Issues require further investigation');
        }

    } catch (error) {
        console.error('âœ— Long-run test failed:', error.message);
        return false;
    }

    return true;
}

// Export for external use
module.exports = { testHexInvariantsLongRun, HexInvariantTracker };

// Run if called directly
if (require.main === module) {
    testHexInvariantsLongRun().catch(console.error);
}
