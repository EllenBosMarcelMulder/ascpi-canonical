/**
 * ORCHESTRATOR v1.0
 * Minimaal modulair verwerkingsskelet
 * Registreert modules, voert sequentieel uit
 * Geen wiskunde, semantiek of UI
 */

class Orchestrator {
    constructor() {
        this.modules = new Map();
        this.pipeline = [];
    }

    /**
     * Registreer een module met contract verificatie
     */
    registerModule(module) {
        // Verify module contract
        if (!module.id || !module.input_type || !module.output_type || typeof module.process !== 'function') {
            throw new Error(`Invalid module contract: ${module.id || 'unknown'}`);
        }
        
        this.modules.set(module.id, module);
        return this;
    }

    /**
     * Stel pipeline samen uit module IDs
     */
    setPipeline(moduleIds) {
        // Verify all modules exist
        for (const id of moduleIds) {
            if (!this.modules.has(id)) {
                throw new Error(`Module not found: ${id}`);
            }
        }
        
        // Verify type compatibility
        for (let i = 0; i < moduleIds.length - 1; i++) {
            const current = this.modules.get(moduleIds[i]);
            const next = this.modules.get(moduleIds[i + 1]);
            
            if (current.output_type !== next.input_type) {
                throw new Error(`Type mismatch: ${current.id}.${current.output_type} â†’ ${next.id}.${next.input_type}`);
            }
        }
        
        this.pipeline = moduleIds;
        return this;
    }

    /**
     * Voer pipeline sequentieel uit
     */
    async execute(input) {
        let data = input;
        const trace = [];
        
        for (const moduleId of this.pipeline) {
            const module = this.modules.get(moduleId);
            
            try {
                const output = await module.process(data);
                trace.push({
                    module: moduleId,
                    input_type: module.input_type,
                    output_type: module.output_type,
                    success: true
                });
                data = output;
            } catch (error) {
                trace.push({
                    module: moduleId,
                    input_type: module.input_type,
                    output_type: module.output_type,
                    success: false,
                    error: error.message
                });
                throw error;
            }
        }
        
        return {
            result: data,
            trace: trace
        };
    }

    /**
     * Haal geregistreerde modules op
     */
    getModules() {
        return Array.from(this.modules.keys());
    }

    /**
     * Haal huidige pipeline op
     */
    getPipeline() {
        return [...this.pipeline];
    }
}

module.exports = Orchestrator;
