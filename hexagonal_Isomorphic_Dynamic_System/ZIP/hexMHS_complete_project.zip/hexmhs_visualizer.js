// hexmhs_visualizer.js
class HexMHSVisualizer {
    constructor(runtime, visConfig) {
        this.runtime = runtime;
        this.visConfig = visConfig;
    }

    captureHexMHSState() {
        const runtimeState = this.runtime.getState();
        
        // Correct: use proper API contract
        const allStepResults = this.runtime.getStepResults();
        const lastStepResults = allStepResults[allStepResults.length - 1];
        
        // Extract hex topology and module allocation
        let hexTopology = null;
        let moduleAllocation = null;
        
        if (lastStepResults && lastStepResults.results) {
            for (const result of lastStepResults.results) {
                if (result.moduleId === 'HexTopology') {
                    hexTopology = result.outputs;
                }
                if (result.moduleId === 'ModuleRegistry') {
                    moduleAllocation = result.outputs;
                }
            }
        }
        
        return {
            runtime: runtimeState,
            topology: hexTopology,
            allocation: moduleAllocation,
            step: runtimeState.stepCount
        };
    }

    translateToCanonicalResult(hexMHSState) {
        // Translate hexMHS state to canonical psi format
        const psi = {
            dPhi: (hexMHSState.allocation?.loadedCount || 0) * 0.1,
            kappa: hexMHSState.runtime.connections || 1.0,
            theta: (hexMHSState.step * Math.PI / 6) % (2 * Math.PI),
            C: hexMHSState.runtime.running ? 0.9 : 0.1,
            N: hexMHSState.allocation?.hexPositions || 0,
            t: hexMHSState.step
        };
        
        return {
            psi: psi,
            output: `hexMHS Step ${hexMHSState.step}`,
            metadata: {
                modules: hexMHSState.runtime.loadedModules,
                connections: hexMHSState.runtime.connections,
                hexPositions: hexMHSState.allocation?.hexPositions || 0
            }
        };
    }

    renderSVG() {
        const hexMHSState = this.captureHexMHSState();
        const canonicalResult = this.translateToCanonicalResult(hexMHSState);
        
        // Use existing vis_svg_adapter
        const { renderSVG } = require('./vis_svg_adapter');
        return renderSVG(canonicalResult, this.visConfig);
    }

    renderHexBYEStructure() {
        const hexMHSState = this.captureHexMHSState();
        
        // Create hexBYE-compatible structure
        const structure = {
            nodes: [],
            relations: []
        };
        
        // Add hex positions as nodes with explicit coordinate conversion
        if (hexMHSState.topology && hexMHSState.topology.nodes) {
            hexMHSState.topology.nodes.forEach(pos => {
                // Explicit axial (q,r) to cartesian (x,y) conversion
                // Standard formula: x = size * (3/2 * q), y = size * (sqrt(3)/2 * (r + q/2))
                const size = 50;
                const x = size * (3/2 * pos.q) + 200;  // +200 for centering
                const y = size * (Math.sqrt(3)/2 * (pos.r + pos.q/2)) + 200;
                
                structure.nodes.push({
                    id: pos.id,
                    x: x,
                    y: y,
                    type: 'hex_position',
                    q: pos.q,     // Keep original axial coords
                    r: pos.r,
                    ring: pos.ring
                });
            });
        }
        
        // Add neighbor relations from hex topology
        if (hexMHSState.topology && hexMHSState.topology.neighbors) {
            for (const [nodeId, neighbors] of Object.entries(hexMHSState.topology.neighbors)) {
                if (Array.isArray(neighbors)) {
                    neighbors.forEach(neighborId => {
                        structure.relations.push({
                            from: parseInt(nodeId),
                            to: neighborId,
                            type: 'hex_neighbor'
                        });
                    });
                }
            }
        }
        
        return structure;
    }

    generateLiveVisualization() {
        return {
            svg: this.renderSVG(),
            structure: this.renderHexBYEStructure(),
            state: this.captureHexMHSState(),
            observerTime: Date.now()  // Explicit: this is adapter observation time, not OS time
        };
    }

    startLiveMonitoring(interval = 100) {
        return setInterval(() => {
            if (this.runtime.getState().running) {
                const currentVis = this.generateLiveVisualization();
                // Return visualization for external handling
                return currentVis;
            }
        }, interval);
    }

    stopLiveMonitoring(intervalId) {
        clearInterval(intervalId);
    }
}

module.exports = HexMHSVisualizer;
