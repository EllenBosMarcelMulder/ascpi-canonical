// vis_runtime.js
const VisConfig = require('./vis_config');

class VisRuntime {
    constructor(config = {}) {
        this.config = new VisConfig(config);
        this.state = 'STOPPED';
        this.artifactCount = 0;
    }

    async start() {
        this.state = 'RUNNING';
        this.artifactCount = 0;
    }

    async stop() {
        this.state = 'STOPPED';
    }

    async reset() {
        this.artifactCount = 0;
    }

    generateArtifact(type, canonicalResult) {
        if (this.state !== 'RUNNING') {
            throw new Error('Runtime not running');
        }

        this.artifactCount++;
        
        return {
            id: `artifact_${this.artifactCount}`,
            type: type,
            timestamp: Date.now(),
            canonical: canonicalResult
        };
    }

    updateConfig(newConfig) {
        this.config.update(newConfig);
    }

    getStatus() {
        return {
            state: this.state,
            artifactCount: this.artifactCount
        };
    }
}

module.exports = VisRuntime;