/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * FIELD-COMPILER CORE v1.2
 * Micro-canoniek conforme veld-transitie
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const CONST = Object.freeze({
    phi: (1 + Math.sqrt(5)) / 2,
    pi: Math.PI,
    tau: 2 * Math.PI,
    eps: 1e-12,
    kappa_min: 0.01,
    kappa_max: 10.0,
});

function hash(text) {
    let h = 0;
    for (let i = 0; i < text.length; i++) {
        const char = text.charCodeAt(i);
        h = ((h << 5) - h) + char;
        h |= 0;
    }
    return (Math.abs(h) % 1000) / 100 + 1.0;
}

function F(psi, config) {
    const K = config.K_coupling;

    const dPhi_dt = psi.kappa * config.alpha_phi;

    let kappa_dt = K * psi.dPhi;
    kappa_dt = Math.max(CONST.kappa_min - psi.kappa, Math.min(CONST.kappa_max - psi.kappa, kappa_dt));

    const theta_dt = K * psi.dPhi / psi.kappa;

    const N_dt = 0;
    
    const C_dt = psi.dPhi * config.alpha_c;
    
    const t_dt = 1;

    return {
        dPhi: dPhi_dt,
        kappa: kappa_dt,
        theta: theta_dt,
        N: N_dt,
        C: C_dt,
        t: t_dt,
    };
}

class Psi {
    constructor(dPhi = 0.0, kappa = 1.0, theta = 0.0, N = 1.0, C = 0.5, t = 0) {
        this.dPhi = dPhi; 
        this.kappa = kappa; 
        this.theta = theta; 
        this.N = N; 
        this.C = C; 
        this.t = t;
    }
    
    toJSON() {
        return {
            dPhi: this.dPhi,
            kappa: this.kappa,
            theta: this.theta,
            N: this.N,
            C: this.C,
            t: this.t
        };
    }

    static fromJSON(json) {
        return new Psi(json.dPhi, json.kappa, json.theta, json.N, json.C, json.t);
    }
}

class ASCPIEngine {
    constructor(config = {}) {
        this.config = {
            stepSize: 0.1,
            alpha_phi: 0.05,
            alpha_c: 0.05,
            beta_c: 0.5,
            K_coupling: 0.1,
            ...config
        };

        this.ψ = new Psi();
        this.history = [];
        this.stepCount = 0;
        this.originalInput = '';
    }

    step() {
        const dψ_dt = F(this.ψ, this.config);

        const dt = this.config.stepSize;
        this.ψ.dPhi += dψ_dt.dPhi * dt;
        this.ψ.kappa += dψ_dt.kappa * dt;
        this.ψ.theta = (this.ψ.theta + dψ_dt.theta * dt) % CONST.tau;
        this.ψ.C += dψ_dt.C * dt;
        this.ψ.t += dψ_dt.t * dt;

        this.history.push(this.ψ.toJSON());
        this.stepCount++;
    }

    rewriteCodeFromField(originalCode, psi) {
        const h = hash(originalCode).toFixed(0);
        
        return `/* ASCπ Field Compiler v1.2 */
/* Field State: dPhi=${psi.dPhi.toFixed(4)} kappa=${psi.kappa.toFixed(4)} theta=${psi.theta.toFixed(4)} C=${psi.C.toFixed(4)} N=${psi.N.toFixed(4)} t=${psi.t.toFixed(0)} */
const FNO_${h} = "${originalCode}";
return FNO_${h};
`;
    }

    process(input) {
        this.originalInput = input;
        
        const initialN = hash(input);
        const initialdPhi = (Math.random() - 0.5) * 2.0;
        this.ψ = new Psi(initialdPhi, 1.0, 0.0, initialN, 0.5, 0);

        this.step();

        const compiledOutput = this.rewriteCodeFromField(input, this.ψ);
        
        return {
            psi: this.ψ.toJSON(),
            output: compiledOutput,
            count: this.stepCount
        };
    }
}

const ASCPI_FIELD_COMPILER = {
    VERSION: '1.2.0',
    CANONICAL: true,
    PARADIGM: 'FIELD_COMPILER',
    
    CONST,
    
    Psi,
    ASCPIEngine,
    
    createEngine(config) {
        return new ASCPIEngine(config);
    },
    
    compile(input, config) {
        const engine = new ASCPIEngine(config);
        return engine.process(input);
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = ASCPI_FIELD_COMPILER;
}

if (typeof window !== 'undefined') {
    window.ASCPI_FIELD_COMPILER = ASCPI_FIELD_COMPILER;
}