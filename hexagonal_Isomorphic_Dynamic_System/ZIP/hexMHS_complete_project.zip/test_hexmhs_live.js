// test_hexmhs_live.js
/**
 * Test script: Canonical hexMHS OS + Live Visualization  
 * Loads hexMHS.os and validates consistent operation
 */

const { ModuleRuntime } = require('./module_runtime');
const ModuleLangCompiler = require('./module_lang_compiler');
const HexMHSVisualizer = require('./hexmhs_visualizer');

async function testHexMHSLive() {
    console.log('=== hexMHS Live Test ===');
    
    // 1. Setup runtime and compiler
    const runtime = new ModuleRuntime();
    const compiler = new ModuleLangCompiler();
    
    // 2. Inject system context
    runtime.setSystemContext('compiler', compiler);
    runtime.setSystemContext('runtime', runtime);
    
    // 3. Load canonical hexMHS.os
    console.log('Loading canonical hexMHS.os...');
    const fs = require('fs');
    const hexMHS_OS = fs.readFileSync('/mnt/user-data/outputs/hexMHS.os', 'utf8');
    
    // 4. Compile hexMHS OS
    console.log('Compiling hexMHS OS...');
    const compilation = compiler.compile(hexMHS_OS);
    console.log('Compiled modules:', compilation.modules.length);
    console.log('Program found:', compilation.program ? 'Yes' : 'No');
    
    // 5. Register all modules
    for (const mod of compilation.modules) {
        runtime.registerModule(mod.id, mod.execute);
        console.log('Registered module:', mod.id);
    }
    
    // 6. Load modules and setup connections based on program
    if (compilation.program) {
        console.log('Loading program modules...');
        for (const moduleId of compilation.program.uses) {
            runtime.loadModule(moduleId);
            console.log('Loaded module:', moduleId);
        }
        
        console.log('Setting up connections...');
        for (const connection of compilation.program.connections) {
            runtime.connect(
                connection.fromModule,
                connection.fromOutput,
                connection.toModule,
                connection.toInput
            );
            console.log(`Connected: ${connection.fromModule}.${connection.fromOutput} -> ${connection.toModule}.${connection.toInput}`);
        }
    }
    
    // 7. Start runtime
    runtime.start();
    console.log('Runtime started');
    
    // 8. Setup visualizer
    const visConfig = { 
        svg: { 
            width: 800, 
            height: 600,
            geometry: { hexRadius: 80 }
        } 
    };
    const visualizer = new HexMHSVisualizer(runtime, visConfig);
    
    // 9. Run several steps and capture visualizations
    console.log('\n=== Running hexMHS Steps - OS-Controlled Execution Test ===');
    
    for (let i = 0; i < 36; i++) {
        // Step the runtime (OS-time only)
        const stepResult = runtime.step();
        
        // Extract all module outputs for OS-controlled execution and migration analysis
        let clockOutput = null;
        let fieldOutput = null;
        let topologyOutput = null;
        let schedulerOutput = null;
        let registryOutput = null;
        let executionContextOutput = null;
        let migrationPlannerOutput = null;
        let migrationExecutorOutput = null;
        let inspectorOutput = null;
        
        if (stepResult && stepResult.results) {
            stepResult.results.forEach(result => {
                if (result.moduleId === 'CoreClock') {
                    clockOutput = result.outputs;
                }
                if (result.moduleId === 'ContextField') {
                    fieldOutput = result.outputs;
                }
                if (result.moduleId === 'HexTopology') {
                    topologyOutput = result.outputs;
                }
                if (result.moduleId === 'Scheduler') {
                    schedulerOutput = result.outputs;
                }
                if (result.moduleId === 'ModuleRegistry') {
                    registryOutput = result.outputs;
                }
                if (result.moduleId === 'ExecutionContext') {
                    executionContextOutput = result.outputs;
                }
                if (result.moduleId === 'MigrationPlanner') {
                    migrationPlannerOutput = result.outputs;
                }
                if (result.moduleId === 'MigrationExecutor') {
                    migrationExecutorOutput = result.outputs;
                }
                if (result.moduleId === 'OSInspector') {
                    inspectorOutput = result.outputs;
                }
            });
        }
        
        console.log(`Step ${i + 1}: version=${fieldOutput?.version || 'unknown'}`);
        
        // OS-controlled execution details
        if (registryOutput) {
            console.log(`  Policy: ${registryOutput.executionPolicy || 'unknown'}`);
        }
        
        // Migration planning details
        if (migrationPlannerOutput && migrationPlannerOutput.migrationPlan && migrationPlannerOutput.migrationPlan.length > 0) {
            console.log(`  Migration Plan: [${migrationPlannerOutput.migrationPlan.join(', ')}]`);
        }
        
        // Migration execution details
        if (migrationExecutorOutput && migrationExecutorOutput.appliedMigrations && migrationExecutorOutput.appliedMigrations.length > 0) {
            console.log(`  Applied Migrations: [${migrationExecutorOutput.appliedMigrations.join(', ')}]`);
            console.log(`  Updated Topology: ${migrationExecutorOutput.updatedTopology} nodes`);
        }
        
        // Topology summary
        if (topologyOutput && Object.keys(topologyOutput).length > 0) {
            const nodeCount = topologyOutput.nodes || 0;
            const ringCount = nodeCount <= 6 ? 1 : 2;
            console.log(`  Topology: ${nodeCount} nodes (${ringCount} rings)`);
        }
        
        // Inspector summary
        if (inspectorOutput && Object.keys(inspectorOutput).length > 0) {
            if (inspectorOutput.migrationSummary) {
                console.log(`  Migration Status: ${inspectorOutput.migrationSummary}`);
            }
            if (inspectorOutput.executionSummary) {
                console.log(`  Execution Status: ${inspectorOutput.executionSummary}`);
            }
        }
        
        console.log('');
    }
    
    // 10. Final state inspection
    console.log('\n=== Final State ===');
    const finalState = runtime.getState();
    const finalVis = visualizer.captureHexMHSState();
    
    console.log('Runtime State:', finalState);
    console.log('hexMHS State:', {
        topology: finalVis.topology ? 'Present' : 'Missing',
        allocation: finalVis.allocation ? 'Present' : 'Missing',
        step: finalVis.step
    });
    
    // 11. Inspect hex topology specifically
    if (finalVis.topology && finalVis.topology.nodes) {
        console.log('\n=== Hex Topology Validation ===');
        console.log('Hex nodes found:', finalVis.topology.nodes.length);
        finalVis.topology.nodes.forEach(node => {
            console.log(`  Node ${node.id}: q=${node.q}, r=${node.r}, ring=${node.ring}`);
        });
        console.log('Neighbor map:', Object.keys(finalVis.topology.neighbors || {}).length, 'entries');
    }
    
    // 12. Stop runtime
    runtime.stop();
    console.log('\nRuntime stopped');
    console.log('=== Test Complete ===');
}

// Run test
if (require.main === module) {
    testHexMHSLive().catch(console.error);
}

module.exports = { testHexMHSLive };
