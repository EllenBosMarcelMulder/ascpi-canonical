// hex_invariants_demo.js
/**
 * CONCEPTUELE DEMONSTRATIE: Hex-Semantische Invarianten
 * Toont wat de observational monitoring meet ZONDER afdwinging
 */

console.log('=== HEX-SEMANTISCHE INVARIANTEN DEMONSTRATIE ===\n');

class HexSemanticObserver {
    constructor() {
        // Hexfield: center (ring 0) + 6 ring positions (ring 1)
        this.topology = [
            { id: 0, q: 0, r: 0, ring: 0, capacity: 1 }, // Center
            { id: 1, q: 1, r: 0, ring: 1, capacity: 1 }, // Ring 1
            { id: 2, q: 0, r: 1, ring: 1, capacity: 1 },
            { id: 3, q: -1, r: 1, ring: 1, capacity: 1 },
            { id: 4, q: -1, r: 0, ring: 1, capacity: 1 },
            { id: 5, q: 0, r: -1, ring: 1, capacity: 1 },
            { id: 6, q: 1, r: -1, ring: 1, capacity: 1 }
        ];
        
        this.modules = ['HexTopology', 'Scheduler', 'OSInspector', 'HexInvariantMonitor'];
    }

    // âœ… OBSERVATIONAL: Ring-balans meten
    calculateRingBalance(allocation) {
        const ring0Count = Object.values(allocation).filter(node => node === 0).length;
        const ring1Count = Object.values(allocation).filter(node => node > 0).length;
        const totalModules = ring0Count + ring1Count;
        
        if (totalModules === 0) return 0;
        
        const ring0Ratio = ring0Count / totalModules;
        const ring1Ratio = ring1Count / totalModules;
        
        return ring1Ratio - ring0Ratio; // Balance difference
    }

    // âœ… OBSERVATIONAL: Bezettingsgraad per ring
    calculateOccupancyDegree(allocation) {
        const ring0Capacity = 1; // Only center node
        const ring1Capacity = 6; // 6 ring nodes
        
        const ring0Count = Object.values(allocation).filter(node => node === 0).length;
        const ring1Count = Object.values(allocation).filter(node => node > 0).length;
        
        return {
            ring0: ring0Count / ring0Capacity,  // 0.0 - 1.0
            ring1: ring1Count / ring1Capacity   // 0.0 - 1.0
        };
    }

    // âœ… OBSERVATIONAL: Max modules per node check
    checkMaxModulesPerNode(allocation) {
        const nodeOccupancy = {};
        
        Object.values(allocation).forEach(node => {
            nodeOccupancy[node] = (nodeOccupancy[node] || 0) + 1;
        });
        
        const maxModulesPerNode = 1; // hexMHS constraint
        const violations = Object.values(nodeOccupancy).filter(count => count > maxModulesPerNode);
        
        return {
            hasViolations: violations.length > 0,
            maxOccupancy: Math.max(...Object.values(nodeOccupancy)),
            violatedNodes: Object.keys(nodeOccupancy).filter(node => nodeOccupancy[node] > maxModulesPerNode)
        };
    }

    // âœ… OBSERVATIONAL: Migratie-druk (concentratie-verschil)
    calculateMigrationPressure(allocation) {
        const occupancy = this.calculateOccupancyDegree(allocation);
        
        // Pressure = density difference between rings
        return occupancy.ring0 - occupancy.ring1;
    }

    // âœ… OBSERVATIONAL: Deterministische checksum
    generateTopologyChecksum(allocation) {
        let checksum = 0;
        
        // Add topology contribution (constant)
        checksum += this.topology.length * 1000; // 7000
        
        // Add allocation contribution
        Object.entries(allocation).forEach(([module, node]) => {
            const moduleHash = module.length * 100; // Simple hash
            checksum += moduleHash + node;
        });
        
        return checksum;
    }

    // PURE OBSERVATIONAL MONITORING (no enforcement)
    observeInvariants(allocation) {
        return {
            ringBalance: this.calculateRingBalance(allocation),
            occupancyDegree: this.calculateOccupancyDegree(allocation),
            maxNodeCheck: this.checkMaxModulesPerNode(allocation),
            migrationPressure: this.calculateMigrationPressure(allocation),
            topologyChecksum: this.generateTopologyChecksum(allocation),
            
            // Observational flags (NO enforcement)
            flags: {
                balanceCritical: Math.abs(this.calculateRingBalance(allocation)) > 0.8,
                pressureHigh: Math.abs(this.calculateMigrationPressure(allocation)) > 0.5,
                hasViolations: this.checkMaxModulesPerNode(allocation).hasViolations
            }
        };
    }
}

// DEMONSTRATIE: Verschillende allocatie scenarios
const observer = new HexSemanticObserver();

console.log('ðŸ“Š HEX-SEMANTISCHE OBSERVATIONAL MONITORING:\n');

// Scenario 1: Balanced allocation
console.log('ðŸ”¹ SCENARIO 1: Balanced Allocation');
const balancedAllocation = {
    HexTopology: 0,         // Ring 0 (center)
    Scheduler: 1,           // Ring 1
    OSInspector: 2,         // Ring 1
    HexInvariantMonitor: 3  // Ring 1
};

const balanced = observer.observeInvariants(balancedAllocation);
console.log('Allocation:', JSON.stringify(balancedAllocation));
console.log('Ring Balance:', balanced.ringBalance.toFixed(3));
console.log('Ring 0 Occupancy:', balanced.occupancyDegree.ring0);
console.log('Ring 1 Occupancy:', balanced.occupancyDegree.ring1.toFixed(3));
console.log('Migration Pressure:', balanced.migrationPressure.toFixed(3));
console.log('Max Node Violations:', balanced.maxNodeCheck.hasViolations);
console.log('Topology Checksum:', balanced.topologyChecksum);
console.log('Balance Critical:', balanced.flags.balanceCritical ? 'âš ï¸' : 'âœ…');
console.log('');

// Scenario 2: Ring 0 concentration (high pressure)
console.log('ðŸ”¹ SCENARIO 2: Ring 0 Concentration');
const ring0Concentration = {
    HexTopology: 0,         // Ring 0
    Scheduler: 0,           // Ring 0 - VIOLATION!
    OSInspector: 1,         // Ring 1
    HexInvariantMonitor: 2  // Ring 1
};

const concentrated = observer.observeInvariants(ring0Concentration);
console.log('Allocation:', JSON.stringify(ring0Concentration));
console.log('Ring Balance:', concentrated.ringBalance.toFixed(3));
console.log('Ring 0 Occupancy:', concentrated.occupancyDegree.ring0); // > 1.0 = violation!
console.log('Ring 1 Occupancy:', concentrated.occupancyDegree.ring1.toFixed(3));
console.log('Migration Pressure:', concentrated.migrationPressure.toFixed(3));
console.log('Max Node Violations:', concentrated.maxNodeCheck.hasViolations ? 'âŒ' : 'âœ…');
console.log('Violated Nodes:', concentrated.maxNodeCheck.violatedNodes);
console.log('Pressure High:', concentrated.flags.pressureHigh ? 'âš ï¸' : 'âœ…');
console.log('');

// Scenario 3: Ring 1 spread (low pressure)
console.log('ðŸ”¹ SCENARIO 3: Ring 1 Distributed');
const ring1Distributed = {
    HexTopology: 1,         // Ring 1
    Scheduler: 2,           // Ring 1
    OSInspector: 3,         // Ring 1
    HexInvariantMonitor: 4  // Ring 1
};

const distributed = observer.observeInvariants(ring1Distributed);
console.log('Allocation:', JSON.stringify(ring1Distributed));
console.log('Ring Balance:', distributed.ringBalance.toFixed(3));
console.log('Ring 0 Occupancy:', distributed.occupancyDegree.ring0);
console.log('Ring 1 Occupancy:', distributed.occupancyDegree.ring1.toFixed(3));
console.log('Migration Pressure:', distributed.migrationPressure.toFixed(3));
console.log('Max Node Violations:', distributed.maxNodeCheck.hasViolations);
console.log('Balance Critical:', distributed.flags.balanceCritical ? 'âš ï¸' : 'âœ…');
console.log('');

console.log('=== OBSERVATIONAL vs ENFORCEMENT ===\n');

console.log('âœ… OBSERVATIONAL (TOEGESTAAN):');
console.log('  - Ring-balans berekenen (geen actie ondernemen)');
console.log('  - Bezettingsgraad meten (geen optimization)');
console.log('  - Violation flags detecteren (geen correctie)');
console.log('  - Migration pressure berekenen (geen auto-migration)');
console.log('  - Topology checksum genereren (geen validation)');
console.log('');

console.log('âŒ ENFORCEMENT (VERBODEN):');
console.log('  - Scheduler aanpassen op basis van ring-balans');
console.log('  - Automatic migration triggeren bij high pressure');
console.log('  - Module execution blokkeren bij violations');
console.log('  - Load balancing tussen rings afdwingen');
console.log('  - Topology "optimalization" uitvoeren');
console.log('');

console.log('ðŸŽ¯ CANONIEKE REGEL:');
console.log('"Hex-semantische invarianten zijn UITSLUITEND observational."');
console.log('"Ze documenteren wat ER IS, niet wat er ZOU MOETEN ZIJN."');
console.log('');

console.log('âœ… hexMHS implementeert PURE OBSERVATIONAL hex-semantics');
console.log('   zonder enige beslissingslogica of afdwinging.');
