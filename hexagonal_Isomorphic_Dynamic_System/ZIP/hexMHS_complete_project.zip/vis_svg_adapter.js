// ===============================
// vis_svg_adapter.js (AANGEPAST)
// ===============================

const VisConfig = require('./vis_config');

function applyMapping(value, map) {
    let v = value * (map.scaleFactor ?? 1.0);

    if (map.modulo !== null && map.modulo !== undefined) {
        v = v % map.modulo;
    }

    if (map.clampMin !== null && map.clampMin !== undefined) {
        v = Math.max(map.clampMin, v);
    }

    if (map.clampMax !== null && map.clampMax !== undefined) {
        v = Math.min(map.clampMax, v);
    }

    return v;
}

function renderSVG(canonicalResult, configOverrides = {}) {
    const config = new VisConfig(configOverrides);
    const { psi } = canonicalResult;
    const { svg } = config;

    const cx = svg.width / 2;
    const cy = svg.height / 2;

    const dPhiVal = applyMapping(psi.dPhi, svg.mapping.dPhi);
    const kappaVal = applyMapping(psi.kappa, svg.mapping.kappa);
    const thetaVal = applyMapping(psi.theta, svg.mapping.theta);
    const CVal = applyMapping(psi.C, svg.mapping.C);

    const baseRadius = svg.geometry.hexRadius * kappaVal;
    const rotation = thetaVal + svg.geometry.rotationOffset;

    const layers = svg.layering.enabled
        ? Math.min(
              svg.layering.maxLayers,
              Math.floor(Math.abs(psi.t) / svg.mapping.t.layerDivisor)
          )
        : 0;

    const hexPoints = (radius, rot) =>
        Array.from({ length: 6 }).map((_, i) => {
            const angle = rot + (Math.PI / 3) * i;
            const x = cx + radius * Math.cos(angle);
            const y = cy + radius * Math.sin(angle);
            return `${x},${y}`;
        }).join(' ');

    let content = '';

    for (let i = 0; i <= layers; i++) {
        const r = baseRadius * (1 - i * 0.05);
        const opacity = svg.style.opacityBase * CVal;

        content += `
        <polygon
            points="${hexPoints(r, rotation)}"
            stroke="${svg.style.strokeColor}"
            stroke-width="${svg.style.strokeWidth}"
            fill="${svg.style.fillColor}"
            opacity="${opacity}"
        />
        `;
    }

    return `
<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${svg.width}"
    height="${svg.height}"
    viewBox="0 0 ${svg.width} ${svg.height}"
>
    <rect width="100%" height="100%" fill="${svg.background}" />
    ${content}
</svg>
`;
}

function renderTimeline(snapshots, configOverrides = {}) {
    const config = new VisConfig(configOverrides);
    const { svg } = config.config;
    
    if (!snapshots || snapshots.length === 0) {
        return `<svg width="${svg.width}" height="${svg.height}" xmlns="http://www.w3.org/2000/svg">
                <rect width="100%" height="100%" fill="${svg.colors.background}"/>
                </svg>`;
    }

    let content = '';
    
    for (let i = 0; i < snapshots.length; i++) {
        const snapshot = snapshots[i];
        if (!snapshot.data || !snapshot.data.psi) continue;
        
        const psi = snapshot.data.psi;
        const timelineOpacity = (snapshots.length - i) / snapshots.length;
        
        const dPhiVal = applyMapping(psi.dPhi, svg.mapping.dPhi);
        const kappaVal = applyMapping(psi.kappa, svg.mapping.kappa);
        const thetaVal = applyMapping(psi.theta, svg.mapping.theta);
        const CVal = applyMapping(psi.C, svg.mapping.C);
        
        const baseRadius = svg.geometry.hexRadius * kappaVal;
        const rotation = thetaVal + svg.geometry.rotationOffset;
        
        const layers = svg.layering.enabled
            ? Math.min(
                  svg.layering.maxLayers,
                  Math.floor(Math.abs(psi.t) / svg.mapping.t.layerDivisor)
              )
            : 0;
        
        for (let j = 0; j <= layers; j++) {
            const r = baseRadius * (1 - j * 0.05);
            const opacity = svg.style.opacityBase * CVal * timelineOpacity;
            
            const hexPoints = Array.from({ length: 6 }).map((_, k) => {
                const angle = rotation + (Math.PI / 3) * k;
                const x = svg.centerX + r * Math.cos(angle);
                const y = svg.centerY + r * Math.sin(angle);
                return `${x},${y}`;
            }).join(' ');
            
            content += `<polygon
                       points="${hexPoints}"
                       stroke="${svg.style.strokeColor}"
                       stroke-width="${svg.style.strokeWidth}"
                       fill="${svg.style.fillColor}"
                       opacity="${opacity}"
                       />`;
        }
    }

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${svg.width}" height="${svg.height}" 
            viewBox="0 0 ${svg.width} ${svg.height}">
            <rect width="100%" height="100%" fill="${svg.colors.background}"/>
            ${content}
            </svg>`;
}

module.exports = {
    renderSVG,
    renderTimeline
};