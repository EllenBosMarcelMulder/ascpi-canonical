// adapter_runtime.js
/**
 * ADAPTER RUNTIME
 * Manages adapter lifecycle, state, caching, and monitoring
 */

class AdapterRuntime {
    constructor(config) {
        this.config = config;
        this.state = 'INITIALIZED';
        this.cache = new Map();
        this.metrics = new Map();
        this.logs = [];
        this.startTime = null;
    }

    async initialize() {
        this.state = 'INITIALIZING';
        this.startTime = Date.now();
        
        // Adapter decision: setup internal systems
        this._setupMetrics();
        this._setupLogRotation();
        this._setupCacheCleanup();
        
        this.state = 'READY';
        this.log('info', 'Runtime initialized successfully');
    }

    async shutdown() {
        this.state = 'SHUTTING_DOWN';
        
        // Adapter cleanup decisions
        this._clearTimers();
        this.clearCache();
        this._flushMetrics();
        
        this.state = 'STOPPED';
        this.log('info', 'Runtime shutdown completed');
    }

    // Caching operations (adapter freedom)
    getCache(key) {
        const entry = this.cache.get(key);
        if (!entry) return null;
        
        // Adapter decision: TTL enforcement
        if (Date.now() > entry.expires) {
            this.cache.delete(key);
            return null;
        }
        
        entry.hits++;
        return entry.value;
    }

    setCache(key, value, ttl = null) {
        if (!this.config.get('caching.enabled')) return;
        
        const actualTtl = ttl || this.config.get('caching.ttl');
        const entry = {
            value: value,
            created: Date.now(),
            expires: Date.now() + actualTtl,
            hits: 0
        };
        
        // Adapter decision: cache size management
        if (this.cache.size >= this.config.get('caching.maxSize')) {
            this._evictOldestCache();
        }
        
        this.cache.set(key, entry);
    }

    clearCache() {
        this.cache.clear();
        this.log('debug', 'Cache cleared');
    }

    getCacheStats() {
        const stats = {
            size: this.cache.size,
            maxSize: this.config.get('caching.maxSize'),
            totalHits: 0,
            entries: []
        };
        
        for (const [key, entry] of this.cache.entries()) {
            stats.totalHits += entry.hits;
            stats.entries.push({
                key: key,
                size: JSON.stringify(entry.value).length,
                hits: entry.hits,
                age: Date.now() - entry.created
            });
        }
        
        return stats;
    }

    // Metrics operations (adapter freedom)
    recordMetric(name, value) {
        if (!this.config.get('metrics.enabled')) return;
        
        if (!this.metrics.has(name)) {
            this.metrics.set(name, {
                count: 0,
                total: 0,
                min: Infinity,
                max: -Infinity,
                last: null
            });
        }
        
        const metric = this.metrics.get(name);
        metric.count++;
        metric.total += value;
        metric.min = Math.min(metric.min, value);
        metric.max = Math.max(metric.max, value);
        metric.last = value;
    }

    getMetrics() {
        const result = {};
        for (const [name, metric] of this.metrics.entries()) {
            result[name] = {
                ...metric,
                average: metric.count > 0 ? metric.total / metric.count : 0
            };
        }
        return result;
    }

    // Logging operations (adapter freedom)
    log(level, message, data = null) {
        if (!this._shouldLog(level)) return;
        
        const entry = {
            timestamp: new Date().toISOString(),
            level: level,
            message: message,
            data: data
        };
        
        // Adapter decision: log storage and rotation
        this.logs.push(entry);
        if (this.logs.length > 10000) {
            this.logs = this.logs.slice(-5000);
        }
        
        // Adapter decision: log output format
        if (this.config.get('logging.destination') === 'console') {
            const formatted = this._formatLogEntry(entry);
            console.log(formatted);
        }
    }

    getLogs(level = null, limit = 100) {
        let logs = this.logs;
        
        if (level) {
            logs = logs.filter(log => log.level === level);
        }
        
        return logs.slice(-limit);
    }

    // Private helper methods
    _setupMetrics() {
        if (!this.config.get('metrics.enabled')) return;
        
        this.metricsTimer = setInterval(() => {
            this._flushMetrics();
        }, this.config.get('metrics.flushInterval'));
    }

    _setupLogRotation() {
        this.logRotationTimer = setInterval(() => {
            const retention = this.config.get('metrics.retention');
            const cutoff = Date.now() - retention;
            this.logs = this.logs.filter(log => new Date(log.timestamp).getTime() > cutoff);
        }, 3600000); // Every hour
    }

    _setupCacheCleanup() {
        if (!this.config.get('caching.enabled')) return;
        
        this.cacheCleanupTimer = setInterval(() => {
            const now = Date.now();
            for (const [key, entry] of this.cache.entries()) {
                if (now > entry.expires) {
                    this.cache.delete(key);
                }
            }
        }, 60000); // Every minute
    }

    _clearTimers() {
        if (this.metricsTimer) clearInterval(this.metricsTimer);
        if (this.logRotationTimer) clearInterval(this.logRotationTimer);
        if (this.cacheCleanupTimer) clearInterval(this.cacheCleanupTimer);
    }

    _flushMetrics() {
        // Adapter decision: metrics persistence (placeholder)
        this.log('debug', 'Metrics flushed', this.getMetrics());
    }

    _evictOldestCache() {
        let oldestKey = null;
        let oldestTime = Infinity;
        
        for (const [key, entry] of this.cache.entries()) {
            if (entry.created < oldestTime) {
                oldestTime = entry.created;
                oldestKey = key;
            }
        }
        
        if (oldestKey) {
            this.cache.delete(oldestKey);
        }
    }

    _shouldLog(level) {
        const levels = ['debug', 'info', 'warn', 'error'];
        const configLevel = this.config.get('logging.level');
        return levels.indexOf(level) >= levels.indexOf(configLevel);
    }

    _formatLogEntry(entry) {
        if (this.config.get('logging.format') === 'json') {
            return JSON.stringify(entry);
        }
        
        let formatted = `[${entry.timestamp}] ${entry.level.toUpperCase()}: ${entry.message}`;
        if (entry.data) {
            formatted += ` | ${JSON.stringify(entry.data)}`;
        }
        return formatted;
    }

    getStatus() {
        return {
            state: this.state,
            uptime: this.startTime ? Date.now() - this.startTime : 0,
            cache: this.getCacheStats(),
            metrics: Object.keys(this.getMetrics()).length,
            logs: this.logs.length
        };
    }
}

module.exports = AdapterRuntime;