class ModuleContract {
    constructor(id, execute, init = null, destroy = null) {
        this.id = id;
        this.execute = execute;
        this.init = init;
        this.destroy = destroy;
        this.state = 'registered';
        this.data = {};
    }
}

class ModuleRegistry {
    constructor() {
        this.modules = new Map();
        this.loadOrder = [];
    }

    register(moduleContract) {
        if (this.modules.has(moduleContract.id)) {
            throw new Error(`Module ${moduleContract.id} already registered`);
        }
        this.modules.set(moduleContract.id, moduleContract);
        return true;
    }

    unregister(moduleId) {
        const module = this.modules.get(moduleId);
        if (!module) return false;
        
        if (module.state === 'loaded' && module.destroy) {
            module.destroy(module.data);
        }
        
        this.modules.delete(moduleId);
        const orderIndex = this.loadOrder.indexOf(moduleId);
        if (orderIndex !== -1) {
            this.loadOrder.splice(orderIndex, 1);
        }
        return true;
    }

    get(moduleId) {
        return this.modules.get(moduleId);
    }

    getLoaded() {
        return this.loadOrder.map(id => this.modules.get(id));
    }

    load(moduleId) {
        const module = this.modules.get(moduleId);
        if (!module) return false;
        if (module.state === 'loaded') return true;

        if (module.init) {
            module.init(module.data);
        }
        module.state = 'loaded';
        this.loadOrder.push(moduleId);
        return true;
    }

    unload(moduleId) {
        const module = this.modules.get(moduleId);
        if (!module || module.state !== 'loaded') return false;

        if (module.destroy) {
            module.destroy(module.data);
        }
        module.state = 'registered';
        module.data = {};
        
        const orderIndex = this.loadOrder.indexOf(moduleId);
        if (orderIndex !== -1) {
            this.loadOrder.splice(orderIndex, 1);
        }
        return true;
    }
}

class ModuleRuntime {
    constructor() {
        this.registry = new ModuleRegistry();
        this.contextHistory = [{}];
        this.stepCount = 0;
        this.running = false;
        this.stepResults = [];
        this.connections = new Map();
        this.previousOutputs = new Map();
        this.systemContext = {};
    }

    registerModule(id, executeFn, initFn = null, destroyFn = null) {
        const contract = new ModuleContract(id, executeFn, initFn, destroyFn);
        return this.registry.register(contract);
    }

    loadModule(moduleId) {
        return this.registry.load(moduleId);
    }

    unloadModule(moduleId) {
        const result = this.registry.unload(moduleId);
        if (result) {
            this.connections.delete(moduleId);
            this.previousOutputs.delete(moduleId);
            for (const [targetModule, inputs] of this.connections.entries()) {
                for (const [inputKey, connection] of Object.entries(inputs)) {
                    if (connection.fromModule === moduleId) {
                        delete inputs[inputKey];
                    }
                }
            }
        }
        return result;
    }

    removeModule(moduleId) {
        return this.registry.unregister(moduleId);
    }

    connect(fromModuleId, outputKey, toModuleId, inputKey) {
        if (!this.registry.get(fromModuleId) || !this.registry.get(toModuleId)) {
            throw new Error('Cannot connect non-existent modules');
        }
        
        if (!this.connections.has(toModuleId)) {
            this.connections.set(toModuleId, {});
        }
        
        this.connections.get(toModuleId)[inputKey] = {
            fromModule: fromModuleId,
            outputKey: outputKey
        };
        
        return true;
    }

    disconnect(toModuleId, inputKey) {
        const moduleConnections = this.connections.get(toModuleId);
        if (moduleConnections && moduleConnections[inputKey]) {
            delete moduleConnections[inputKey];
            return true;
        }
        return false;
    }

    getConnections() {
        const result = {};
        for (const [moduleId, inputs] of this.connections.entries()) {
            result[moduleId] = { ...inputs };
        }
        return result;
    }

    setSystemContext(key, value) {
        this.systemContext[key] = value;
    }

    calculateModuleInputs(moduleId, externalInput) {
        const moduleInputs = { external: externalInput };
        const connections = this.connections.get(moduleId);
        
        if (connections) {
            for (const [inputKey, connection] of Object.entries(connections)) {
                const sourceOutputs = this.previousOutputs.get(connection.fromModule);
                if (sourceOutputs && sourceOutputs.hasOwnProperty(connection.outputKey)) {
                    moduleInputs[inputKey] = sourceOutputs[connection.outputKey];
                }
            }
        }
        
        return moduleInputs;
    }

    updateContext(contextDelta) {
        const currentContext = this.contextHistory[this.contextHistory.length - 1];
        const mergedContext = { ...currentContext, ...this.systemContext, ...contextDelta };
        this.contextHistory.push(mergedContext);
        return true;
    }

    getCurrentContext() {
        const currentContext = this.contextHistory[this.contextHistory.length - 1];
        return { ...currentContext, ...this.systemContext };
    }

    validateResult(result, moduleId) {
        if (!result || typeof result !== 'object') {
            throw new Error(`Module ${moduleId} returned invalid result format`);
        }
        
        if (!result.hasOwnProperty('outputs')) {
            throw new Error(`Module ${moduleId} missing outputs field`);
        }
        
        if (!result.hasOwnProperty('contextDelta')) {
            throw new Error(`Module ${moduleId} missing contextDelta field`);
        }
        
        if (!result.hasOwnProperty('signals')) {
            throw new Error(`Module ${moduleId} missing signals field`);
        }
        
        if (typeof result.outputs !== 'object' || result.outputs === null) {
            throw new Error(`Module ${moduleId} outputs must be an object`);
        }
        
        if (typeof result.contextDelta !== 'object' || result.contextDelta === null) {
            throw new Error(`Module ${moduleId} contextDelta must be an object`);
        }
        
        return true;
    }

    step(input = null) {
        if (!this.running) return null;
        
        const currentContext = this.getCurrentContext();
        const stepResults = [];
        const loadedModules = this.registry.getLoaded();
        const currentStepOutputs = new Map();
        
        let aggregatedContextDelta = {};
        
        for (const module of loadedModules) {
            const moduleInputs = this.calculateModuleInputs(module.id, input);
            
            const executionContext = {
                input: moduleInputs,
                context: currentContext,
                moduleData: { ...module.data },
                stepCount: this.stepCount,
                setData: (key, value) => { module.data[key] = value; },
                getData: (key) => module.data[key]
            };
            
            const result = module.execute(executionContext);
            
            this.validateResult(result, module.id);
            
            Object.assign(aggregatedContextDelta, result.contextDelta);
            currentStepOutputs.set(module.id, result.outputs);
            
            stepResults.push({
                moduleId: module.id,
                outputs: result.outputs,
                signals: result.signals,
                step: this.stepCount
            });
        }
        
        this.previousOutputs = currentStepOutputs;
        
        if (Object.keys(aggregatedContextDelta).length > 0) {
            this.updateContext(aggregatedContextDelta);
        }
        
        this.stepCount++;
        this.stepResults.push({
            step: this.stepCount - 1,
            results: stepResults
        });
        
        return {
            step: this.stepCount - 1,
            results: stepResults
        };
    }

    start() {
        this.running = true;
        return true;
    }

    stop() {
        this.running = false;
        return true;
    }

    getState() {
        return {
            running: this.running,
            stepCount: this.stepCount,
            loadedModules: this.registry.loadOrder.length,
            totalModules: this.registry.modules.size,
            contextVersion: this.contextHistory.length - 1,
            connections: Object.keys(this.getConnections()).length
        };
    }

    getStepResults(fromStep = 0, toStep = null) {
        const endStep = toStep || this.stepResults.length - 1;
        return this.stepResults.slice(fromStep, endStep + 1);
    }

    reset() {
        this.stop();
        
        for (const moduleId of [...this.registry.loadOrder]) {
            this.unloadModule(moduleId);
        }
        
        this.registry = new ModuleRegistry();
        this.contextHistory = [{}];
        this.stepCount = 0;
        this.stepResults = [];
        this.connections = new Map();
        this.previousOutputs = new Map();
        this.systemContext = {};
        return true;
    }
}

module.exports = { ModuleRuntime, ModuleContract, ModuleRegistry };