/**
 * LAAG 3 - VISUALISATIE
 * visualization.js - DOM manipulation only, no logic
 */

function updateStructurePanel(summary) {
    const nodeCountEl = document.getElementById('structureNodeCount');
    const relationCountEl = document.getElementById('structureRelationCount');
    const densityEl = document.getElementById('densityValue');
    const panelEl = document.getElementById('structurePanel');
    
    if (nodeCountEl) nodeCountEl.textContent = summary.nodeCount;
    if (relationCountEl) relationCountEl.textContent = summary.relationCount;
    if (densityEl) densityEl.textContent = summary.density.toFixed(2);
    
    if (panelEl) panelEl.classList.add('visible');
}

function updateComparisonStatus(comparisonResult) {
    const statusEl = document.getElementById('comparisonStatus');
    if (!statusEl) return;
    
    statusEl.textContent = comparisonResult.status;
    
    // Clear existing classes
    statusEl.classList.remove('identical', 'different', 'none');
    
    // Add appropriate class
    if (comparisonResult.status === 'IDENTIEK') {
        statusEl.classList.add('identical');
    } else if (comparisonResult.status === 'AFWIJKING') {
        statusEl.classList.add('different');
    } else {
        statusEl.classList.add('none');
    }
}

function clearDifferenceMarkers() {
    const container = document.getElementById('previewContainer');
    if (container) {
        container.querySelectorAll('[data-difference="true"]').forEach(el => el.remove());
    }
}

function addDifferenceMarkers(diffObjects) {
    const container = document.getElementById('previewContainer');
    if (!container) return;
    
    const preview = container.querySelector('.image-preview');
    if (!preview) return;
    
    diffObjects.markers.forEach(marker => {
        const markerEl = document.createElement('div');
        markerEl.className = marker.style || 'diff-node-marker';
        markerEl.dataset.difference = 'true';
        markerEl.dataset.type = marker.type;
        
        // Position marker based on original position
        const rect = preview.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        
        // Simple positioning - may need currentImage reference
        markerEl.style.position = 'absolute';
        markerEl.style.left = marker.position.x + 'px';
        markerEl.style.top = marker.position.y + 'px';
        markerEl.style.transform = 'translate(-50%, -50%)';
        
        container.appendChild(markerEl);
    });
}

function renderDifferences(diffObjects) {
    clearDifferenceMarkers();
    if (diffObjects.markers.length > 0) {
        addDifferenceMarkers(diffObjects);
    }
}
