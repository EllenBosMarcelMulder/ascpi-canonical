/**
 * LAAG 2 - MEETUITKOMSTEN
 * invariance-tester.js - test deterministic operation
 */

function testInvariance(imageData, width, height, iterations = 3) {
    const results = [];
    
    for (let i = 0; i < iterations; i++) {
        const fieldState = hexByeExtract(imageData, width, height);
        const hash = generateStructureHash(fieldState);
        results.push({
            iteration: i,
            hash,
            nodeCount: fieldState.nodes.length,
            relationCount: fieldState.relations.length
        });
    }
    
    // Check if all hashes are identical
    const firstHash = results[0].hash;
    const allIdentical = results.every(result => result.hash === firstHash);
    
    return {
        passed: allIdentical,
        iterations: iterations,
        results: results,
        variance: allIdentical ? 0 : calculateVariance(results)
    };
}

function calculateVariance(results) {
    const nodeCounts = results.map(r => r.nodeCount);
    const relationCounts = results.map(r => r.relationCount);
    
    const nodeVariance = variance(nodeCounts);
    const relationVariance = variance(relationCounts);
    
    return {
        nodeVariance,
        relationVariance,
        totalVariance: nodeVariance + relationVariance
    };
}

function variance(arr) {
    const mean = arr.reduce((sum, val) => sum + val, 0) / arr.length;
    const squaredDiffs = arr.map(val => Math.pow(val - mean, 2));
    return squaredDiffs.reduce((sum, val) => sum + val, 0) / arr.length;
}
