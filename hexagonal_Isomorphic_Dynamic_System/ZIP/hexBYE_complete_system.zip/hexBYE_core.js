/**
 * LAAG 0 - CANONIEKE KERN
 * hexBYE core extraction logic - isolated from hexBYE_2D
 * visibility → structure → nodes, relations, hash
 */

function hexByeExtract(pixelBuffer, width, height, options = {}) {
    // IMMUTABLE CANONICAL CONSTANTS - readonly during execution
    const SCALE = Object.freeze(40);              // Fixed scale - never modified
    const EDGE_THRESHOLD = Object.freeze(20);     // Sobel threshold - sensor constant
    const MAX_HEX_DISTANCE = Object.freeze(3);    // Relation distance limit

    // Convert to luminance
    const luminance = new Float32Array(width * height);
    for (let i = 0; i < pixelBuffer.length; i += 4) {
        luminance[i / 4] = 
            0.2126 * pixelBuffer[i] +     // R
            0.7152 * pixelBuffer[i + 1] + // G
            0.0722 * pixelBuffer[i + 2];  // B
    }

    // Edge detection (Sobel operator)
    const edges = new Uint8Array(width * height);
    for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
            const i = y * width + x;
            
            // Sobel X kernel
            const gx = 
                -luminance[i - width - 1] - 2 * luminance[i - 1] - luminance[i + width - 1] +
                 luminance[i - width + 1] + 2 * luminance[i + 1] + luminance[i + width + 1];
            
            // Sobel Y kernel
            const gy = 
                -luminance[i - width - 1] - 2 * luminance[i - width] - luminance[i - width + 1] +
                 luminance[i + width - 1] + 2 * luminance[i + width] + luminance[i + width + 1];
            
            const magnitude = Math.sqrt(gx * gx + gy * gy);
            edges[i] = magnitude > EDGE_THRESHOLD ? 1 : 0;
        }
    }

    // Cluster connected components
    const visited = new Uint8Array(width * height);
    const clusters = [];

    for (let i = 0; i < edges.length; i++) {
        if (edges[i] && !visited[i]) {
            const stack = [i];
            let sumX = 0, sumY = 0, count = 0;

            while (stack.length) {
                const p = stack.pop();
                if (visited[p]) continue;
                
                visited[p] = 1;
                const x = p % width;
                const y = Math.floor(p / width);
                sumX += x;
                sumY += y;
                count++;

                // Check 8-connected neighbors
                for (let dy = -1; dy <= 1; dy++) {
                    for (let dx = -1; dx <= 1; dx++) {
                        const nx = x + dx;
                        const ny = y + dy;
                        if (nx >= 0 && ny >= 0 && nx < width && ny < height) {
                            const ni = ny * width + nx;
                            if (edges[ni] && !visited[ni]) {
                                stack.push(ni);
                            }
                        }
                    }
                }
            }

            // Preserve all clusters - no filtering
            clusters.push({
                x: sumX / count,
                y: sumY / count,
                size: count
            });
        }
    }

    // Map to hex coordinates using immutable scale
    const nodes = clusters.map((cluster, i) => ({
        id: `n${i}`,
        position: {
            q: Math.round(cluster.x / SCALE),
            r: Math.round(cluster.y / SCALE)
        },
        properties: {
            type: "extracted",
            cluster_size: cluster.size,
            original_position: {
                x: cluster.x,
                y: cluster.y
            }
        }
    }));

    // Generate relations based on proximity using immutable distance
    const relations = [];

    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
            const a = nodes[i].position;
            const b = nodes[j].position;
            
            // Calculate hex distance
            const distance = (Math.abs(a.q - b.q) + 
                            Math.abs(a.q + a.r - b.q - b.r) + 
                            Math.abs(a.r - b.r)) / 2;

            if (distance <= MAX_HEX_DISTANCE) {
                const visibility = distance <= 1 ? 3 : 
                                 distance <= 2 ? 2 : 1;
                relations.push({
                    a: nodes[i].id,
                    b: nodes[j].id,
                    visibility,
                    properties: {
                        type: "structural",
                        distance: distance
                    }
                });
            }
        }
    }

    const fieldState = {
        topology: "hexagonal",
        meta: {
            phase: "hexBYE",
            version: "1.0.0",
            source: "visibility_extraction",
            dimensions: { width, height },
            scale: SCALE,
            scale_invariant: true,
            constants_immutable: true
        },
        nodes,
        relations,
        crossed_link: {
            method_identity: "hexBYE ∘ P ∘ hexBYE",
            projector_spec: {
                type: "deterministic_code_projection",
                geometry: "hex_axial_to_visible",
                scale: SCALE,
                rotation: 0,
                translation: "centered",
                decision_free: true
            },
            invariant_claim: "hexBYE(P(F)) ≡ F",
            normalization: {
                node_order: ["q", "r"],
                relation_order: ["a", "b"],
                ignore: ["timestamps", "ui", "labels"]
            },
            validation_mode: "structural_identity_only"
        },
        validation: {
            invariants: [
                "non_decisional",
                "no_time_authority",
                "crossed_link_neutral",
                "structurally_correspondent"
            ]
        }
    };

    // Passthrough optional metadata
    if (options.z_lift_spec) {
        fieldState.z_lift_spec = options.z_lift_spec;
    }

    if (options.visibility_field) {
        fieldState.visibility_field = options.visibility_field;
    }

    return fieldState;
}

function generateStructureHash(fieldState) {
    const hashData = {
        nodeCount: fieldState.nodes.length,
        relationCount: fieldState.relations.length,
        nodePositions: fieldState.nodes.map(n => `${n.position.q},${n.position.r}`).sort(),
        relationPairs: fieldState.relations.map(r => `${r.a}:${r.b}`).sort()
    };
    return btoa(JSON.stringify(hashData));
}
