# hexBYE Instrument

## Wat is dit?
Lokaal meetinstrument voor structuurextractie uit afbeeldingen.

## Wat doet één handeling?
1. Open `hexBYE_2D_recombined.html`
2. Upload afbeelding
3. Klik "EXTRACT STRUCTURE"

## Wat krijg je terug?
- **Structure Summary**: Node count, relation count, density
- **Oordeel**: IDENTIEK / AFWIJKING / NIET VERGELIJKBAAR  
- **Visuele aanwijzing**: Rode markers bij AFWIJKING

## Wat doet het expliciet niet?
- Geen AI of machine learning
- Geen interpretatie of betekenis
- Geen cloud of externe verbindingen
- Geen beslissingen nemen

Zelfde input = exact zelfde output.
