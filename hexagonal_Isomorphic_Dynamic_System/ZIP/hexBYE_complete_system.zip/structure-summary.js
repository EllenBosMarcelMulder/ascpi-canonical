/**
 * LAAG 2 - MEETUITKOMSTEN
 * structure-summary.js - count nodes, relations, density
 */

function calculateStructureSummary(fieldState) {
    if (!fieldState || !fieldState.nodes || !fieldState.relations) {
        return {
            nodeCount: 0,
            relationCount: 0,
            density: 0
        };
    }

    const nodeCount = fieldState.nodes.length;
    const relationCount = fieldState.relations.length;
    
    // Calculate density
    let density = 0;
    if (nodeCount > 1) {
        const maxPossibleRelations = (nodeCount * (nodeCount - 1)) / 2;
        density = relationCount / maxPossibleRelations;
    }

    return {
        nodeCount,
        relationCount,
        density
    };
}
