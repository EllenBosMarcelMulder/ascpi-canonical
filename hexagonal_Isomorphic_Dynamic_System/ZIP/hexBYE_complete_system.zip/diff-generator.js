/**
 * LAAG 2 - MEETUITKOMSTEN  
 * diff-generator.js - generate diff objects for visualization
 */

function generateDiffObjects(comparisonResult) {
    if (!comparisonResult.differences) {
        return {
            markers: [],
            highlights: []
        };
    }
    
    const markers = [];
    const highlights = [];
    
    // Generate markers for new nodes
    if (comparisonResult.differences.newNodes) {
        comparisonResult.differences.newNodes.forEach(node => {
            if (node.properties && node.properties.original_position) {
                markers.push({
                    type: 'new-node',
                    position: node.properties.original_position,
                    nodeId: node.id,
                    style: 'diff-node-marker'
                });
            }
        });
    }
    
    // Generate markers for missing nodes
    if (comparisonResult.differences.missingNodes) {
        comparisonResult.differences.missingNodes.forEach(node => {
            if (node.properties && node.properties.original_position) {
                markers.push({
                    type: 'missing-node',
                    position: node.properties.original_position,
                    nodeId: node.id,
                    style: 'diff-missing-marker'
                });
            }
        });
    }
    
    return {
        markers,
        highlights,
        summary: {
            newNodeCount: comparisonResult.differences.newNodes ? comparisonResult.differences.newNodes.length : 0,
            missingNodeCount: comparisonResult.differences.missingNodes ? comparisonResult.differences.missingNodes.length : 0,
            nodeCountDiff: comparisonResult.differences.nodeCountDiff || 0,
            relationCountDiff: comparisonResult.differences.relationCountDiff || 0
        }
    };
}
