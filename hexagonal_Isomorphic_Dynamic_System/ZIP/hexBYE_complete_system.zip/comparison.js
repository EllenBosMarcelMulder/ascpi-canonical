/**
 * LAAG 2 - MEETUITKOMSTEN
 * comparison.js - compare structures, generate judgment
 */

function compareStructures(currentStructure, previousStructure) {
    if (!previousStructure) {
        return {
            status: 'NIET VERGELIJKBAAR',
            identical: false,
            differences: null
        };
    }

    const isIdentical = structuresIdentical(currentStructure, previousStructure);
    
    if (isIdentical) {
        return {
            status: 'IDENTIEK',
            identical: true,
            differences: null
        };
    } else {
        const differences = findDifferences(currentStructure, previousStructure);
        return {
            status: 'AFWIJKING',
            identical: false,
            differences: differences
        };
    }
}

function structuresIdentical(struct1, struct2) {
    // Compare node counts
    if (struct1.nodes.length !== struct2.nodes.length) return false;
    
    // Compare relation counts
    if (struct1.relations.length !== struct2.relations.length) return false;
    
    // Compare node positions (simplified check)
    const positions1 = struct1.nodes.map(n => `${n.position.q},${n.position.r}`).sort();
    const positions2 = struct2.nodes.map(n => `${n.position.q},${n.position.r}`).sort();
    
    for (let i = 0; i < positions1.length; i++) {
        if (positions1[i] !== positions2[i]) return false;
    }
    
    return true;
}

function findDifferences(current, previous) {
    const currentPositions = current.nodes.map(n => `${n.position.q},${n.position.r}`);
    const previousPositions = previous.nodes.map(n => `${n.position.q},${n.position.r}`);
    
    const newNodes = [];
    const missingNodes = [];
    
    // Find nodes that exist in current but not in previous
    current.nodes.forEach(node => {
        const nodePos = `${node.position.q},${node.position.r}`;
        if (!previousPositions.includes(nodePos)) {
            newNodes.push(node);
        }
    });
    
    // Find nodes that exist in previous but not in current
    previous.nodes.forEach(node => {
        const nodePos = `${node.position.q},${node.position.r}`;
        if (!currentPositions.includes(nodePos)) {
            missingNodes.push(node);
        }
    });
    
    return {
        newNodes,
        missingNodes,
        nodeCountDiff: current.nodes.length - previous.nodes.length,
        relationCountDiff: current.relations.length - previous.relations.length
    };
}
