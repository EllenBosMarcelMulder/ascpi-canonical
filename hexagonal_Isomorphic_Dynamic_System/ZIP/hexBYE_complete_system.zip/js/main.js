/**
 * hexBYE Main Coordinator
 * Orchestrates all modules of the hexBYE measurement instrument
 * Maintains non-decisional, deterministic operation across all components
 */

class HexByeInstrument {
    constructor() {
        this.version = '1.0.0';
        this.initialized = false;
        
        // Core modules
        this.structureExtractor = null;
        this.invarianceTester = null;
        
        // UI modules
        this.imageHandler = null;
        this.visualization = null;
        this.comparison = null;
        this.snapshots = null;
        
        // State
        this.currentProcessing = false;
        this.lastStructure = null;
        this.instrumentReady = false;
    }

    /**
     * Initialize the instrument
     */
    async initialize() {
        try {
            this.showStatus('Initializing hexBYE instrument...', 'processing');
            
            // Initialize core modules
            this.structureExtractor = new StructureExtractor();
            this.invarianceTester = new InvarianceTester();
            
            // Initialize UI modules
            this.imageHandler = new ImageHandler();
            this.visualization = new Visualization();
            this.comparison = new Comparison();
            this.snapshots = new Snapshots();
            
            // Setup cross-module dependencies
            this.setupModuleConnections();
            
            // Initialize UI modules
            await this.initializeUIModules();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Validate instrument readiness
            this.validateInstrument();
            
            // Mark as initialized
            this.initialized = true;
            this.instrumentReady = true;
            
            this.showStatus('hexBYE instrument ready', 'success');
            this.updateInvariantIndicator('ready');
            
            // Log initialization
            console.log('hexBYE Instrument initialized successfully');
            console.log('Version:', this.version);
            console.log('Modules loaded:', {
                structureExtractor: !!this.structureExtractor,
                invarianceTester: !!this.invarianceTester,
                imageHandler: !!this.imageHandler,
                visualization: !!this.visualization,
                comparison: !!this.comparison,
                snapshots: !!this.snapshots
            });
            
        } catch (error) {
            console.error('Failed to initialize hexBYE instrument:', error);
            this.showStatus('Initialization failed', 'error');
        }
    }

    /**
     * Setup connections between modules
     */
    setupModuleConnections() {
        // Make imageHandler globally accessible for other modules
        window.imageHandler = this.imageHandler;
        window.visualization = this.visualization;
        
        // Pass structure extractor to comparison module
        this.comparison.initialize(this.structureExtractor);
    }

    /**
     * Initialize UI modules
     */
    async initializeUIModules() {
        this.imageHandler.initialize();
        this.visualization.initialize();
        this.snapshots.initialize();
    }

    /**
     * Setup global event listeners
     */
    setupEventListeners() {
        // Structure extraction
        const extractBtn = document.getElementById('extractBtn');
        if (extractBtn) {
            extractBtn.addEventListener('click', () => this.extractStructure());
        }

        // Invariance testing
        const testInvariance = document.getElementById('testInvariance');
        if (testInvariance) {
            testInvariance.addEventListener('click', () => this.testInvariance());
        }

        // Window resize handling
        window.addEventListener('resize', () => this.handleResize());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));

        // Error handling
        window.addEventListener('error', (e) => this.handleError(e));
        window.addEventListener('unhandledrejection', (e) => this.handleError(e));
    }

    /**
     * Extract structure from current image
     */
    async extractStructure() {
        if (this.currentProcessing) {
            this.showStatus('Processing already in progress', 'error');
            return;
        }

        const currentImage = this.imageHandler.getCurrentImage();
        if (!currentImage) {
            this.showStatus('No image selected', 'error');
            return;
        }

        try {
            this.currentProcessing = true;
            this.showStatus('Extracting structure...', 'processing');
            this.updateExtractButton(true);

            // Extract structure
            const extraction = await this.structureExtractor.extractFromImage(currentImage.file);
            
            // Validate extraction
            const validation = this.structureExtractor.validateExtraction(extraction);
            if (!validation.valid) {
                throw new Error(`Invalid extraction: ${validation.errors.join(', ')}`);
            }

            // Store structure in image data
            this.imageHandler.markImageProcessed(currentImage.id, extraction);
            
            // Store as last structure
            this.lastStructure = extraction;

            // Display structure
            this.visualization.displayStructure(extraction, this.imageHandler.getCurrentCanvas());
            
            // Update metrics
            this.updateMetrics(extraction.structure);
            
            // Enable dependent controls
            this.updateControlStates();
            
            this.showStatus(`Structure extracted: ${extraction.structure.nodes.length} nodes, ${extraction.structure.relations.length} relations`, 'success');

        } catch (error) {
            console.error('Structure extraction failed:', error);
            this.showStatus(`Extraction failed: ${error.message}`, 'error');
        } finally {
            this.currentProcessing = false;
            this.updateExtractButton(false);
        }
    }

    /**
     * Test invariance of current image
     */
    async testInvariance() {
        const currentImage = this.imageHandler.getCurrentImage();
        if (!currentImage) {
            this.showStatus('No image selected', 'error');
            return;
        }

        try {
            this.showStatus('Testing invariance...', 'processing');
            this.updateInvariantIndicator('testing');

            // Run invariance test
            const testResult = await this.invarianceTester.testInvariance(currentImage.file, 3);
            
            // Update UI based on result
            const isInvariant = testResult.analysis.overall_invariant;
            this.updateInvariantIndicator(isInvariant ? 'pass' : 'fail');

            if (isInvariant) {
                this.showStatus('Invariance test PASSED', 'success');
            } else {
                this.showStatus('Invariance test FAILED', 'error');
                console.warn('Invariance violations:', testResult.analysis.violations);
            }

            // Log detailed results
            console.log('Invariance test results:', testResult);

        } catch (error) {
            console.error('Invariance test failed:', error);
            this.showStatus(`Invariance test error: ${error.message}`, 'error');
            this.updateInvariantIndicator('error');
        }
    }

    /**
     * Update metrics display
     */
    updateMetrics(structure) {
        const nodeCount = document.getElementById('nodeCount');
        const relationCount = document.getElementById('relationCount');
        const densityValue = document.getElementById('densityValue');
        const coverageValue = document.getElementById('coverageValue');

        if (nodeCount) nodeCount.textContent = structure.nodes.length;
        if (relationCount) relationCount.textContent = structure.relations.length;
        if (densityValue) densityValue.textContent = structure.metrics.density.toFixed(3);
        if (coverageValue) coverageValue.textContent = (structure.metrics.coverage * 100).toFixed(1) + '%';
    }

    /**
     * Update control button states
     */
    updateControlStates() {
        const snapshotBtn = document.getElementById('snapshotBtn');
        if (snapshotBtn) {
            snapshotBtn.disabled = !this.lastStructure;
        }
    }

    /**
     * Update extract button state
     */
    updateExtractButton(processing) {
        const extractBtn = document.getElementById('extractBtn');
        if (extractBtn) {
            extractBtn.disabled = processing || this.currentProcessing;
            extractBtn.textContent = processing ? 'PROCESSING...' : 'EXTRACT STRUCTURE';
            
            if (processing) {
                extractBtn.classList.add('processing');
            } else {
                extractBtn.classList.remove('processing');
            }
        }
    }

    /**
     * Update invariant indicator
     */
    updateInvariantIndicator(state) {
        const invariantStatus = document.getElementById('invariantStatus');
        if (!invariantStatus) return;

        const states = {
            'ready': { symbol: '⚫', color: '#666666' },
            'testing': { symbol: '🟡', color: '#ffaa00' },
            'pass': { symbol: '🟢', color: '#00ff41' },
            'fail': { symbol: '🔴', color: '#ff4444' },
            'error': { symbol: '⚠️', color: '#ff6600' }
        };

        const stateConfig = states[state] || states.ready;
        invariantStatus.textContent = stateConfig.symbol;
        invariantStatus.style.color = stateConfig.color;
        invariantStatus.title = `Invariance: ${state.toUpperCase()}`;
    }

    /**
     * Handle window resize
     */
    handleResize() {
        if (this.visualization) {
            this.visualization.handleResize();
        }
    }

    /**
     * Handle keyboard shortcuts
     */
    handleKeyboard(event) {
        // Only handle shortcuts when not typing in inputs
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            return;
        }

        if (event.ctrlKey || event.metaKey) {
            switch (event.key) {
                case 'o': // Open file
                    event.preventDefault();
                    this.imageHandler.triggerFileSelect();
                    break;
                case 'e': // Extract structure
                    event.preventDefault();
                    if (this.imageHandler.getCurrentImage() && !this.currentProcessing) {
                        this.extractStructure();
                    }
                    break;
                case 'i': // Test invariance
                    event.preventDefault();
                    if (this.imageHandler.getCurrentImage()) {
                        this.testInvariance();
                    }
                    break;
                case 's': // Save snapshot (handled by snapshots module)
                    // Let snapshots module handle this
                    break;
                case 'r': // Clear/reset
                    event.preventDefault();
                    this.clearAll();
                    break;
            }
        }

        // Escape key - exit comparison mode
        if (event.key === 'Escape') {
            if (this.comparison && this.comparison.isComparisonActive()) {
                this.comparison.exitComparison();
            }
        }
    }

    /**
     * Handle errors
     */
    handleError(event) {
        console.error('Instrument error:', event.error || event.reason);
        
        // Reset processing state if error occurs during processing
        if (this.currentProcessing) {
            this.currentProcessing = false;
            this.updateExtractButton(false);
            this.showStatus('Operation failed due to error', 'error');
        }
    }

    /**
     * Clear all data
     */
    clearAll() {
        if (confirm('Clear all images and data? This cannot be undone.')) {
            // Clear image handler
            if (this.imageHandler) {
                this.imageHandler.clearAllImages();
            }
            
            // Clear visualization
            if (this.visualization) {
                this.visualization.clearOverlays();
            }
            
            // Reset state
            this.lastStructure = null;
            this.currentProcessing = false;
            
            // Update UI
            this.updateMetrics({ nodes: [], relations: [], metrics: { density: 0, coverage: 0 } });
            this.updateControlStates();
            this.updateInvariantIndicator('ready');
            
            this.showStatus('All data cleared', 'info');
        }
    }

    /**
     * Validate instrument state
     */
    validateInstrument() {
        const requiredModules = [
            'structureExtractor',
            'invarianceTester', 
            'imageHandler',
            'visualization',
            'comparison',
            'snapshots'
        ];

        const missingModules = requiredModules.filter(module => !this[module]);
        
        if (missingModules.length > 0) {
            throw new Error(`Missing required modules: ${missingModules.join(', ')}`);
        }

        // Validate deterministic operation
        const deterministicCheck = this.invarianceTester.validateDeterministicOperation();
        if (!deterministicCheck.deterministic) {
            console.warn('Deterministic operation issues detected:', deterministicCheck.issues);
        }
    }

    /**
     * Show status message
     */
    showStatus(message, type = 'info') {
        if (this.imageHandler) {
            this.imageHandler.showStatus(message, type);
        }
    }

    /**
     * Get instrument info
     */
    getInstrumentInfo() {
        return {
            name: 'hexBYE',
            full_name: 'Behavioral Yield Exclusion',
            version: this.version,
            type: 'structural_measurement_instrument',
            initialized: this.initialized,
            ready: this.instrumentReady,
            modules: {
                structure_extractor: !!this.structureExtractor,
                invariance_tester: !!this.invarianceTester,
                image_handler: !!this.imageHandler,
                visualization: !!this.visualization,
                comparison: !!this.comparison,
                snapshots: !!this.snapshots
            },
            capabilities: [
                'visibility_to_structure_mapping',
                'structural_invariance_testing',
                'non_semantic_analysis',
                'deterministic_operation',
                'local_storage',
                'structural_comparison'
            ],
            principles: [
                'no_semantic_interpretation',
                'no_decision_logic',
                'deterministic_only',
                'visibility_domain_only',
                'structural_invariance'
            ]
        };
    }

    /**
     * Export instrument state
     */
    exportInstrumentState() {
        const info = this.getInstrumentInfo();
        const snapshots = this.snapshots ? this.snapshots.getSnapshots() : [];
        const storageInfo = this.snapshots ? this.snapshots.getStorageInfo() : {};
        
        return {
            instrument: info,
            snapshots_count: snapshots.length,
            storage: storageInfo,
            export_timestamp: new Date().toISOString()
        };
    }
}

// Initialize instrument when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Create global instrument instance
        window.hexByeInstrument = new HexByeInstrument();
        
        // Initialize instrument
        await window.hexByeInstrument.initialize();
        
        console.log('hexBYE Measurement Instrument ready for use');
        
    } catch (error) {
        console.error('Failed to initialize hexBYE instrument:', error);
        
        // Show error in UI if possible
        const statusElement = document.getElementById('statusIndicator');
        if (statusElement) {
            statusElement.textContent = 'INITIALIZATION FAILED';
            statusElement.style.color = '#ff4444';
        }
    }
});

// Handle page unload
window.addEventListener('beforeunload', (event) => {
    if (window.hexByeInstrument && window.hexByeInstrument.currentProcessing) {
        event.preventDefault();
        event.returnValue = 'Processing in progress. Are you sure you want to leave?';
    }
});

// Export for module access
window.HexByeInstrument = HexByeInstrument;
