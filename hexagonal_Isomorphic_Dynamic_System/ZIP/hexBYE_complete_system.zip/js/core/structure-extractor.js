/**
 * hexBYE Structure Extractor
 * Deterministic structure processing and analysis
 * NO semantic interpretation, NO optimization
 */

class StructureExtractor {
    constructor() {
        this.visibilityMapper = new VisibilityMapper();
        this.lastExtraction = null;
    }

    /**
     * Main extraction method - Image to Structure
     */
    async extractFromImage(imageFile) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            img.onload = () => {
                try {
                    // Set canvas dimensions
                    canvas.width = img.naturalWidth;
                    canvas.height = img.naturalHeight;

                    // Draw image to canvas
                    ctx.drawImage(img, 0, 0);

                    // Extract image data
                    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

                    // Map to structure using visibility mapper
                    const result = this.visibilityMapper.mapImageToStructure(
                        imageData.data,
                        canvas.width,
                        canvas.height
                    );

                    // Add extraction metadata
                    result.extraction = {
                        filename: imageFile.name,
                        filesize: imageFile.size,
                        filetype: imageFile.type,
                        extracted_at: new Date().toISOString(),
                        hash: this._generateFileHash(imageFile)
                    };

                    this.lastExtraction = result;
                    resolve(result);

                } catch (error) {
                    reject(new Error(`Extraction failed: ${error.message}`));
                }
            };

            img.onerror = () => {
                reject(new Error('Failed to load image'));
            };

            img.src = URL.createObjectURL(imageFile);
        });
    }

    /**
     * Extract from canvas element
     */
    extractFromCanvas(canvas) {
        const ctx = canvas.getContext('2d');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

        const result = this.visibilityMapper.mapImageToStructure(
            imageData.data,
            canvas.width,
            canvas.height
        );

        result.extraction = {
            source: 'canvas',
            width: canvas.width,
            height: canvas.height,
            extracted_at: new Date().toISOString()
        };

        this.lastExtraction = result;
        return result;
    }

    /**
     * Validate extraction results
     */
    validateExtraction(extraction) {
        const required_fields = [
            'meta', 'visibility', 'structure', 'extraction'
        ];

        const errors = [];

        // Check required fields
        for (const field of required_fields) {
            if (!(field in extraction)) {
                errors.push(`Missing required field: ${field}`);
            }
        }

        // Validate structure
        if (extraction.structure) {
            const structure = extraction.structure;
            
            if (!Array.isArray(structure.nodes)) {
                errors.push('Structure nodes must be array');
            }

            if (!Array.isArray(structure.relations)) {
                errors.push('Structure relations must be array');
            }

            // Validate node format
            for (const [index, node] of structure.nodes.entries()) {
                if (!node.id || typeof node.id !== 'string') {
                    errors.push(`Node ${index}: missing or invalid id`);
                }

                if (!node.position || !node.position.pixel || !node.position.hex) {
                    errors.push(`Node ${index}: missing position data`);
                }

                if (!node.properties || typeof node.properties.size !== 'number') {
                    errors.push(`Node ${index}: missing or invalid properties`);
                }
            }

            // Validate relation format
            for (const [index, relation] of structure.relations.entries()) {
                if (!relation.id || typeof relation.id !== 'string') {
                    errors.push(`Relation ${index}: missing or invalid id`);
                }

                if (!relation.from || !relation.to) {
                    errors.push(`Relation ${index}: missing from/to nodes`);
                }

                if (typeof relation.distance !== 'number' || relation.distance < 0) {
                    errors.push(`Relation ${index}: invalid distance`);
                }
            }
        }

        return {
            valid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Compare two extractions structurally
     */
    compareExtractions(extractionA, extractionB) {
        const structA = extractionA.structure;
        const structB = extractionB.structure;

        // Node count difference
        const nodeCountDiff = Math.abs(structA.nodes.length - structB.nodes.length);
        
        // Relation count difference  
        const relationCountDiff = Math.abs(structA.relations.length - structB.relations.length);

        // Metric differences
        const densityDiff = Math.abs(structA.metrics.density - structB.metrics.density);
        const coverageDiff = Math.abs(structA.metrics.coverage - structB.metrics.coverage);

        // Topological comparison (simplified)
        const topologyDiff = this._compareTopology(structA, structB);

        // Overall similarity score (0 = identical, 1 = completely different)
        const similarity = this._calculateSimilarity(
            nodeCountDiff,
            relationCountDiff, 
            densityDiff,
            coverageDiff,
            topologyDiff
        );

        return {
            comparison: {
                node_count_diff: nodeCountDiff,
                relation_count_diff: relationCountDiff,
                density_diff: densityDiff,
                coverage_diff: coverageDiff,
                topology_diff: topologyDiff
            },
            similarity: similarity,
            identical: similarity < 0.001, // Threshold for "identical"
            metrics: {
                structure_a: {
                    nodes: structA.nodes.length,
                    relations: structA.relations.length,
                    density: structA.metrics.density,
                    coverage: structA.metrics.coverage
                },
                structure_b: {
                    nodes: structB.nodes.length,
                    relations: structB.relations.length,
                    density: structB.metrics.density,
                    coverage: structB.metrics.coverage
                }
            }
        };
    }

    /**
     * Compare topology between two structures
     */
    _compareTopology(structA, structB) {
        // Build adjacency matrices
        const matrixA = this._buildAdjacencyMatrix(structA);
        const matrixB = this._buildAdjacencyMatrix(structB);

        // Compare matrix dimensions
        if (matrixA.length !== matrixB.length) {
            return 1.0; // Completely different if different node counts
        }

        // Compare matrices element by element
        let differences = 0;
        let total = 0;

        for (let i = 0; i < matrixA.length; i++) {
            for (let j = 0; j < matrixA[i].length; j++) {
                if (matrixA[i][j] !== matrixB[i][j]) {
                    differences++;
                }
                total++;
            }
        }

        return total > 0 ? differences / total : 0;
    }

    /**
     * Build adjacency matrix from structure
     */
    _buildAdjacencyMatrix(structure) {
        const nodeCount = structure.nodes.length;
        const matrix = Array(nodeCount).fill().map(() => Array(nodeCount).fill(0));

        // Create node ID to index mapping
        const nodeIdToIndex = {};
        structure.nodes.forEach((node, index) => {
            nodeIdToIndex[node.id] = index;
        });

        // Fill matrix based on relations
        structure.relations.forEach(relation => {
            const fromIndex = nodeIdToIndex[relation.from];
            const toIndex = nodeIdToIndex[relation.to];

            if (fromIndex !== undefined && toIndex !== undefined) {
                matrix[fromIndex][toIndex] = 1;
                matrix[toIndex][fromIndex] = 1; // Undirected graph
            }
        });

        return matrix;
    }

    /**
     * Calculate overall similarity score
     */
    _calculateSimilarity(nodeCountDiff, relationCountDiff, densityDiff, coverageDiff, topologyDiff) {
        // Weighted combination of differences
        const weights = {
            nodeCount: 0.3,
            relationCount: 0.3,
            density: 0.2,
            coverage: 0.1,
            topology: 0.1
        };

        // Normalize differences to [0,1] range
        const normalizedNodeDiff = Math.min(1.0, nodeCountDiff / 10);
        const normalizedRelationDiff = Math.min(1.0, relationCountDiff / 20);
        const normalizedDensityDiff = Math.min(1.0, densityDiff);
        const normalizedCoverageDiff = Math.min(1.0, coverageDiff);

        return (
            weights.nodeCount * normalizedNodeDiff +
            weights.relationCount * normalizedRelationDiff +
            weights.density * normalizedDensityDiff +
            weights.coverage * normalizedCoverageDiff +
            weights.topology * topologyDiff
        );
    }

    /**
     * Generate simplified file hash for tracking
     */
    _generateFileHash(file) {
        // Simple hash based on filename, size, and type
        const hashString = `${file.name}_${file.size}_${file.type}_${file.lastModified || 0}`;
        return this._simpleHash(hashString);
    }

    /**
     * Simple hash function
     */
    _simpleHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return Math.abs(hash).toString(16);
    }

    /**
     * Export structure to various formats
     */
    exportStructure(extraction, format = 'json') {
        switch (format.toLowerCase()) {
            case 'json':
                return this._exportJSON(extraction);
            case 'svg':
                return this._exportSVG(extraction);
            case 'csv':
                return this._exportCSV(extraction);
            default:
                throw new Error(`Unsupported export format: ${format}`);
        }
    }

    /**
     * Export as JSON
     */
    _exportJSON(extraction) {
        return {
            data: JSON.stringify(extraction, null, 2),
            filename: `hexBYE_extraction_${Date.now()}.json`,
            mimetype: 'application/json'
        };
    }

    /**
     * Export as SVG
     */
    _exportSVG(extraction) {
        const { nodes, relations } = extraction.structure;
        const { width, height } = extraction.meta;
        
        // Calculate view box with padding
        const padding = 50;
        const viewWidth = width + (padding * 2);
        const viewHeight = height + (padding * 2);

        let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${viewWidth} ${viewHeight}">`;
        svg += `<rect width="${viewWidth}" height="${viewHeight}" fill="#000000"/>`;

        // Draw relations first (behind nodes)
        relations.forEach(relation => {
            const fromNode = nodes.find(n => n.id === relation.from);
            const toNode = nodes.find(n => n.id === relation.to);

            if (fromNode && toNode) {
                const x1 = fromNode.position.pixel.x + padding;
                const y1 = fromNode.position.pixel.y + padding;
                const x2 = toNode.position.pixel.x + padding;
                const y2 = toNode.position.pixel.y + padding;

                svg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" `;
                svg += `stroke="#ffaa00" stroke-width="1" opacity="0.6"/>`;
            }
        });

        // Draw nodes
        nodes.forEach(node => {
            const x = node.position.pixel.x + padding;
            const y = node.position.pixel.y + padding;
            const size = Math.max(3, Math.sqrt(node.properties.size) / 2);

            svg += `<circle cx="${x}" cy="${y}" r="${size}" `;
            svg += `fill="#00aaff" stroke="#ffffff" stroke-width="1"/>`;
        });

        svg += '</svg>';

        return {
            data: svg,
            filename: `hexBYE_structure_${Date.now()}.svg`,
            mimetype: 'image/svg+xml'
        };
    }

    /**
     * Export as CSV
     */
    _exportCSV(extraction) {
        const { nodes, relations } = extraction.structure;
        
        let csv = 'Type,ID,Property,Value\n';

        // Export nodes
        nodes.forEach(node => {
            csv += `node,${node.id},x,${node.position.pixel.x}\n`;
            csv += `node,${node.id},y,${node.position.pixel.y}\n`;
            csv += `node,${node.id},q,${node.position.hex.q}\n`;
            csv += `node,${node.id},r,${node.position.hex.r}\n`;
            csv += `node,${node.id},size,${node.properties.size}\n`;
            csv += `node,${node.id},density,${node.properties.density}\n`;
        });

        // Export relations
        relations.forEach(relation => {
            csv += `relation,${relation.id},from,${relation.from}\n`;
            csv += `relation,${relation.id},to,${relation.to}\n`;
            csv += `relation,${relation.id},distance,${relation.distance}\n`;
            csv += `relation,${relation.id},angle,${relation.angle}\n`;
        });

        return {
            data: csv,
            filename: `hexBYE_data_${Date.now()}.csv`,
            mimetype: 'text/csv'
        };
    }

    /**
     * Get last extraction result
     */
    getLastExtraction() {
        return this.lastExtraction;
    }

    /**
     * Clear last extraction
     */
    clearLastExtraction() {
        this.lastExtraction = null;
    }
}

// Export for use in other modules
window.StructureExtractor = StructureExtractor;
