/**
 * hexBYE Visibility Mapper
 * Deterministic visibility-to-structure mapping
 * NO semantic interpretation, NO decisions, NO randomness
 */

class VisibilityMapper {
    constructor() {
        // Fixed, immutable constants - never modified during execution
        this.CONSTANTS = Object.freeze({
            LUMINANCE_WEIGHTS: Object.freeze([0.2126, 0.7152, 0.0722]), // ITU-R BT.709
            SOBEL_X: Object.freeze([
                [-1, 0, 1],
                [-2, 0, 2], 
                [-1, 0, 1]
            ]),
            SOBEL_Y: Object.freeze([
                [-1, -2, -1],
                [ 0,  0,  0],
                [ 1,  2,  1]
            ]),
            EDGE_THRESHOLD: 20, // Fixed threshold, never optimized
            CLUSTER_CONNECTIVITY: 8, // 8-connected components
            MIN_CLUSTER_SIZE: 4, // Minimum pixels for valid cluster
            SCALE_FACTOR: 40 // Fixed scale for hex coordinates
        });
    }

    /**
     * Main mapping function: Image → Visibility Domain → Structure
     */
    mapImageToStructure(imageData, width, height) {
        // Step 1: Convert to luminance (visibility-only)
        const luminance = this._extractLuminance(imageData, width, height);
        
        // Step 2: Detect edges (contrast boundaries)
        const edges = this._detectEdges(luminance, width, height);
        
        // Step 3: Find connected components (clusters)
        const clusters = this._findClusters(edges, width, height);
        
        // Step 4: Extract structure (nodes + relations)
        const structure = this._extractStructure(clusters, width, height);
        
        return {
            meta: {
                timestamp: Date.now(),
                width: width,
                height: height,
                method: 'hexBYE_visibility_mapper_v1.0',
                deterministic: true,
                constants: this.CONSTANTS
            },
            visibility: {
                luminance_stats: this._calculateLuminanceStats(luminance),
                edge_density: this._calculateEdgeDensity(edges, width, height),
                cluster_count: clusters.length
            },
            structure: structure
        };
    }

    /**
     * Extract luminance from RGBA data
     * Uses ITU-R BT.709 standard weights (deterministic)
     */
    _extractLuminance(imageData, width, height) {
        const luminance = new Float32Array(width * height);
        const [wr, wg, wb] = this.CONSTANTS.LUMINANCE_WEIGHTS;
        
        for (let i = 0; i < imageData.length; i += 4) {
            const pixelIndex = i / 4;
            luminance[pixelIndex] = 
                imageData[i] * wr +     // R
                imageData[i + 1] * wg + // G  
                imageData[i + 2] * wb;  // B
                // Alpha channel ignored (visibility-only)
        }
        
        return luminance;
    }

    /**
     * Edge detection using Sobel operator
     * Deterministic convolution, no adaptive thresholds
     */
    _detectEdges(luminance, width, height) {
        const edges = new Uint8Array(width * height);
        const sobelX = this.CONSTANTS.SOBEL_X;
        const sobelY = this.CONSTANTS.SOBEL_Y;
        
        for (let y = 1; y < height - 1; y++) {
            for (let x = 1; x < width - 1; x++) {
                let gx = 0, gy = 0;
                
                // Apply Sobel kernels
                for (let ky = -1; ky <= 1; ky++) {
                    for (let kx = -1; kx <= 1; kx++) {
                        const pixelIndex = (y + ky) * width + (x + kx);
                        const pixelValue = luminance[pixelIndex];
                        
                        gx += pixelValue * sobelX[ky + 1][kx + 1];
                        gy += pixelValue * sobelY[ky + 1][kx + 1];
                    }
                }
                
                // Gradient magnitude
                const magnitude = Math.sqrt(gx * gx + gy * gy);
                const currentIndex = y * width + x;
                
                // Fixed threshold (never adaptive)
                edges[currentIndex] = magnitude > this.CONSTANTS.EDGE_THRESHOLD ? 1 : 0;
            }
        }
        
        return edges;
    }

    /**
     * Find connected components using flood fill
     * 8-connected components, deterministic traversal
     */
    _findClusters(edges, width, height) {
        const visited = new Uint8Array(width * height);
        const clusters = [];
        
        for (let i = 0; i < edges.length; i++) {
            if (edges[i] && !visited[i]) {
                const cluster = this._floodFill(edges, visited, i, width, height);
                
                // Only include clusters above minimum size
                if (cluster.pixels.length >= this.CONSTANTS.MIN_CLUSTER_SIZE) {
                    clusters.push(cluster);
                }
            }
        }
        
        return clusters;
    }

    /**
     * Flood fill algorithm for connected component labeling
     * Deterministic 8-connected traversal
     */
    _floodFill(edges, visited, startIndex, width, height) {
        const stack = [startIndex];
        const pixels = [];
        let sumX = 0, sumY = 0;
        
        const directions = [
            -width - 1, -width, -width + 1,  // Top row
            -1,                    1,         // Middle row (skip center)
            width - 1,  width,  width + 1    // Bottom row
        ];
        
        while (stack.length > 0) {
            const currentIndex = stack.pop();
            
            if (visited[currentIndex]) continue;
            visited[currentIndex] = 1;
            
            const x = currentIndex % width;
            const y = Math.floor(currentIndex / width);
            
            pixels.push({ x, y, index: currentIndex });
            sumX += x;
            sumY += y;
            
            // Check 8-connected neighbors
            for (const direction of directions) {
                const neighborIndex = currentIndex + direction;
                const neighborX = neighborIndex % width;
                const neighborY = Math.floor(neighborIndex / width);
                
                // Bounds checking
                if (neighborX >= 0 && neighborX < width && 
                    neighborY >= 0 && neighborY < height &&
                    !visited[neighborIndex] && 
                    edges[neighborIndex]) {
                    
                    stack.push(neighborIndex);
                }
            }
        }
        
        return {
            pixels: pixels,
            centroid: {
                x: sumX / pixels.length,
                y: sumY / pixels.length
            },
            size: pixels.length,
            bounds: this._calculateBounds(pixels)
        };
    }

    /**
     * Calculate bounding box for cluster
     */
    _calculateBounds(pixels) {
        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;
        
        for (const pixel of pixels) {
            minX = Math.min(minX, pixel.x);
            maxX = Math.max(maxX, pixel.x);
            minY = Math.min(minY, pixel.y);
            maxY = Math.max(maxY, pixel.y);
        }
        
        return { minX, maxX, minY, maxY };
    }

    /**
     * Extract structural representation from clusters
     */
    _extractStructure(clusters, width, height) {
        const nodes = this._createNodes(clusters);
        const relations = this._createRelations(nodes);
        
        return {
            topology: "visibility_derived",
            nodes: nodes,
            relations: relations,
            metrics: this._calculateStructureMetrics(nodes, relations, width, height)
        };
    }

    /**
     * Create nodes from cluster centroids
     */
    _createNodes(clusters) {
        return clusters.map((cluster, index) => ({
            id: `n${index}`,
            position: {
                pixel: {
                    x: cluster.centroid.x,
                    y: cluster.centroid.y
                },
                hex: {
                    q: Math.round(cluster.centroid.x / this.CONSTANTS.SCALE_FACTOR),
                    r: Math.round(cluster.centroid.y / this.CONSTANTS.SCALE_FACTOR)
                }
            },
            properties: {
                size: cluster.size,
                bounds: cluster.bounds,
                density: cluster.size / ((cluster.bounds.maxX - cluster.bounds.minX + 1) * 
                                       (cluster.bounds.maxY - cluster.bounds.minY + 1))
            }
        }));
    }

    /**
     * Create relations based on proximity
     * Fixed distance thresholds, no optimization
     */
    _createRelations(nodes) {
        const relations = [];
        const maxDistance = this.CONSTANTS.SCALE_FACTOR * 2; // Fixed threshold
        
        for (let i = 0; i < nodes.length; i++) {
            for (let j = i + 1; j < nodes.length; j++) {
                const nodeA = nodes[i];
                const nodeB = nodes[j];
                
                const distance = this._calculateDistance(
                    nodeA.position.pixel,
                    nodeB.position.pixel
                );
                
                if (distance <= maxDistance) {
                    relations.push({
                        id: `r${i}_${j}`,
                        from: nodeA.id,
                        to: nodeB.id,
                        distance: distance,
                        angle: this._calculateAngle(
                            nodeA.position.pixel,
                            nodeB.position.pixel
                        )
                    });
                }
            }
        }
        
        return relations;
    }

    /**
     * Calculate Euclidean distance between two points
     */
    _calculateDistance(pointA, pointB) {
        const dx = pointA.x - pointB.x;
        const dy = pointA.y - pointB.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Calculate angle between two points
     */
    _calculateAngle(pointA, pointB) {
        return Math.atan2(pointB.y - pointA.y, pointB.x - pointA.x);
    }

    /**
     * Calculate structure metrics
     */
    _calculateStructureMetrics(nodes, relations, width, height) {
        const nodeCount = nodes.length;
        const relationCount = relations.length;
        const density = relationCount / (nodeCount * (nodeCount - 1) / 2);
        const coverage = this._calculateCoverage(nodes, width, height);
        
        return {
            node_count: nodeCount,
            relation_count: relationCount,
            density: density,
            coverage: coverage,
            connectivity: nodeCount > 0 ? relationCount / nodeCount : 0
        };
    }

    /**
     * Calculate spatial coverage
     */
    _calculateCoverage(nodes, width, height) {
        if (nodes.length === 0) return 0;
        
        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;
        
        for (const node of nodes) {
            minX = Math.min(minX, node.position.pixel.x);
            maxX = Math.max(maxX, node.position.pixel.x);
            minY = Math.min(minY, node.position.pixel.y);
            maxY = Math.max(maxY, node.position.pixel.y);
        }
        
        const coveredArea = (maxX - minX + 1) * (maxY - minY + 1);
        const totalArea = width * height;
        
        return Math.min(1.0, coveredArea / totalArea);
    }

    /**
     * Calculate luminance statistics
     */
    _calculateLuminanceStats(luminance) {
        let sum = 0, min = Infinity, max = -Infinity;
        
        for (const value of luminance) {
            sum += value;
            min = Math.min(min, value);
            max = Math.max(max, value);
        }
        
        return {
            mean: sum / luminance.length,
            min: min,
            max: max,
            range: max - min
        };
    }

    /**
     * Calculate edge density
     */
    _calculateEdgeDensity(edges, width, height) {
        let edgeCount = 0;
        for (const edge of edges) {
            edgeCount += edge;
        }
        return edgeCount / (width * height);
    }

    /**
     * Generate deterministic hash of structure for invariance testing
     */
    generateStructureHash(structure) {
        const hashData = {
            node_positions: structure.nodes.map(n => ({
                q: n.position.hex.q,
                r: n.position.hex.r
            })),
            relation_count: structure.relations.length,
            metrics: {
                density: Math.round(structure.metrics.density * 1000) / 1000,
                coverage: Math.round(structure.metrics.coverage * 1000) / 1000
            }
        };
        
        return this._simpleHash(JSON.stringify(hashData));
    }

    /**
     * Simple deterministic hash function
     */
    _simpleHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash).toString(16);
    }
}

// Export for use in other modules
window.VisibilityMapper = VisibilityMapper;
