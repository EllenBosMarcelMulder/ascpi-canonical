/**
 * hexBYE Invariance Tester
 * Tests structural invariance across identical inputs
 * Core validation mechanism for deterministic operation
 */

class InvarianceTester {
    constructor() {
        this.structureExtractor = new StructureExtractor();
        this.testHistory = [];
        this.TOLERANCE = 0.001; // Tolerance for floating-point comparison
    }

    /**
     * Test invariance by processing same image multiple times
     */
    async testInvariance(imageFile, iterations = 3) {
        const results = [];
        const hashes = [];

        try {
            // Perform multiple extractions
            for (let i = 0; i < iterations; i++) {
                const extraction = await this.structureExtractor.extractFromImage(imageFile);
                results.push(extraction);

                // Generate structural hash
                const hash = this.structureExtractor.visibilityMapper.generateStructureHash(extraction.structure);
                hashes.push(hash);
            }

            // Analyze invariance
            const analysis = this._analyzeInvariance(results, hashes);

            // Store test record
            const testRecord = {
                timestamp: new Date().toISOString(),
                filename: imageFile.name,
                iterations: iterations,
                results: results,
                hashes: hashes,
                analysis: analysis
            };

            this.testHistory.push(testRecord);

            return testRecord;

        } catch (error) {
            throw new Error(`Invariance test failed: ${error.message}`);
        }
    }

    /**
     * Analyze invariance across multiple extractions
     */
    _analyzeInvariance(results, hashes) {
        // Check hash identity
        const uniqueHashes = [...new Set(hashes)];
        const hashInvariant = uniqueHashes.length === 1;

        // Detailed structural comparison
        const structuralAnalysis = this._compareAllStructures(results);

        // Node count consistency
        const nodeCounts = results.map(r => r.structure.nodes.length);
        const nodeCountInvariant = this._isArrayInvariant(nodeCounts);

        // Relation count consistency
        const relationCounts = results.map(r => r.structure.relations.length);
        const relationCountInvariant = this._isArrayInvariant(relationCounts);

        // Metric consistency
        const densities = results.map(r => r.structure.metrics.density);
        const densityInvariant = this._isArrayInvariant(densities, this.TOLERANCE);

        const coverages = results.map(r => r.structure.metrics.coverage);
        const coverageInvariant = this._isArrayInvariant(coverages, this.TOLERANCE);

        // Overall invariance assessment
        const overallInvariant = hashInvariant && 
                                nodeCountInvariant && 
                                relationCountInvariant && 
                                densityInvariant && 
                                coverageInvariant;

        return {
            overall_invariant: overallInvariant,
            hash_invariant: hashInvariant,
            unique_hashes: uniqueHashes,
            structural_analysis: structuralAnalysis,
            metrics: {
                node_count_invariant: nodeCountInvariant,
                node_counts: nodeCounts,
                relation_count_invariant: relationCountInvariant,
                relation_counts: relationCounts,
                density_invariant: densityInvariant,
                densities: densities,
                coverage_invariant: coverageInvariant,
                coverages: coverages
            },
            violations: this._identifyViolations(results)
        };
    }

    /**
     * Compare all structures pairwise
     */
    _compareAllStructures(results) {
        const comparisons = [];

        for (let i = 0; i < results.length; i++) {
            for (let j = i + 1; j < results.length; j++) {
                const comparison = this.structureExtractor.compareExtractions(results[i], results[j]);
                comparisons.push({
                    pair: `${i}-${j}`,
                    identical: comparison.identical,
                    similarity: comparison.similarity,
                    differences: comparison.comparison
                });
            }
        }

        const allIdentical = comparisons.every(c => c.identical);
        const maxDifference = comparisons.reduce((max, c) => Math.max(max, 1 - c.similarity), 0);

        return {
            all_identical: allIdentical,
            max_difference: maxDifference,
            comparisons: comparisons
        };
    }

    /**
     * Check if array values are invariant
     */
    _isArrayInvariant(values, tolerance = 0) {
        if (values.length <= 1) return true;

        const first = values[0];
        return values.every(value => {
            if (tolerance === 0) {
                return value === first;
            } else {
                return Math.abs(value - first) <= tolerance;
            }
        });
    }

    /**
     * Identify specific invariance violations
     */
    _identifyViolations(results) {
        const violations = [];

        if (results.length <= 1) return violations;

        const reference = results[0];

        for (let i = 1; i < results.length; i++) {
            const current = results[i];
            const iteration = i;

            // Check node count
            if (current.structure.nodes.length !== reference.structure.nodes.length) {
                violations.push({
                    type: 'node_count_mismatch',
                    iteration: iteration,
                    expected: reference.structure.nodes.length,
                    actual: current.structure.nodes.length
                });
            }

            // Check relation count
            if (current.structure.relations.length !== reference.structure.relations.length) {
                violations.push({
                    type: 'relation_count_mismatch',
                    iteration: iteration,
                    expected: reference.structure.relations.length,
                    actual: current.structure.relations.length
                });
            }

            // Check density
            const densityDiff = Math.abs(current.structure.metrics.density - reference.structure.metrics.density);
            if (densityDiff > this.TOLERANCE) {
                violations.push({
                    type: 'density_mismatch',
                    iteration: iteration,
                    expected: reference.structure.metrics.density,
                    actual: current.structure.metrics.density,
                    difference: densityDiff
                });
            }

            // Check coverage
            const coverageDiff = Math.abs(current.structure.metrics.coverage - reference.structure.metrics.coverage);
            if (coverageDiff > this.TOLERANCE) {
                violations.push({
                    type: 'coverage_mismatch',
                    iteration: iteration,
                    expected: reference.structure.metrics.coverage,
                    actual: current.structure.metrics.coverage,
                    difference: coverageDiff
                });
            }
        }

        return violations;
    }

    /**
     * Test cross-platform invariance (simulate different execution contexts)
     */
    async testCrossPlatformInvariance(imageFile) {
        const results = [];

        // Test with slight canvas modifications (simulating different rendering contexts)
        const modificationTests = [
            { name: 'baseline', modify: false },
            { name: 'canvas_translation', modify: true, type: 'translate' },
            { name: 'canvas_scale', modify: true, type: 'scale' }
        ];

        for (const test of modificationTests) {
            try {
                let extraction;
                
                if (test.modify) {
                    extraction = await this._extractWithCanvasModification(imageFile, test.type);
                } else {
                    extraction = await this.structureExtractor.extractFromImage(imageFile);
                }

                extraction.test_context = test.name;
                results.push(extraction);

            } catch (error) {
                console.warn(`Cross-platform test ${test.name} failed:`, error);
            }
        }

        if (results.length < 2) {
            throw new Error('Insufficient results for cross-platform test');
        }

        // Analyze cross-platform invariance
        const hashes = results.map(r => 
            this.structureExtractor.visibilityMapper.generateStructureHash(r.structure)
        );

        const analysis = this._analyzeInvariance(results, hashes);

        return {
            test_type: 'cross_platform',
            timestamp: new Date().toISOString(),
            filename: imageFile.name,
            contexts: results.map(r => r.test_context),
            results: results,
            analysis: analysis
        };
    }

    /**
     * Extract with slight canvas modification for robustness testing
     */
    async _extractWithCanvasModification(imageFile, modificationType) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            img.onload = () => {
                try {
                    canvas.width = img.naturalWidth;
                    canvas.height = img.naturalHeight;

                    // Apply modification based on type
                    switch (modificationType) {
                        case 'translate':
                            // Translate by fractional pixel (tests subpixel handling)
                            ctx.translate(0.5, 0.5);
                            break;
                        case 'scale':
                            // Minimal scale (tests interpolation consistency)
                            ctx.scale(1.0001, 1.0001);
                            break;
                    }

                    ctx.drawImage(img, 0, 0);

                    // Extract normally
                    const result = this.structureExtractor.extractFromCanvas(canvas);
                    resolve(result);

                } catch (error) {
                    reject(error);
                }
            };

            img.onerror = () => {
                reject(new Error('Failed to load image for modification test'));
            };

            img.src = URL.createObjectURL(imageFile);
        });
    }

    /**
     * Generate invariance report
     */
    generateInvarianceReport(testRecord) {
        const { analysis } = testRecord;

        let report = `HEXBYE INVARIANCE TEST REPORT\n`;
        report += `=====================================\n\n`;
        report += `File: ${testRecord.filename}\n`;
        report += `Test Date: ${testRecord.timestamp}\n`;
        report += `Iterations: ${testRecord.iterations}\n\n`;

        report += `OVERALL RESULT: ${analysis.overall_invariant ? 'PASS' : 'FAIL'}\n\n`;

        report += `DETAILED ANALYSIS:\n`;
        report += `------------------\n`;
        report += `Hash Invariant: ${analysis.hash_invariant ? 'PASS' : 'FAIL'}\n`;
        report += `Unique Hashes: ${analysis.unique_hashes.length}\n`;
        report += `Node Count Invariant: ${analysis.metrics.node_count_invariant ? 'PASS' : 'FAIL'}\n`;
        report += `Relation Count Invariant: ${analysis.metrics.relation_count_invariant ? 'PASS' : 'FAIL'}\n`;
        report += `Density Invariant: ${analysis.metrics.density_invariant ? 'PASS' : 'FAIL'}\n`;
        report += `Coverage Invariant: ${analysis.metrics.coverage_invariant ? 'PASS' : 'FAIL'}\n\n`;

        if (analysis.violations.length > 0) {
            report += `VIOLATIONS:\n`;
            report += `-----------\n`;
            analysis.violations.forEach((violation, index) => {
                report += `${index + 1}. ${violation.type} (iteration ${violation.iteration})\n`;
                report += `   Expected: ${violation.expected}, Actual: ${violation.actual}\n`;
                if (violation.difference !== undefined) {
                    report += `   Difference: ${violation.difference}\n`;
                }
            });
        } else {
            report += `No violations detected.\n`;
        }

        return report;
    }

    /**
     * Get test history
     */
    getTestHistory() {
        return this.testHistory;
    }

    /**
     * Clear test history
     */
    clearTestHistory() {
        this.testHistory = [];
    }

    /**
     * Get latest test result
     */
    getLatestTest() {
        return this.testHistory.length > 0 ? this.testHistory[this.testHistory.length - 1] : null;
    }

    /**
     * Validate deterministic operation
     */
    validateDeterministicOperation() {
        // Check if there are any non-deterministic elements in the system
        const issues = [];

        // Check for time-based randomness
        if (Math.random === Math.random) {
            // This is always true, but we're checking if Math.random might be overridden
            // In a real test, we'd check if our algorithms use Math.random anywhere
        }

        // Check for Date-based randomness in algorithms (not in metadata)
        // Our algorithms should never use Date.now() or new Date() for computation

        // Check for non-deterministic array operations
        // JavaScript array sort is not guaranteed stable across all engines

        return {
            deterministic: issues.length === 0,
            issues: issues
        };
    }
}

// Export for use in other modules
window.InvarianceTester = InvarianceTester;
