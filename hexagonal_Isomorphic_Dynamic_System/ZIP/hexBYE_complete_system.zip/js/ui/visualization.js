/**
 * hexBYE Visualization
 * Renders structural overlays and representations
 * NO interpretation, pure visual display of extracted structure
 */

class Visualization {
    constructor() {
        this.overlayEnabled = {
            clusters: false,
            nodes: true,
            relations: false,
            density: false
        };
        this.currentStructure = null;
        this.scale = 1.0;
        this.offset = { x: 0, y: 0 };
    }

    /**
     * Initialize visualization with UI controls
     */
    initialize() {
        this.setupOverlayControls();
    }

    /**
     * Setup overlay toggle controls
     */
    setupOverlayControls() {
        const controls = {
            'showClusters': 'clusters',
            'showNodes': 'nodes', 
            'showRelations': 'relations',
            'showDensity': 'density'
        };

        Object.entries(controls).forEach(([controlId, overlayType]) => {
            const control = document.getElementById(controlId);
            if (control) {
                control.addEventListener('change', (e) => {
                    this.overlayEnabled[overlayType] = e.target.checked;
                    this.renderOverlays();
                });
                
                // Set initial state
                control.checked = this.overlayEnabled[overlayType];
            }
        });
    }

    /**
     * Display structure with overlays
     */
    displayStructure(structureData, canvas) {
        this.currentStructure = structureData;
        
        if (canvas) {
            this.calculateScale(canvas, structureData);
            this.renderOverlays();
        }
        
        // Update structure canvas
        this.renderStructureCanvas(structureData);
    }

    /**
     * Calculate scale and offset for overlays
     */
    calculateScale(canvas, structureData) {
        const canvasRect = canvas.getBoundingClientRect();
        const imageWidth = structureData.meta.width;
        const imageHeight = structureData.meta.height;
        
        this.scale = Math.min(
            canvas.width / imageWidth,
            canvas.height / imageHeight
        );
        
        this.offset = {
            x: (canvas.width - imageWidth * this.scale) / 2,
            y: (canvas.height - imageHeight * this.scale) / 2
        };
    }

    /**
     * Render all enabled overlays
     */
    renderOverlays() {
        if (!this.currentStructure) return;

        const overlayContainer = document.getElementById('measurementOverlay');
        if (!overlayContainer) return;

        // Clear existing overlays
        overlayContainer.innerHTML = '';

        const canvas = document.getElementById('measurementCanvas');
        if (!canvas) return;

        // Get canvas position for absolute positioning
        const canvasRect = canvas.getBoundingClientRect();
        const containerRect = overlayContainer.parentElement.getBoundingClientRect();

        const canvasOffset = {
            x: canvasRect.left - containerRect.left,
            y: canvasRect.top - containerRect.top
        };

        // Render enabled overlays
        if (this.overlayEnabled.clusters) {
            this.renderClusters(overlayContainer, canvasOffset);
        }

        if (this.overlayEnabled.nodes) {
            this.renderNodes(overlayContainer, canvasOffset);
        }

        if (this.overlayEnabled.relations) {
            this.renderRelations(overlayContainer, canvasOffset);
        }

        if (this.overlayEnabled.density) {
            this.renderDensityAreas(overlayContainer, canvasOffset);
        }
    }

    /**
     * Render cluster overlays
     */
    renderClusters(container, canvasOffset) {
        if (!this.currentStructure || !this.currentStructure.structure.nodes) return;

        this.currentStructure.structure.nodes.forEach((node, index) => {
            const bounds = node.properties.bounds;
            if (!bounds) return;

            const x = (bounds.minX * this.scale) + canvasOffset.x + this.offset.x;
            const y = (bounds.minY * this.scale) + canvasOffset.y + this.offset.y;
            const width = ((bounds.maxX - bounds.minX + 1) * this.scale);
            const height = ((bounds.maxY - bounds.minY + 1) * this.scale);

            const cluster = document.createElement('div');
            cluster.className = 'cluster-marker';
            cluster.style.cssText = `
                position: absolute;
                left: ${x}px;
                top: ${y}px;
                width: ${width}px;
                height: ${height}px;
                border: 2px solid var(--accent-ready);
                background: rgba(0, 255, 65, 0.1);
                pointer-events: none;
                box-sizing: border-box;
            `;

            container.appendChild(cluster);
        });
    }

    /**
     * Render node markers
     */
    renderNodes(container, canvasOffset) {
        if (!this.currentStructure || !this.currentStructure.structure.nodes) return;

        this.currentStructure.structure.nodes.forEach((node, index) => {
            const x = (node.position.pixel.x * this.scale) + canvasOffset.x + this.offset.x;
            const y = (node.position.pixel.y * this.scale) + canvasOffset.y + this.offset.y;

            // Node size based on cluster size
            const baseSize = 6;
            const sizeMultiplier = Math.log10(node.properties.size + 1) / 2;
            const size = Math.max(4, baseSize * (1 + sizeMultiplier));

            const nodeMarker = document.createElement('div');
            nodeMarker.className = 'node-marker';
            nodeMarker.style.cssText = `
                position: absolute;
                left: ${x}px;
                top: ${y}px;
                width: ${size}px;
                height: ${size}px;
                background: var(--accent-data);
                border: 1px solid var(--text-primary);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                pointer-events: none;
                box-sizing: border-box;
            `;

            // Add node ID tooltip
            nodeMarker.title = `${node.id} (${node.properties.size} px)`;

            container.appendChild(nodeMarker);
        });
    }

    /**
     * Render relation lines
     */
    renderRelations(container, canvasOffset) {
        if (!this.currentStructure || !this.currentStructure.structure.relations) return;

        const nodes = this.currentStructure.structure.nodes;
        const nodeMap = new Map(nodes.map(node => [node.id, node]));

        this.currentStructure.structure.relations.forEach((relation, index) => {
            const fromNode = nodeMap.get(relation.from);
            const toNode = nodeMap.get(relation.to);

            if (!fromNode || !toNode) return;

            const x1 = (fromNode.position.pixel.x * this.scale) + canvasOffset.x + this.offset.x;
            const y1 = (fromNode.position.pixel.y * this.scale) + canvasOffset.y + this.offset.y;
            const x2 = (toNode.position.pixel.x * this.scale) + canvasOffset.x + this.offset.x;
            const y2 = (toNode.position.pixel.y * this.scale) + canvasOffset.y + this.offset.y;

            const length = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
            const angle = Math.atan2(y2 - y1, x2 - x1);

            const relationLine = document.createElement('div');
            relationLine.className = 'relation-line';
            relationLine.style.cssText = `
                position: absolute;
                left: ${x1}px;
                top: ${y1}px;
                width: ${length}px;
                height: 1px;
                background: var(--accent-processing);
                opacity: 0.6;
                transform-origin: left center;
                transform: rotate(${angle}rad);
                pointer-events: none;
            `;

            // Add relation info tooltip
            relationLine.title = `${relation.from} → ${relation.to} (${relation.distance.toFixed(1)}px)`;

            container.appendChild(relationLine);
        });
    }

    /**
     * Render density areas
     */
    renderDensityAreas(container, canvasOffset) {
        if (!this.currentStructure || !this.currentStructure.structure.nodes) return;

        // Simple density visualization - just highlight dense regions
        const nodes = this.currentStructure.structure.nodes;
        const gridSize = 50; // pixels
        const densityGrid = this.calculateDensityGrid(nodes, gridSize);

        densityGrid.forEach((cell) => {
            if (cell.density < 0.1) return; // Skip low-density cells

            const x = (cell.x * this.scale) + canvasOffset.x + this.offset.x;
            const y = (cell.y * this.scale) + canvasOffset.y + this.offset.y;
            const size = gridSize * this.scale;

            const densityArea = document.createElement('div');
            densityArea.className = 'density-overlay';
            densityArea.style.cssText = `
                position: absolute;
                left: ${x}px;
                top: ${y}px;
                width: ${size}px;
                height: ${size}px;
                background: rgba(255, 170, 0, ${Math.min(0.3, cell.density)});
                border: 1px solid rgba(255, 170, 0, 0.4);
                pointer-events: none;
                box-sizing: border-box;
            `;

            densityArea.title = `Density: ${cell.density.toFixed(2)}`;

            container.appendChild(densityArea);
        });
    }

    /**
     * Calculate density grid for visualization
     */
    calculateDensityGrid(nodes, gridSize) {
        if (!this.currentStructure) return [];

        const width = this.currentStructure.meta.width;
        const height = this.currentStructure.meta.height;
        
        const gridCols = Math.ceil(width / gridSize);
        const gridRows = Math.ceil(height / gridSize);
        
        const densityGrid = [];

        for (let row = 0; row < gridRows; row++) {
            for (let col = 0; col < gridCols; col++) {
                const x = col * gridSize;
                const y = row * gridSize;
                
                // Count nodes in this grid cell
                let nodeCount = 0;
                let totalSize = 0;

                nodes.forEach(node => {
                    const nodeX = node.position.pixel.x;
                    const nodeY = node.position.pixel.y;

                    if (nodeX >= x && nodeX < x + gridSize &&
                        nodeY >= y && nodeY < y + gridSize) {
                        nodeCount++;
                        totalSize += node.properties.size;
                    }
                });

                if (nodeCount > 0) {
                    const density = totalSize / (gridSize * gridSize);
                    densityGrid.push({
                        x: x,
                        y: y,
                        nodeCount: nodeCount,
                        totalSize: totalSize,
                        density: density
                    });
                }
            }
        }

        return densityGrid;
    }

    /**
     * Render structure in dedicated canvas
     */
    renderStructureCanvas(structureData) {
        const canvas = document.getElementById('structureCanvas');
        if (!canvas || !structureData) return;

        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        // Clear canvas
        ctx.fillStyle = '#0a0a0a';
        ctx.fillRect(0, 0, width, height);

        const structure = structureData.structure;
        if (!structure || !structure.nodes.length) {
            // Draw "no data" indicator
            ctx.fillStyle = '#666666';
            ctx.font = '10px monospace';
            ctx.textAlign = 'center';
            ctx.fillText('NO STRUCTURE', width / 2, height / 2);
            return;
        }

        // Calculate bounds and scale
        const bounds = this.calculateStructureBounds(structure.nodes);
        const scale = this.calculateStructureScale(bounds, width - 40, height - 40);
        const centerX = width / 2;
        const centerY = height / 2;

        // Draw relations first (behind nodes)
        ctx.strokeStyle = '#ffaa00';
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.6;

        const nodeMap = new Map(structure.nodes.map(node => [node.id, node]));

        structure.relations.forEach(relation => {
            const fromNode = nodeMap.get(relation.from);
            const toNode = nodeMap.get(relation.to);

            if (fromNode && toNode) {
                const x1 = centerX + (fromNode.position.pixel.x - bounds.centerX) * scale;
                const y1 = centerY + (fromNode.position.pixel.y - bounds.centerY) * scale;
                const x2 = centerX + (toNode.position.pixel.x - bounds.centerX) * scale;
                const y2 = centerY + (toNode.position.pixel.y - bounds.centerY) * scale;

                ctx.beginPath();
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
                ctx.stroke();
            }
        });

        // Draw nodes
        ctx.globalAlpha = 1.0;
        ctx.fillStyle = '#00aaff';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;

        structure.nodes.forEach(node => {
            const x = centerX + (node.position.pixel.x - bounds.centerX) * scale;
            const y = centerY + (node.position.pixel.y - bounds.centerY) * scale;
            
            // Node size based on cluster size
            const size = Math.max(2, Math.sqrt(node.properties.size) / 3);

            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
        });

        // Draw metrics
        ctx.fillStyle = '#666666';
        ctx.font = '8px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`NODES: ${structure.nodes.length}`, 5, 15);
        ctx.fillText(`RELATIONS: ${structure.relations.length}`, 5, 25);
        ctx.fillText(`DENSITY: ${structure.metrics.density.toFixed(3)}`, 5, 35);
    }

    /**
     * Calculate bounds of structure for scaling
     */
    calculateStructureBounds(nodes) {
        if (nodes.length === 0) {
            return { minX: 0, maxX: 100, minY: 0, maxY: 100, centerX: 50, centerY: 50 };
        }

        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;

        nodes.forEach(node => {
            const x = node.position.pixel.x;
            const y = node.position.pixel.y;
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        });

        return {
            minX, maxX, minY, maxY,
            centerX: (minX + maxX) / 2,
            centerY: (minY + maxY) / 2,
            width: maxX - minX,
            height: maxY - minY
        };
    }

    /**
     * Calculate scale for structure display
     */
    calculateStructureScale(bounds, maxWidth, maxHeight) {
        if (bounds.width === 0 && bounds.height === 0) {
            return 1.0;
        }

        const scaleX = bounds.width > 0 ? maxWidth / bounds.width : 1.0;
        const scaleY = bounds.height > 0 ? maxHeight / bounds.height : 1.0;

        return Math.min(scaleX, scaleY, 1.0); // Don't scale up
    }

    /**
     * Clear all overlays
     */
    clearOverlays() {
        const overlayContainer = document.getElementById('measurementOverlay');
        if (overlayContainer) {
            overlayContainer.innerHTML = '';
        }

        const structureCanvas = document.getElementById('structureCanvas');
        if (structureCanvas) {
            const ctx = structureCanvas.getContext('2d');
            ctx.clearRect(0, 0, structureCanvas.width, structureCanvas.height);
        }

        this.currentStructure = null;
    }

    /**
     * Update visualization for window resize
     */
    handleResize() {
        if (this.currentStructure) {
            // Recalculate and re-render
            setTimeout(() => {
                this.renderOverlays();
            }, 100);
        }
    }

    /**
     * Export visualization as image
     */
    exportVisualization() {
        const canvas = document.getElementById('structureCanvas');
        if (!canvas) return null;

        return {
            dataURL: canvas.toDataURL('image/png'),
            filename: `hexBYE_structure_${Date.now()}.png`
        };
    }
}

// Export for use in other modules
window.Visualization = Visualization;
