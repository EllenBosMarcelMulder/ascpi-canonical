/**
 * hexBYE Image Handler
 * Handles image loading, display, and file management
 * NO semantic interpretation of images, purely functional handling
 */

class ImageHandler {
    constructor() {
        this.loadedImages = new Map(); // id -> ImageData
        this.currentImageId = null;
        this.imageCounter = 0;
        this.maxImageSize = 2048; // Maximum dimension for processing
    }

    /**
     * Initialize image handler with UI elements
     */
    initialize() {
        this.setupEventListeners();
        this.updateUI();
    }

    /**
     * Setup drag & drop and file input event listeners
     */
    setupEventListeners() {
        // File input
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.handleFileInput(e));
        }

        // Upload zone
        const uploadZone = document.getElementById('uploadZone');
        if (uploadZone) {
            uploadZone.addEventListener('click', () => this.triggerFileSelect());
            uploadZone.addEventListener('dragover', (e) => this.handleDragOver(e));
            uploadZone.addEventListener('dragleave', (e) => this.handleDragLeave(e));
            uploadZone.addEventListener('drop', (e) => this.handleDrop(e));
        }

        // Image list interactions
        const imageList = document.getElementById('listItems');
        if (imageList) {
            imageList.addEventListener('click', (e) => this.handleImageSelect(e));
        }
    }

    /**
     * Trigger file selection dialog
     */
    triggerFileSelect() {
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.click();
        }
    }

    /**
     * Handle file input change
     */
    async handleFileInput(event) {
        const files = event.target.files;
        await this.processFiles(files);
        // Clear input to allow re-selection of same file
        event.target.value = '';
    }

    /**
     * Handle drag over event
     */
    handleDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        
        const uploadZone = document.getElementById('uploadZone');
        if (uploadZone) {
            uploadZone.classList.add('drag-over');
        }
    }

    /**
     * Handle drag leave event
     */
    handleDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        
        // Only remove class if actually leaving the zone
        if (!event.currentTarget.contains(event.relatedTarget)) {
            const uploadZone = document.getElementById('uploadZone');
            if (uploadZone) {
                uploadZone.classList.remove('drag-over');
            }
        }
    }

    /**
     * Handle drop event
     */
    async handleDrop(event) {
        event.preventDefault();
        event.stopPropagation();

        const uploadZone = document.getElementById('uploadZone');
        if (uploadZone) {
            uploadZone.classList.remove('drag-over');
        }

        const files = event.dataTransfer.files;
        await this.processFiles(files);
    }

    /**
     * Process dropped or selected files
     */
    async processFiles(files) {
        const validFiles = [];

        // Filter for valid image files
        for (const file of files) {
            if (this.isValidImageFile(file)) {
                validFiles.push(file);
            } else {
                console.warn(`Invalid file type: ${file.name}`);
                this.showStatus(`Invalid file type: ${file.name}`, 'error');
            }
        }

        // Load valid files
        for (const file of validFiles) {
            try {
                await this.loadImage(file);
            } catch (error) {
                console.error(`Failed to load ${file.name}:`, error);
                this.showStatus(`Failed to load ${file.name}`, 'error');
            }
        }

        this.updateUI();
    }

    /**
     * Check if file is valid image
     */
    isValidImageFile(file) {
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        return validTypes.includes(file.type);
    }

    /**
     * Load image file
     */
    async loadImage(file) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const reader = new FileReader();

            reader.onload = (e) => {
                img.onload = () => {
                    try {
                        // Check image dimensions
                        if (img.naturalWidth > this.maxImageSize || img.naturalHeight > this.maxImageSize) {
                            this.showStatus(`Image too large (max ${this.maxImageSize}px)`, 'error');
                            reject(new Error('Image too large'));
                            return;
                        }

                        // Create image data object
                        const imageData = {
                            id: `img_${this.imageCounter++}`,
                            file: file,
                            filename: file.name,
                            filesize: file.size,
                            filetype: file.type,
                            width: img.naturalWidth,
                            height: img.naturalHeight,
                            element: img,
                            url: e.target.result,
                            loaded_at: new Date().toISOString(),
                            processed: false,
                            structure: null
                        };

                        // Store image data
                        this.loadedImages.set(imageData.id, imageData);

                        // Set as current if first image
                        if (!this.currentImageId) {
                            this.currentImageId = imageData.id;
                        }

                        this.showStatus(`Loaded: ${file.name}`, 'success');
                        resolve(imageData);

                    } catch (error) {
                        reject(error);
                    }
                };

                img.onerror = () => {
                    reject(new Error('Failed to decode image'));
                };

                img.src = e.target.result;
            };

            reader.onerror = () => {
                reject(new Error('Failed to read file'));
            };

            reader.readAsDataURL(file);
        });
    }

    /**
     * Handle image selection from list
     */
    handleImageSelect(event) {
        const imageItem = event.target.closest('.image-item');
        if (imageItem && imageItem.dataset.imageId) {
            this.selectImage(imageItem.dataset.imageId);
        }
    }

    /**
     * Select image for display
     */
    selectImage(imageId) {
        if (this.loadedImages.has(imageId)) {
            this.currentImageId = imageId;
            this.displayCurrentImage();
            this.updateUI();
            
            // Enable extract button if image is selected
            this.updateControlStates();
        }
    }

    /**
     * Display current image in measurement view
     */
    displayCurrentImage() {
        const imageData = this.getCurrentImage();
        if (!imageData) return;

        const canvas = document.getElementById('measurementCanvas');
        const container = document.getElementById('measurementContainer');
        const info = document.getElementById('measurementInfo');

        if (canvas && container && info) {
            const ctx = canvas.getContext('2d');
            
            // Calculate display size (maintain aspect ratio)
            const containerRect = container.getBoundingClientRect();
            const maxWidth = containerRect.width - 32; // Account for padding
            const maxHeight = containerRect.height - 32;

            const scale = Math.min(
                maxWidth / imageData.width,
                maxHeight / imageData.height,
                1.0 // Don't scale up
            );

            const displayWidth = imageData.width * scale;
            const displayHeight = imageData.height * scale;

            // Set canvas size
            canvas.width = displayWidth;
            canvas.height = displayHeight;
            canvas.style.width = displayWidth + 'px';
            canvas.style.height = displayHeight + 'px';

            // Draw image
            ctx.drawImage(imageData.element, 0, 0, displayWidth, displayHeight);

            // Update info
            info.textContent = `${imageData.filename} (${imageData.width}×${imageData.height})`;
            info.style.display = 'none'; // Hide when image is loaded
        }
    }

    /**
     * Get current image data
     */
    getCurrentImage() {
        return this.currentImageId ? this.loadedImages.get(this.currentImageId) : null;
    }

    /**
     * Get all loaded images
     */
    getAllImages() {
        return Array.from(this.loadedImages.values());
    }

    /**
     * Update UI to reflect current state
     */
    updateUI() {
        this.updateImageList();
        this.updateControlStates();
    }

    /**
     * Update image list display
     */
    updateImageList() {
        const listItems = document.getElementById('listItems');
        if (!listItems) return;

        listItems.innerHTML = '';

        if (this.loadedImages.size === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-message';
            emptyMessage.textContent = 'No images loaded';
            emptyMessage.style.cssText = `
                padding: 20px;
                text-align: center;
                color: var(--text-label);
                font-size: 9px;
            `;
            listItems.appendChild(emptyMessage);
            return;
        }

        // Create list items
        this.loadedImages.forEach((imageData) => {
            const item = document.createElement('div');
            item.className = 'image-item';
            item.dataset.imageId = imageData.id;
            
            if (imageData.id === this.currentImageId) {
                item.classList.add('selected');
            }

            item.innerHTML = `
                <span class="item-name">${imageData.filename}</span>
                <span class="item-status ${imageData.processed ? 'processed' : 'ready'}"></span>
            `;

            listItems.appendChild(item);
        });
    }

    /**
     * Update control button states
     */
    updateControlStates() {
        const extractBtn = document.getElementById('extractBtn');
        const testInvariance = document.getElementById('testInvariance');
        const compareBtn = document.getElementById('compareBtn');

        if (extractBtn) {
            extractBtn.disabled = !this.currentImageId;
        }

        if (testInvariance) {
            testInvariance.disabled = !this.currentImageId;
        }

        if (compareBtn) {
            compareBtn.disabled = this.getProcessedImageCount() < 2;
        }
    }

    /**
     * Get count of processed images
     */
    getProcessedImageCount() {
        return Array.from(this.loadedImages.values()).filter(img => img.processed).length;
    }

    /**
     * Mark image as processed
     */
    markImageProcessed(imageId, structureData) {
        const imageData = this.loadedImages.get(imageId);
        if (imageData) {
            imageData.processed = true;
            imageData.structure = structureData;
            imageData.processed_at = new Date().toISOString();
            this.updateUI();
        }
    }

    /**
     * Clear all loaded images
     */
    clearAllImages() {
        // Revoke object URLs to free memory
        this.loadedImages.forEach(imageData => {
            if (imageData.url) {
                URL.revokeObjectURL(imageData.url);
            }
        });

        this.loadedImages.clear();
        this.currentImageId = null;
        this.imageCounter = 0;
        
        // Clear canvas
        const canvas = document.getElementById('measurementCanvas');
        if (canvas) {
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        this.updateUI();
        this.showStatus('All images cleared', 'info');
    }

    /**
     * Remove specific image
     */
    removeImage(imageId) {
        const imageData = this.loadedImages.get(imageId);
        if (imageData) {
            // Revoke object URL
            if (imageData.url) {
                URL.revokeObjectURL(imageData.url);
            }

            // Remove from collection
            this.loadedImages.delete(imageId);

            // Update current selection if needed
            if (this.currentImageId === imageId) {
                const remaining = Array.from(this.loadedImages.keys());
                this.currentImageId = remaining.length > 0 ? remaining[0] : null;
                
                if (this.currentImageId) {
                    this.displayCurrentImage();
                }
            }

            this.updateUI();
        }
    }

    /**
     * Get canvas for current image
     */
    getCurrentCanvas() {
        return document.getElementById('measurementCanvas');
    }

    /**
     * Show status message
     */
    showStatus(message, type = 'info') {
        const statusElement = document.getElementById('statusIndicator');
        if (statusElement) {
            statusElement.textContent = message.toUpperCase();
            
            // Update status indicator color
            statusElement.className = `status-indicator ${type}`;
            
            // Auto-clear after delay
            setTimeout(() => {
                if (statusElement.textContent === message.toUpperCase()) {
                    statusElement.textContent = 'READY';
                    statusElement.className = 'status-indicator';
                }
            }, 3000);
        }
    }

    /**
     * Export current image data
     */
    exportCurrentImage() {
        const imageData = this.getCurrentImage();
        if (!imageData) return null;

        return {
            filename: imageData.filename,
            dimensions: {
                width: imageData.width,
                height: imageData.height
            },
            processed: imageData.processed,
            structure: imageData.structure
        };
    }
}

// Export for use in other modules
window.ImageHandler = ImageHandler;
