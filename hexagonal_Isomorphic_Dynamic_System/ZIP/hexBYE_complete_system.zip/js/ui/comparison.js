/**
 * hexBYE Comparison
 * Handles structural comparison between two extractions
 * NO semantic comparison, purely structural differences
 */

class Comparison {
    constructor() {
        this.comparisonA = null;
        this.comparisonB = null;
        this.isActive = false;
        this.structureExtractor = null; // Will be injected
    }

    /**
     * Initialize comparison module
     */
    initialize(structureExtractor) {
        this.structureExtractor = structureExtractor;
        this.setupEventListeners();
    }

    /**
     * Setup event listeners for comparison UI
     */
    setupEventListeners() {
        const compareBtn = document.getElementById('compareBtn');
        const closeCompareBtn = document.getElementById('closeCompareBtn');

        if (compareBtn) {
            compareBtn.addEventListener('click', () => this.startComparison());
        }

        if (closeCompareBtn) {
            closeCompareBtn.addEventListener('click', () => this.exitComparison());
        }
    }

    /**
     * Start comparison mode
     */
    startComparison() {
        // Get all processed images
        const processedImages = this.getProcessedImages();
        
        if (processedImages.length < 2) {
            this.showMessage('Need at least 2 processed images for comparison', 'error');
            return;
        }

        // Auto-select first two processed images
        this.comparisonA = processedImages[0];
        this.comparisonB = processedImages[1];

        this.showComparisonMode();
        this.renderComparison();
    }

    /**
     * Show comparison mode interface
     */
    showComparisonMode() {
        const comparisonMode = document.getElementById('comparisonMode');
        if (comparisonMode) {
            comparisonMode.style.display = 'block';
            this.isActive = true;
        }
    }

    /**
     * Exit comparison mode
     */
    exitComparison() {
        const comparisonMode = document.getElementById('comparisonMode');
        if (comparisonMode) {
            comparisonMode.style.display = 'none';
            this.isActive = false;
        }

        this.comparisonA = null;
        this.comparisonB = null;
    }

    /**
     * Get all processed images from image handler
     */
    getProcessedImages() {
        // Access global imageHandler if available
        if (window.imageHandler) {
            return window.imageHandler.getAllImages().filter(img => img.processed && img.structure);
        }
        return [];
    }

    /**
     * Render comparison interface
     */
    renderComparison() {
        if (!this.comparisonA || !this.comparisonB) return;

        // Render side A
        this.renderComparisonSide('A', this.comparisonA);
        
        // Render side B
        this.renderComparisonSide('B', this.comparisonB);
        
        // Render difference analysis
        this.renderDifferenceAnalysis();
    }

    /**
     * Render one side of comparison
     */
    renderComparisonSide(side, imageData) {
        const viewId = `comparison${side}`;
        const metricsId = `metrics${side}`;
        
        const view = document.getElementById(viewId);
        const metrics = document.getElementById(metricsId);

        if (!view || !metrics) return;

        // Clear existing content
        view.innerHTML = '';
        metrics.innerHTML = '';

        // Create canvas for structure visualization
        const canvas = document.createElement('canvas');
        canvas.width = view.clientWidth - 20;
        canvas.height = view.clientHeight - 20;
        canvas.style.cssText = `
            width: 100%;
            height: 100%;
            object-fit: contain;
        `;

        view.appendChild(canvas);

        // Render structure on canvas
        this.renderStructureOnCanvas(canvas, imageData.structure);

        // Display metrics
        const structure = imageData.structure.structure;
        metrics.innerHTML = `
            <div class="metric-row">
                <span class="metric-label">FILE:</span>
                <span class="metric-value">${imageData.filename}</span>
            </div>
            <div class="metric-row">
                <span class="metric-label">NODES:</span>
                <span class="metric-value">${structure.nodes.length}</span>
            </div>
            <div class="metric-row">
                <span class="metric-label">RELATIONS:</span>
                <span class="metric-value">${structure.relations.length}</span>
            </div>
            <div class="metric-row">
                <span class="metric-label">DENSITY:</span>
                <span class="metric-value">${structure.metrics.density.toFixed(3)}</span>
            </div>
            <div class="metric-row">
                <span class="metric-label">COVERAGE:</span>
                <span class="metric-value">${(structure.metrics.coverage * 100).toFixed(1)}%</span>
            </div>
            <div class="metric-row">
                <span class="metric-label">CONNECTIVITY:</span>
                <span class="metric-value">${structure.metrics.connectivity.toFixed(2)}</span>
            </div>
        `;
    }

    /**
     * Render structure on canvas for comparison
     */
    renderStructureOnCanvas(canvas, structureData) {
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        // Clear canvas
        ctx.fillStyle = '#0a0a0a';
        ctx.fillRect(0, 0, width, height);

        const structure = structureData.structure;
        if (!structure || !structure.nodes.length) return;

        // Calculate bounds and scale
        const bounds = this.calculateStructureBounds(structure.nodes);
        const scale = this.calculateStructureScale(bounds, width - 20, height - 20);
        const centerX = width / 2;
        const centerY = height / 2;

        // Draw relations
        ctx.strokeStyle = '#ffaa00';
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.5;

        const nodeMap = new Map(structure.nodes.map(node => [node.id, node]));

        structure.relations.forEach(relation => {
            const fromNode = nodeMap.get(relation.from);
            const toNode = nodeMap.get(relation.to);

            if (fromNode && toNode) {
                const x1 = centerX + (fromNode.position.pixel.x - bounds.centerX) * scale;
                const y1 = centerY + (fromNode.position.pixel.y - bounds.centerY) * scale;
                const x2 = centerX + (toNode.position.pixel.x - bounds.centerX) * scale;
                const y2 = centerY + (toNode.position.pixel.y - bounds.centerY) * scale;

                ctx.beginPath();
                ctx.moveTo(x1, y1);
                ctx.lineTo(x2, y2);
                ctx.stroke();
            }
        });

        // Draw nodes
        ctx.globalAlpha = 1.0;
        ctx.fillStyle = '#00aaff';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;

        structure.nodes.forEach(node => {
            const x = centerX + (node.position.pixel.x - bounds.centerX) * scale;
            const y = centerY + (node.position.pixel.y - bounds.centerY) * scale;
            const size = Math.max(2, Math.sqrt(node.properties.size) / 4);

            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
        });
    }

    /**
     * Render difference analysis
     */
    renderDifferenceAnalysis() {
        if (!this.comparisonA || !this.comparisonB || !this.structureExtractor) return;

        const diffMetrics = document.getElementById('diffMetrics');
        if (!diffMetrics) return;

        // Perform comparison
        const comparison = this.structureExtractor.compareExtractions(
            this.comparisonA.structure,
            this.comparisonB.structure
        );

        // Calculate color based on similarity
        const similarity = comparison.similarity;
        const color = this.getSimilarityColor(similarity);

        // Render difference metrics
        diffMetrics.innerHTML = `
            <div class="diff-metric" style="color: ${color}">
                <div class="diff-label">SIMILARITY:</div>
                <div class="diff-value">${((1 - similarity) * 100).toFixed(1)}%</div>
            </div>
            
            <div class="diff-details">
                <div class="diff-detail">
                    <span>NODE DIFF:</span>
                    <span>${comparison.comparison.node_count_diff}</span>
                </div>
                <div class="diff-detail">
                    <span>RELATION DIFF:</span>
                    <span>${comparison.comparison.relation_count_diff}</span>
                </div>
                <div class="diff-detail">
                    <span>DENSITY DIFF:</span>
                    <span>${comparison.comparison.density_diff.toFixed(3)}</span>
                </div>
                <div class="diff-detail">
                    <span>TOPOLOGY DIFF:</span>
                    <span>${comparison.comparison.topology_diff.toFixed(3)}</span>
                </div>
            </div>
            
            <div class="diff-verdict">
                ${comparison.identical ? 'IDENTICAL STRUCTURES' : 'DIFFERENT STRUCTURES'}
            </div>
        `;
    }

    /**
     * Get color based on similarity score
     */
    getSimilarityColor(similarity) {
        if (similarity < 0.01) return '#00ff41'; // Green - identical/very similar
        if (similarity < 0.1) return '#ffaa00';  // Orange - similar
        if (similarity < 0.3) return '#ff6600';  // Orange-red - different
        return '#ff4444'; // Red - very different
    }

    /**
     * Calculate structure bounds for display
     */
    calculateStructureBounds(nodes) {
        if (nodes.length === 0) {
            return { centerX: 0, centerY: 0, width: 100, height: 100 };
        }

        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;

        nodes.forEach(node => {
            const x = node.position.pixel.x;
            const y = node.position.pixel.y;
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        });

        return {
            minX, maxX, minY, maxY,
            centerX: (minX + maxX) / 2,
            centerY: (minY + maxY) / 2,
            width: maxX - minX,
            height: maxY - minY
        };
    }

    /**
     * Calculate scale for structure display
     */
    calculateStructureScale(bounds, maxWidth, maxHeight) {
        if (bounds.width === 0 && bounds.height === 0) {
            return 1.0;
        }

        const scaleX = bounds.width > 0 ? maxWidth / bounds.width : 1.0;
        const scaleY = bounds.height > 0 ? maxHeight / bounds.height : 1.0;

        return Math.min(scaleX, scaleY, 2.0); // Allow some scale up for small structures
    }

    /**
     * Switch comparison items
     */
    switchComparison(sideA_imageId, sideB_imageId) {
        const processedImages = this.getProcessedImages();
        
        const imageA = processedImages.find(img => img.id === sideA_imageId);
        const imageB = processedImages.find(img => img.id === sideB_imageId);

        if (imageA && imageB) {
            this.comparisonA = imageA;
            this.comparisonB = imageB;
            this.renderComparison();
        }
    }

    /**
     * Export comparison results
     */
    exportComparison() {
        if (!this.comparisonA || !this.comparisonB || !this.structureExtractor) {
            return null;
        }

        const comparison = this.structureExtractor.compareExtractions(
            this.comparisonA.structure,
            this.comparisonB.structure
        );

        const exportData = {
            comparison_type: 'structural',
            timestamp: new Date().toISOString(),
            image_a: {
                filename: this.comparisonA.filename,
                structure_hash: this.structureExtractor.visibilityMapper.generateStructureHash(
                    this.comparisonA.structure.structure
                )
            },
            image_b: {
                filename: this.comparisonB.filename,
                structure_hash: this.structureExtractor.visibilityMapper.generateStructureHash(
                    this.comparisonB.structure.structure
                )
            },
            results: comparison,
            verdict: comparison.identical ? 'identical' : 'different'
        };

        return {
            data: JSON.stringify(exportData, null, 2),
            filename: `hexBYE_comparison_${Date.now()}.json`,
            mimetype: 'application/json'
        };
    }

    /**
     * Show message in comparison interface
     */
    showMessage(message, type = 'info') {
        // Could be implemented to show messages in the comparison UI
        console.log(`${type.toUpperCase()}: ${message}`);
        
        // Update status if available
        if (window.imageHandler) {
            window.imageHandler.showStatus(message, type);
        }
    }

    /**
     * Check if comparison mode is active
     */
    isComparisonActive() {
        return this.isActive;
    }

    /**
     * Get current comparison data
     */
    getCurrentComparison() {
        if (!this.comparisonA || !this.comparisonB) return null;

        return {
            imageA: this.comparisonA,
            imageB: this.comparisonB,
            isActive: this.isActive
        };
    }
}

// Add CSS for comparison metrics
const comparisonCSS = `
    .metric-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 4px;
        font-size: 9px;
    }

    .metric-label {
        color: var(--text-label);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .metric-value {
        color: var(--accent-data);
        font-weight: bold;
    }

    .diff-metric {
        text-align: center;
        margin-bottom: 16px;
    }

    .diff-label {
        font-size: 9px;
        color: var(--text-label);
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 4px;
    }

    .diff-value {
        font-size: 24px;
        font-weight: bold;
    }

    .diff-details {
        margin-bottom: 16px;
    }

    .diff-detail {
        display: flex;
        justify-content: space-between;
        margin-bottom: 4px;
        font-size: 8px;
        color: var(--text-secondary);
    }

    .diff-verdict {
        text-align: center;
        font-size: 10px;
        font-weight: bold;
        color: var(--text-primary);
        text-transform: uppercase;
        letter-spacing: 1px;
        padding: 8px;
        border: 1px solid var(--border-accent);
    }
`;

// Inject CSS
const style = document.createElement('style');
style.textContent = comparisonCSS;
document.head.appendChild(style);

// Export for use in other modules
window.Comparison = Comparison;
