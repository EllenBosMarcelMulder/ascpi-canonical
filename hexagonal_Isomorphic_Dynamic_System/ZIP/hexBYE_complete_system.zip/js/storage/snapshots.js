/**
 * hexBYE Snapshots
 * Local storage and snapshot management
 * NO cloud storage, purely browser-local persistence
 */

class Snapshots {
    constructor() {
        this.storageKey = 'hexBYE_snapshots';
        this.metaKey = 'hexBYE_meta';
        this.maxSnapshots = 100; // Prevent storage bloat
        this.storageVisible = false;
    }

    /**
     * Initialize snapshots module
     */
    initialize() {
        this.setupEventListeners();
        this.loadStoragePanel();
        this.validateStorage();
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        const snapshotBtn = document.getElementById('snapshotBtn');
        const exportBtn = document.getElementById('exportBtn');
        const clearStorageBtn = document.getElementById('clearStorageBtn');

        if (snapshotBtn) {
            snapshotBtn.addEventListener('click', () => this.saveCurrentSnapshot());
        }

        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportSnapshots());
        }

        if (clearStorageBtn) {
            clearStorageBtn.addEventListener('click', () => this.clearAllSnapshots());
        }

        // Toggle storage panel visibility
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                this.toggleStoragePanel();
            }
        });
    }

    /**
     * Save current extraction as snapshot
     */
    async saveCurrentSnapshot() {
        try {
            // Get current image and structure
            const currentImage = window.imageHandler ? window.imageHandler.getCurrentImage() : null;
            if (!currentImage || !currentImage.structure) {
                this.showMessage('No structure to save', 'error');
                return;
            }

            const snapshot = {
                id: this.generateSnapshotId(),
                timestamp: new Date().toISOString(),
                filename: currentImage.filename,
                image: {
                    width: currentImage.width,
                    height: currentImage.height,
                    filesize: currentImage.filesize,
                    filetype: currentImage.filetype
                },
                structure: currentImage.structure,
                meta: {
                    hexBYE_version: '1.0',
                    saved_by: 'hexBYE_local_instrument',
                    hash: this.generateDataHash(currentImage.structure)
                }
            };

            await this.saveSnapshot(snapshot);
            this.updateStoragePanel();
            this.showMessage(`Snapshot saved: ${snapshot.id}`, 'success');

        } catch (error) {
            console.error('Failed to save snapshot:', error);
            this.showMessage('Failed to save snapshot', 'error');
        }
    }

    /**
     * Save snapshot to local storage
     */
    async saveSnapshot(snapshot) {
        const snapshots = this.getSnapshots();
        
        // Check if we're at max capacity
        if (snapshots.length >= this.maxSnapshots) {
            // Remove oldest snapshot
            snapshots.shift();
        }

        // Add new snapshot
        snapshots.push(snapshot);

        // Save to localStorage
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(snapshots));
            
            // Update metadata
            this.updateMetadata(snapshots);
            
        } catch (error) {
            throw new Error(`Storage quota exceeded: ${error.message}`);
        }
    }

    /**
     * Get all snapshots from storage
     */
    getSnapshots() {
        try {
            const stored = localStorage.getItem(this.storageKey);
            return stored ? JSON.parse(stored) : [];
        } catch (error) {
            console.error('Failed to load snapshots:', error);
            return [];
        }
    }

    /**
     * Get snapshot by ID
     */
    getSnapshot(snapshotId) {
        const snapshots = this.getSnapshots();
        return snapshots.find(snap => snap.id === snapshotId);
    }

    /**
     * Delete snapshot by ID
     */
    async deleteSnapshot(snapshotId) {
        const snapshots = this.getSnapshots();
        const filtered = snapshots.filter(snap => snap.id !== snapshotId);
        
        if (filtered.length < snapshots.length) {
            localStorage.setItem(this.storageKey, JSON.stringify(filtered));
            this.updateMetadata(filtered);
            this.updateStoragePanel();
            return true;
        }
        return false;
    }

    /**
     * Load snapshot (restore to UI)
     */
    async loadSnapshot(snapshotId) {
        const snapshot = this.getSnapshot(snapshotId);
        if (!snapshot) {
            this.showMessage('Snapshot not found', 'error');
            return;
        }

        try {
            // Create a synthetic image object for display
            const syntheticImage = {
                id: `loaded_${Date.now()}`,
                filename: `${snapshot.filename} (loaded)`,
                width: snapshot.image.width,
                height: snapshot.image.height,
                structure: snapshot.structure,
                processed: true,
                loaded_from_snapshot: true,
                original_snapshot_id: snapshotId
            };

            // Add to image handler if available
            if (window.imageHandler) {
                window.imageHandler.loadedImages.set(syntheticImage.id, syntheticImage);
                window.imageHandler.currentImageId = syntheticImage.id;
                window.imageHandler.updateUI();
            }

            // Display structure if visualization is available
            if (window.visualization) {
                window.visualization.displayStructure(snapshot.structure, null);
            }

            this.showMessage(`Loaded snapshot: ${snapshot.id}`, 'success');

        } catch (error) {
            console.error('Failed to load snapshot:', error);
            this.showMessage('Failed to load snapshot', 'error');
        }
    }

    /**
     * Export snapshots to file
     */
    exportSnapshots() {
        const snapshots = this.getSnapshots();
        
        if (snapshots.length === 0) {
            this.showMessage('No snapshots to export', 'error');
            return;
        }

        const exportData = {
            export_info: {
                timestamp: new Date().toISOString(),
                version: '1.0',
                count: snapshots.length,
                tool: 'hexBYE_local_instrument'
            },
            snapshots: snapshots
        };

        // Create and download file
        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `hexBYE_snapshots_${Date.now()}.json`;
        a.click();
        
        URL.revokeObjectURL(url);
        this.showMessage(`Exported ${snapshots.length} snapshots`, 'success');
    }

    /**
     * Import snapshots from file
     */
    async importSnapshots(file) {
        try {
            const text = await file.text();
            const importData = JSON.parse(text);

            // Validate import data
            if (!importData.snapshots || !Array.isArray(importData.snapshots)) {
                throw new Error('Invalid snapshot file format');
            }

            // Validate each snapshot
            for (const snapshot of importData.snapshots) {
                if (!this.validateSnapshot(snapshot)) {
                    throw new Error(`Invalid snapshot: ${snapshot.id || 'unknown'}`);
                }
            }

            // Merge with existing snapshots
            const existingSnapshots = this.getSnapshots();
            const existingIds = new Set(existingSnapshots.map(s => s.id));
            
            let importedCount = 0;
            for (const snapshot of importData.snapshots) {
                if (!existingIds.has(snapshot.id)) {
                    existingSnapshots.push(snapshot);
                    importedCount++;
                }
            }

            // Trim to max capacity
            if (existingSnapshots.length > this.maxSnapshots) {
                existingSnapshots.splice(0, existingSnapshots.length - this.maxSnapshots);
            }

            // Save merged snapshots
            localStorage.setItem(this.storageKey, JSON.stringify(existingSnapshots));
            this.updateMetadata(existingSnapshots);
            this.updateStoragePanel();

            this.showMessage(`Imported ${importedCount} new snapshots`, 'success');

        } catch (error) {
            console.error('Failed to import snapshots:', error);
            this.showMessage(`Import failed: ${error.message}`, 'error');
        }
    }

    /**
     * Validate snapshot format
     */
    validateSnapshot(snapshot) {
        return (
            snapshot.id &&
            snapshot.timestamp &&
            snapshot.filename &&
            snapshot.structure &&
            snapshot.structure.structure &&
            Array.isArray(snapshot.structure.structure.nodes) &&
            Array.isArray(snapshot.structure.structure.relations)
        );
    }

    /**
     * Clear all snapshots
     */
    clearAllSnapshots() {
        if (confirm('Clear all snapshots? This cannot be undone.')) {
            localStorage.removeItem(this.storageKey);
            localStorage.removeItem(this.metaKey);
            this.updateStoragePanel();
            this.showMessage('All snapshots cleared', 'info');
        }
    }

    /**
     * Update storage panel display
     */
    updateStoragePanel() {
        const snapshotList = document.getElementById('snapshotList');
        if (!snapshotList) return;

        const snapshots = this.getSnapshots();
        snapshotList.innerHTML = '';

        if (snapshots.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.textContent = 'No snapshots saved';
            emptyMessage.style.cssText = `
                text-align: center;
                color: var(--text-label);
                padding: 20px;
                font-size: 9px;
            `;
            snapshotList.appendChild(emptyMessage);
            return;
        }

        // Sort by timestamp (newest first)
        snapshots.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        snapshots.forEach(snapshot => {
            const item = document.createElement('div');
            item.className = 'snapshot-item';
            item.style.cssText = `
                padding: 8px;
                margin-bottom: 4px;
                background: var(--bg-secondary);
                border: 1px solid var(--border-primary);
                cursor: pointer;
                font-size: 8px;
            `;

            const date = new Date(snapshot.timestamp).toLocaleDateString();
            const time = new Date(snapshot.timestamp).toLocaleTimeString();
            const nodeCount = snapshot.structure.structure.nodes.length;
            const relationCount = snapshot.structure.structure.relations.length;

            item.innerHTML = `
                <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
                    <span style="color: var(--text-primary); font-weight: bold;">${snapshot.filename}</span>
                    <span style="color: var(--text-label);">${date}</span>
                </div>
                <div style="display: flex; justify-content: space-between; color: var(--text-secondary);">
                    <span>ID: ${snapshot.id}</span>
                    <span>N:${nodeCount} R:${relationCount}</span>
                </div>
                <div style="color: var(--text-label); margin-top: 4px;">
                    ${time} | ${snapshot.meta.hash.substring(0, 8)}
                </div>
            `;

            // Add click handlers
            item.addEventListener('click', () => this.loadSnapshot(snapshot.id));
            item.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                this.showSnapshotContextMenu(e, snapshot.id);
            });

            snapshotList.appendChild(item);
        });
    }

    /**
     * Show context menu for snapshot
     */
    showSnapshotContextMenu(event, snapshotId) {
        // Simple implementation - could be enhanced with proper context menu
        if (confirm(`Delete snapshot ${snapshotId}?`)) {
            this.deleteSnapshot(snapshotId);
        }
    }

    /**
     * Toggle storage panel visibility
     */
    toggleStoragePanel() {
        const storagePanel = document.getElementById('storagePanel');
        if (storagePanel) {
            this.storageVisible = !this.storageVisible;
            storagePanel.classList.toggle('visible', this.storageVisible);
            
            if (this.storageVisible) {
                this.updateStoragePanel();
            }
        }
    }

    /**
     * Load storage panel (initialize display)
     */
    loadStoragePanel() {
        this.updateStoragePanel();
    }

    /**
     * Update metadata
     */
    updateMetadata(snapshots) {
        const meta = {
            count: snapshots.length,
            last_updated: new Date().toISOString(),
            version: '1.0',
            total_structures: snapshots.length
        };

        localStorage.setItem(this.metaKey, JSON.stringify(meta));
    }

    /**
     * Get storage metadata
     */
    getMetadata() {
        try {
            const stored = localStorage.getItem(this.metaKey);
            return stored ? JSON.parse(stored) : {};
        } catch (error) {
            return {};
        }
    }

    /**
     * Validate storage integrity
     */
    validateStorage() {
        try {
            const snapshots = this.getSnapshots();
            const invalidSnapshots = snapshots.filter(s => !this.validateSnapshot(s));
            
            if (invalidSnapshots.length > 0) {
                console.warn(`Found ${invalidSnapshots.length} invalid snapshots`);
                
                // Remove invalid snapshots
                const validSnapshots = snapshots.filter(s => this.validateSnapshot(s));
                localStorage.setItem(this.storageKey, JSON.stringify(validSnapshots));
                this.updateMetadata(validSnapshots);
            }
            
        } catch (error) {
            console.error('Storage validation failed:', error);
        }
    }

    /**
     * Get storage usage info
     */
    getStorageInfo() {
        const snapshots = this.getSnapshots();
        const dataSize = localStorage.getItem(this.storageKey)?.length || 0;
        const quotaUsed = ((dataSize / (5 * 1024 * 1024)) * 100).toFixed(1); // Estimate vs 5MB quota

        return {
            count: snapshots.length,
            max_count: this.maxSnapshots,
            data_size_kb: (dataSize / 1024).toFixed(1),
            quota_used_percent: quotaUsed
        };
    }

    /**
     * Generate unique snapshot ID
     */
    generateSnapshotId() {
        return `snap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    }

    /**
     * Generate data hash for integrity
     */
    generateDataHash(structureData) {
        const hashString = JSON.stringify({
            nodes: structureData.structure.nodes.length,
            relations: structureData.structure.relations.length,
            metrics: structureData.structure.metrics
        });
        
        return this.simpleHash(hashString);
    }

    /**
     * Simple hash function
     */
    simpleHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return Math.abs(hash).toString(16);
    }

    /**
     * Show message
     */
    showMessage(message, type = 'info') {
        if (window.imageHandler) {
            window.imageHandler.showStatus(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

// Export for use in other modules
window.Snapshots = Snapshots;
